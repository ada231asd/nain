/**
 * Модуль админ панели
 */
class AdminManager {
    constructor() {
        this.API_BASE = 'http://localhost:8000/api';
        this.currentUser = null;
        this.init();
    }

    init() {
        this.bindEvents();
        this.checkAuth();
    }

    bindEvents() {
        $('#logoutBtn').on('click', () => {
            this.logout();
        });

        // Обработчики для кнопок действий с пользователями
        $(document).on('click', '.approve-btn', (e) => {
            const userId = $(e.currentTarget).data('user-id');
            this.approveUser(userId);
        });

        $(document).on('click', '.reject-btn', (e) => {
            const userId = $(e.currentTarget).data('user-id');
            this.rejectUser(userId);
        });
    }

    // Проверка авторизации
    async checkAuth() {
        const token = localStorage.getItem('authToken');
        if (!token) {
            window.location.href = 'auth.html';
            return;
        }

        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/auth/profile`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.user) {
                this.currentUser = response.user;
                this.displayUserInfo(response.user);
                
                // Проверяем права доступа
                if (!this.isAdmin(response.user)) {
                    this.showError('У вас нет прав доступа к админ панели');
                    setTimeout(() => {
                        window.location.href = 'auth.html';
                    }, 2000);
                    return;
                }
                
                this.loadPendingUsers();
                this.loadStats();
            }
        } catch (error) {
            localStorage.removeItem('authToken');
            localStorage.removeItem('currentUser');
            window.location.href = 'auth.html';
        }
    }

    // Проверка роли администратора
    isAdmin(user) {
        return user && ['service_admin', 'group_admin', 'subgroup_admin'].includes(user.role);
    }

    // Отображение информации о пользователе
    displayUserInfo(user) {
        $('#userName').text(user.fio || user.phone_e164);
    }

    // Загрузка пользователей, ожидающих подтверждения
    async loadPendingUsers() {
        const token = localStorage.getItem('authToken');
        
        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/admin/pending-users`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            $('#pendingUsersLoading').hide();
            
            if (response.users && response.users.length > 0) {
                this.displayPendingUsers(response.users);
            } else {
                $('#noPendingUsers').show();
            }
        } catch (xhr) {
            $('#pendingUsersLoading').hide();
            const response = xhr.responseJSON;
            if (response && response.error) {
                this.showError(response.error);
            } else {
                this.showError('Ошибка загрузки пользователей');
            }
        }
    }

    // Отображение пользователей
    displayPendingUsers(users) {
        const container = $('#pendingUsersList');
        container.empty();
        
        users.forEach(user => {
            const userCard = $(`
                <div class="user-card" data-user-id="${user.user_id}">
                    <div class="user-info-card">
                        <div class="user-field">
                            <div class="user-field-label">ID</div>
                            <div class="user-field-value">${user.user_id}</div>
                        </div>
                        <div class="user-field">
                            <div class="user-field-label">Телефон</div>
                            <div class="user-field-value">${user.phone_e164}</div>
                        </div>
                        <div class="user-field">
                            <div class="user-field-label">Email</div>
                            <div class="user-field-value">${user.email}</div>
                        </div>
                        <div class="user-field">
                            <div class="user-field-label">ФИО</div>
                            <div class="user-field-value">${user.fio || 'Не указано'}</div>
                        </div>
                        <div class="user-field">
                            <div class="user-field-label">Дата регистрации</div>
                            <div class="user-field-value">${new Date(user.created_at).toLocaleString('ru-RU')}</div>
                        </div>
                        <div class="user-field">
                            <div class="user-field-label">Статус</div>
                            <div class="user-field-value">${user.status}</div>
                        </div>
                    </div>
                    <div class="user-actions">
                        <button class="action-btn approve-btn" data-user-id="${user.user_id}">
                            Подтвердить
                        </button>
                        <button class="action-btn reject-btn" data-user-id="${user.user_id}">
                            Отклонить
                        </button>
                    </div>
                </div>
            `);
            
            container.append(userCard);
        });
        
        container.show();
    }

    // Загрузка статистики
    loadStats() {
        // Здесь можно добавить загрузку статистики
        // Пока что устанавливаем заглушки
        $('#totalUsers').text('-');
        $('#pendingUsers').text('-');
        $('#activeUsers').text('-');
    }

    // Подтверждение пользователя
    async approveUser(userId) {
        const token = localStorage.getItem('authToken');
        const button = $(`.approve-btn[data-user-id="${userId}"]`);
        
        button.prop('disabled', true).text('Подтверждение...');
        
        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/admin/approve-user`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({ user_id: userId })
            });

            this.showSuccess('Пользователь подтвержден');
            this.loadPendingUsers();
            this.loadStats();
        } catch (xhr) {
            button.prop('disabled', false).text('Подтвердить');
            const response = xhr.responseJSON;
            if (response && response.error) {
                this.showError(response.error);
            } else {
                this.showError('Ошибка подтверждения пользователя');
            }
        }
    }

    // Отклонение пользователя
    async rejectUser(userId) {
        const token = localStorage.getItem('authToken');
        const button = $(`.reject-btn[data-user-id="${userId}"]`);
        
        button.prop('disabled', true).text('Отклонение...');
        
        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/admin/reject-user`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({ user_id: userId })
            });

            this.showSuccess('Пользователь отклонен');
            this.loadPendingUsers();
            this.loadStats();
        } catch (xhr) {
            button.prop('disabled', false).text('Отклонить');
            const response = xhr.responseJSON;
            if (response && response.error) {
                this.showError(response.error);
            } else {
                this.showError('Ошибка отклонения пользователя');
            }
        }
    }

    // Показать ошибку
    showError(message) {
        $('#errorMessage').text(message).show();
        $('#successMessage').hide();
    }

    // Показать успех
    showSuccess(message) {
        $('#successMessage').text(message).show();
        $('#errorMessage').hide();
    }

    // Выход из системы
    logout() {
        localStorage.removeItem('authToken');
        localStorage.removeItem('currentUser');
        window.location.href = 'auth.html';
    }
}

// Инициализация при загрузке страницы
$(document).ready(() => {
    new AdminManager();
});
