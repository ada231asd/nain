/**
 * Модуль главной страницы
 */
class IndexManager {
    constructor() {
        this.API_BASE = 'http://localhost:8000/api';
        this.currentUser = null;
        this.init();
    }

    init() {
        this.bindEvents();
        this.checkAuth();
    }

    bindEvents() {
        $('#logoutBtn').on('click', () => {
            this.logout();
        });

        $('#adminLink').on('click', (e) => {
            e.preventDefault();
            this.handleAdminAccess();
        });
    }

    // Проверка авторизации
    async checkAuth() {
        const token = localStorage.getItem('authToken');
        if (!token) {
            this.hideLoading();
            return;
        }

        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/auth/profile`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.user) {
                this.currentUser = response.user;
                this.displayUserInfo(response.user);
            }
            this.hideLoading();
        } catch (error) {
            localStorage.removeItem('authToken');
            localStorage.removeItem('currentUser');
            this.hideLoading();
        }
    }

    // Проверка роли администратора
    isAdmin(user) {
        return user && ['service_admin', 'group_admin', 'subgroup_admin'].includes(user.role);
    }

    // Отображение информации о пользователе
    displayUserInfo(user) {
        $('#userName').text(user.fio || user.phone_e164);
        $('#userRole').text(user.role || 'user');
        $('#userInfo').show();
        
        // Обновляем кнопки в зависимости от роли
        const actionButtons = $('#actionButtons');
                actionButtons.html(`
                    <a href="dashboard.html" class="action-btn btn-primary">
                        Панель пользователя
                    </a>
                    ${this.isAdmin(user) ? 
                        '<a href="admin_full.html" class="action-btn btn-admin">Админ панель</a>' : ''}
                `);
    }

    // Обработка доступа к админ панели
    async handleAdminAccess() {
        const token = localStorage.getItem('authToken');
        if (!token) {
            this.showError('Необходимо авторизоваться для доступа к админ панели');
            return;
        }

        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/auth/profile`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.user && this.isAdmin(response.user)) {
                window.location.href = 'admin_full.html';
            } else {
                this.showError('У вас нет прав доступа к админ панели');
            }
        } catch (error) {
            localStorage.removeItem('authToken');
            localStorage.removeItem('currentUser');
            this.showError('Сессия истекла. Войдите в систему заново.');
        }
    }

    // Показать ошибку
    showError(message) {
        $('#errorMessage').text(message).show();
    }

    // Скрыть ошибку
    hideError() {
        $('#errorMessage').hide();
    }

    // Показать загрузку
    showLoading() {
        $('#loading').show();
        $('#mainContent').hide();
    }

    // Скрыть загрузку
    hideLoading() {
        $('#loading').hide();
        $('#mainContent').show();
    }

    // Выход из системы
    logout() {
        localStorage.removeItem('authToken');
        localStorage.removeItem('currentUser');
        location.reload();
    }
}

// Инициализация при загрузке страницы
$(document).ready(() => {
    new IndexManager();
});
