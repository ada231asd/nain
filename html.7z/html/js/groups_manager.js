class GroupsManager {
    constructor(apiBase, showNotification) {
        this.API_BASE = apiBase;
        this.showNotification = showNotification;
        this.groupsCache = null;
        this.groupsCacheTime = 0;
        this.CACHE_DURATION = 30000; // 30 секунд
    }

    // Загрузка групп
    async loadGroups() {
        console.log('GroupsManager: loadGroups вызвана');
        $('#groupsLoading').show();
        $('#groupsTable').hide();
        $('#noGroups').hide();
        $('#groupsTable').empty();

        try {
            const groups = await this.getGroups();
            console.log('GroupsManager: Получены группы:', groups);
            this.displayGroups(groups);
            $('#groupsLoading').hide();
        } catch (error) {
            $('#groupsLoading').hide();
            console.error('Ошибка загрузки групп:', error);
            this.showNotification('Ошибка загрузки групп: ' + error.message, 'error');
        }
    }

    // Получение групп с кэшированием
    async getGroups() {
        const now = Date.now();
        if (this.groupsCache && (now - this.groupsCacheTime) < this.CACHE_DURATION) {
            console.log('GroupsManager: Используем кэшированные данные');
            return this.groupsCache;
        }

        const token = localStorage.getItem('authToken');
        if (!token) {
            throw new Error('Токен авторизации не найден');
        }

        try {
            console.log('GroupsManager: Запрашиваем группы с сервера');
            const response = await this.apiRequest('/api/org-units', 'GET');
            console.log('GroupsManager: Полный ответ от сервера:', response);
            
            if (!response.success) {
                throw new Error(response.error || JSON.stringify(response.data));
            }

            const groups = response.data || [];
            console.log('GroupsManager: Получены группы с сервера:', groups);
            console.log('GroupsManager: Тип groups:', typeof groups, 'isArray:', Array.isArray(groups));

            // Проверяем, что groups - это массив
            if (!Array.isArray(groups)) {
                console.error('GroupsManager: response.data не является массивом:', groups);
                throw new Error('Неверный формат данных от сервера');
            }

            // Обогащаем данные информацией о родительских группах
            const enrichedGroups = groups.map(group => {
                const parentGroup = groups.find(p => p.org_unit_id === group.parent_org_unit_id);
                return {
                    ...group,
                    parent_name: parentGroup ? parentGroup.name : 'Корневая группа'
                };
            });

            this.groupsCache = enrichedGroups;
            this.groupsCacheTime = now;
            return enrichedGroups;
        } catch (error) {
            console.error('Ошибка загрузки групп:', error);
            throw error;
        }
    }

    // Отображение групп
    displayGroups(groups) {
        console.log('GroupsManager: displayGroups вызвана с данными:', groups);
        
        if (!groups || groups.length === 0) {
            console.log('GroupsManager: Нет данных для отображения');
            $('#noGroups').show();
            $('#groupsTable').hide();
            return;
        }

        console.log('GroupsManager: Создаем таблицу для', groups.length, 'групп');
        const table = this.createGroupsTable(groups);
        $('#groupsTable').html(table).show();
        $('#noGroups').hide();
        
        // Применяем стили к кнопкам
        setTimeout(() => {
            this.styleActionButtons();
        }, 100);
    }

    // Создание таблицы групп
    createGroupsTable(groups) {
        let table = `
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Название</th>
                        <th>Тип</th>
                        <th>Родительская группа</th>
                        <th>Адрес</th>
                        <th>Логотип</th>
                        <th>Дата создания</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
        `;

        groups.forEach(group => {
            const typeText = this.getTypeName(group.unit_type);
            const createdDate = new Date(group.created_at).toLocaleString('ru-RU');
            
            table += `
                <tr>
                    <td>${group.org_unit_id}</td>
                    <td>${group.name || 'Не указано'}</td>
                    <td>${typeText}</td>
                    <td>${group.parent_name || 'Корневая группа'}</td>
                    <td>${group.adress || 'Не указан'}</td>
                    <td>${group.logo_url ? `<a href="${group.logo_url}" target="_blank">Просмотр</a>` : 'Не загружен'}</td>
                    <td>${createdDate}</td>
                    <td>
                        <button class="action-btn primary edit-group-btn" onclick="adminManager.editGroup(${group.org_unit_id})" title="Редактировать группу">Редактировать</button>
                        <button class="action-btn danger delete-group-btn" onclick="adminManager.deleteGroup(${group.org_unit_id})" title="Удалить группу" data-group-id="${group.org_unit_id}">Удалить</button>
                    </td>
                </tr>
            `;
        });

        table += `
                </tbody>
            </table>
        `;

        return table;
    }

    // Фильтрация групп
    async filterGroups() {
        const searchTerm = $('#groupSearch').val().toLowerCase();
        const typeFilter = $('#groupTypeFilter').val();
        
        console.log('GroupsManager: Фильтрация групп', { searchTerm, typeFilter });
        
        $('#groupsLoading').show();
        $('#groupsTable').hide();
        $('#noGroups').hide();

        try {
            const groups = await this.getGroups();
            let filteredGroups = groups;

            // Фильтр по поиску
            if (searchTerm) {
                filteredGroups = filteredGroups.filter(group =>
                    group.name.toLowerCase().includes(searchTerm) ||
                    (group.adress && group.adress.toLowerCase().includes(searchTerm))
                );
            }

            // Фильтр по типу
            if (typeFilter) {
                filteredGroups = filteredGroups.filter(group =>
                    group.unit_type === typeFilter
                );
            }

            console.log('GroupsManager: Отфильтровано групп:', filteredGroups.length);
            this.displayGroups(filteredGroups);
            $('#groupsLoading').hide();
        } catch (error) {
            $('#groupsLoading').hide();
            console.error('Ошибка фильтрации групп:', error);
            this.showNotification('Ошибка фильтрации групп', 'error');
        }
    }

    // Очистка кэша
    clearGroupsCache() {
        this.groupsCache = null;
        this.groupsCacheTime = 0;
    }

    // API запрос
    async apiRequest(url, method = 'GET', data = null, headers = {}) {
        const token = localStorage.getItem('authToken');
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                ...(token && { 'Authorization': `Bearer ${token}` }),
                ...headers
            }
        };

        if (data) {
            options.body = JSON.stringify(data);
        }

        try {
            const response = await fetch(this.API_BASE + url, options);
            const result = await response.json();
            
            // Если API уже возвращает объект с success и data, используем его
            if (result && typeof result === 'object' && 'success' in result) {
                return {
                    success: result.success,
                    status: response.status,
                    data: result.data || result
                };
            }
            
            // Иначе оборачиваем в стандартный формат
            return {
                success: response.ok,
                status: response.status,
                data: result
            };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Удаление группы
    async deleteGroup(groupId) {
        console.log('GroupsManager: Удаление группы', groupId);
        
        const confirmed = await this.showDeleteConfirmation(groupId);
        if (!confirmed) {
            return;
        }

        try {
            const result = await this.apiRequest(`/api/org-units/${groupId}`, 'DELETE');
            
            if (result.success) {
                this.showNotification('Группа успешно удалена', 'success');
                this.clearGroupsCache();
                await this.loadGroups();
            } else {
                this.showNotification(`Ошибка удаления группы: ${result.error || JSON.stringify(result.data)}`, 'error');
            }
        } catch (error) {
            this.showNotification(`Ошибка удаления группы: ${error.message}`, 'error');
        }
    }

    // Модальное окно подтверждения удаления
    showDeleteConfirmation(groupId) {
        return new Promise((resolve) => {
            const modalHtml = `
                <div id="deleteConfirmModal" class="delete-modal-overlay">
                    <div class="delete-modal-content">
                        <div class="delete-modal-header">
                            <h3>Подтверждение удаления</h3>
                        </div>
                        <div class="delete-modal-body">
                            <p>Вы уверены, что хотите удалить группу с ID <strong>${groupId}</strong>?</p>
                            <p class="warning-text">Это действие нельзя отменить!</p>
                        </div>
                        <div class="delete-modal-footer">
                            <button class="btn btn-cancel" id="cancelDelete">Отмена</button>
                            <button class="btn btn-danger" id="confirmDelete">Удалить</button>
                        </div>
                    </div>
                </div>
            `;

            const modalStyles = `
                <style>
                .delete-modal-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0, 0, 0, 0.5);
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    z-index: 10000;
                }
                .delete-modal-content {
                    background: white;
                    border-radius: 8px;
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
                    max-width: 400px;
                    width: 90%;
                    animation: modalSlideIn 0.3s ease;
                }
                .delete-modal-header {
                    padding: 20px 20px 0;
                    border-bottom: 1px solid #eee;
                }
                .delete-modal-header h3 {
                    margin: 0 0 15px;
                    color: #333;
                    font-size: 18px;
                }
                .delete-modal-body {
                    padding: 20px;
                }
                .delete-modal-body p {
                    margin: 0 0 10px;
                    color: #666;
                }
                .warning-text {
                    color: #e74c3c !important;
                    font-weight: bold;
                }
                .delete-modal-footer {
                    padding: 0 20px 20px;
                    display: flex;
                    gap: 10px;
                    justify-content: flex-end;
                }
                .btn {
                    padding: 8px 16px;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                    transition: all 0.2s ease;
                }
                .btn-cancel {
                    background: #6c757d;
                    color: white;
                }
                .btn-cancel:hover {
                    background: #5a6268;
                }
                .btn-danger {
                    background: #dc3545;
                    color: white;
                }
                .btn-danger:hover {
                    background: #c82333;
                }
                @keyframes modalSlideIn {
                    from {
                        opacity: 0;
                        transform: translateY(-20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
                </style>
            `;

            $('head').append(modalStyles);
            $('body').append(modalHtml);

            const $modal = $('#deleteConfirmModal');

            $('#cancelDelete').on('click', () => {
                $modal.remove();
                resolve(false);
            });

            $('#confirmDelete').on('click', () => {
                $modal.remove();
                resolve(true);
            });

            $modal.on('click', (e) => {
                if (e.target === $modal[0]) {
                    $modal.remove();
                    resolve(false);
                }
            });

            $(document).on('keydown.deleteModal', (e) => {
                if (e.key === 'Escape') {
                    $modal.remove();
                    $(document).off('keydown.deleteModal');
                    resolve(false);
                }
            });
        });
    }

    // Стилизация кнопок действий
    styleActionButtons() {
        $('.edit-group-btn, .delete-group-btn').each(function() {
            const $btn = $(this);
            
            if ($btn.hasClass('edit-group-btn')) {
                $btn.css({
                    'background-color': '#007bff',
                    'border-color': '#007bff',
                    'color': 'white',
                    'margin-right': '5px'
                });
                
                $btn.hover(
                    function() { $(this).css({'background-color': '#0056b3', 'border-color': '#004085'}); },
                    function() { $(this).css({'background-color': '#007bff', 'border-color': '#007bff'}); }
                );
            } else if ($btn.hasClass('delete-group-btn')) {
                $btn.css({
                    'background-color': '#dc3545',
                    'border-color': '#dc3545',
                    'color': 'white',
                    'margin-left': '5px'
                });
                
                $btn.hover(
                    function() { $(this).css({'background-color': '#c82333', 'border-color': '#bd2130'}); },
                    function() { $(this).css({'background-color': '#dc3545', 'border-color': '#dc3545'}); }
                );
            }
            
            $btn.css({
                'padding': '6px 12px',
                'border-radius': '4px',
                'cursor': 'pointer',
                'font-size': '12px',
                'transition': 'all 0.2s ease'
            });
            
            $btn.mousedown(function() {
                $(this).css({
                    'transform': 'translateY(1px)',
                    'box-shadow': 'inset 0 1px 2px rgba(0,0,0,0.2)'
                });
            });
            
            $btn.mouseup(function() {
                $(this).css({
                    'transform': 'translateY(0)',
                    'box-shadow': 'none'
                });
            });
        });
    }

    // Получение названия типа
    getTypeName(type) {
        const typeMap = {
            'group': 'Группа',
            'subgroup': 'Подгруппа'
        };
        return typeMap[type] || 'Неизвестно';
    }

    // Создание группы
    async createGroup(groupData) {
        console.log('GroupsManager: Создание группы:', groupData);
        
        try {
            const result = await this.apiRequest('/api/org-units', 'POST', groupData);
            
            if (result.success) {
                this.showNotification('Группа успешно создана', 'success');
                this.clearGroupsCache();
                return result.data;
            } else {
                this.showNotification(`Ошибка создания группы: ${result.error || JSON.stringify(result.data)}`, 'error');
                return null;
            }
        } catch (error) {
            this.showNotification(`Ошибка создания группы: ${error.message}`, 'error');
            return null;
        }
    }

    // Обновление группы
    async updateGroup(groupId, groupData) {
        console.log('GroupsManager: Обновление группы:', groupId, groupData);
        
        try {
            const result = await this.apiRequest(`/api/org-units/${groupId}`, 'PUT', groupData);
            
            if (result.success) {
                this.showNotification('Группа успешно обновлена', 'success');
                this.clearGroupsCache();
                return result.data;
            } else {
                this.showNotification(`Ошибка обновления группы: ${result.error || JSON.stringify(result.data)}`, 'error');
                return null;
            }
        } catch (error) {
            this.showNotification(`Ошибка обновления группы: ${error.message}`, 'error');
            return null;
        }
    }

    // Получение группы по ID
    async getGroupById(groupId) {
        try {
            const groups = await this.getGroups();
            return groups.find(group => group.org_unit_id == groupId);
        } catch (error) {
            console.error('Ошибка получения группы:', error);
            return null;
        }
    }

    // Загрузка групп для селекта
    async loadGroupsForSelect(selectId, excludeId = null) {
        try {
            const groups = await this.getGroups();
            const $select = $(selectId);
            
            // Очищаем текущие опции (кроме первой)
            $select.find('option:not(:first)').remove();
            
            // Добавляем только группы (не подгруппы) для выбора родительской группы
            groups.filter(group => group.unit_type === 'group' && group.org_unit_id != excludeId)
                .forEach(group => {
                    $select.append(`<option value="${group.org_unit_id}">${group.name}</option>`);
                });
        } catch (error) {
            console.error('Ошибка загрузки групп для селекта:', error);
            this.showNotification('Ошибка загрузки списка групп', 'error');
        }
    }

    // Загрузка всех организационных единиц (групп и подгрупп) для селекта
    async loadAllOrgUnitsForSelect(selectId, excludeId = null) {
        try {
            const groups = await this.getGroups();
            const $select = $(selectId);
            
            // Очищаем текущие опции (кроме первой)
            $select.find('option:not(:first)').remove();
            
            // Сортируем: сначала группы, потом подгруппы
            const sortedGroups = groups.sort((a, b) => {
                if (a.unit_type === b.unit_type) {
                    return a.name.localeCompare(b.name);
                }
                return a.unit_type === 'group' ? -1 : 1;
            });
            
            // Добавляем все группы и подгруппы
            sortedGroups.filter(group => group.org_unit_id != excludeId)
                .forEach(group => {
                    const prefix = group.unit_type === 'group' ? '📁' : '📂';
                    $select.append(`<option value="${group.org_unit_id}">${prefix} ${group.name}</option>`);
                });
                
        } catch (error) {
            console.error('Ошибка загрузки организационных единиц для селекта:', error);
            this.showNotification('Ошибка загрузки списка организационных единиц', 'error');
        }
    }

    // Предварительный просмотр изображения
    setupImagePreview(inputId, previewId, imageId) {
        $(inputId).on('input', function() {
            const url = $(this).val();
            const $preview = $(previewId);
            const $image = $(imageId);
            
            if (url && this.checkValidity()) {
                $image.attr('src', url);
                $image.on('load', function() {
                    $preview.show();
                });
                $image.on('error', function() {
                    $preview.hide();
                    console.warn('Не удалось загрузить изображение:', url);
                });
            } else {
                $preview.hide();
            }
        });
    }

    // Инициализация модальных окон
    initModals() {
        // Предварительный просмотр для создания группы
        this.setupImagePreview('#groupLogo', '#logoPreview', '#previewImage');
        
        // Предварительный просмотр для создания подгруппы
        this.setupImagePreview('#subgroupLogo', '#subgroupLogoPreview', '#subgroupPreviewImage');
        
        // Предварительный просмотр для редактирования группы
        this.setupImagePreview('#editGroupLogo', '#editLogoPreview', '#editPreviewImage');
        
        // Обработчик изменения типа группы в модальном окне редактирования
        $(document).on('change', '#editGroupType', function() {
            const type = $(this).val();
            const parentGroupField = $('#editParentGroup').closest('.form-group');
            
            if (type === 'subgroup') {
                parentGroupField.show();
            } else {
                parentGroupField.hide();
                $('#editParentGroup').val('');
            }
        });
    }
}
