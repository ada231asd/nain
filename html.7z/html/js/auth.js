/**
 * Модуль авторизации и регистрации
 */
class AuthManager {
    constructor() {
        this.API_BASE = 'http://localhost:8000/api';
        this.currentUser = null;
        this.init();
    }

    init() {
        this.bindEvents();
        this.checkExistingAuth();
    }

    bindEvents() {
        // Переключение между вкладками
        $('.tab-button').on('click', (e) => {
            const tab = $(e.currentTarget).data('tab');
            this.switchTab(tab);
        });

        // Обработка формы входа
        $('#loginFormElement').on('submit', (e) => {
            e.preventDefault();
            this.handleLogin();
        });

        // Обработка формы регистрации
        $('#registerFormElement').on('submit', (e) => {
            e.preventDefault();
            this.handleRegister();
        });

        // Обработка клика по ссылке админ панели
        $('#adminLink').on('click', (e) => {
            e.preventDefault();
            this.handleAdminAccess();
        });

        // Очистка ошибок при вводе
        $('input').on('input', (e) => {
            this.clearFieldError($(e.target).attr('id'));
        });
    }

    switchTab(tab) {
        $('.tab-button').removeClass('active');
        $(`.tab-button[data-tab="${tab}"]`).addClass('active');
        
        $('.form-section').removeClass('active');
        $(`#${tab}Form`).addClass('active');
        
        this.clearMessages();
        this.clearErrors();
    }

    // Валидация и санитизация данных
    sanitizeInput(input) {
        if (typeof input !== 'string') return input;
        return input.replace(/[<>\"'&]/g, (match) => {
            const escapeMap = {
                '<': '&lt;', '>': '&gt;', '"': '&quot;',
                "'": '&#x27;', '&': '&amp;'
            };
            return escapeMap[match];
        });
    }

    validatePhone(phone) {
        const phoneRegex = /^\+[1-9]\d{1,14}$/;
        return phoneRegex.test(phone);
    }

    validateEmail(email) {
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return emailRegex.test(email);
    }

    validatePassword(password) {
        return password && password.length >= 6;
    }

    validateFio(fio) {
        if (!fio) return true; // Необязательное поле
        return fio.length >= 2 && fio.length <= 100;
    }

    // Проверка роли пользователя для доступа к админ панели
    isAdmin(user) {
        return user && ['service_admin', 'group_admin', 'subgroup_admin'].includes(user.role);
    }

    // Обработка ошибок
    showError(message) {
        $('#errorAlert').text(message).show();
        $('#successMessage').hide();
    }

    showSuccess(message) {
        $('#successMessage').text(message).show();
        $('#errorAlert').hide();
    }

    clearMessages() {
        $('#errorAlert').hide();
        $('#successMessage').hide();
    }

    clearErrors() {
        $('.error-message').hide();
        $('input').removeClass('error');
    }

    showFieldError(fieldId, message) {
        $(`#${fieldId}Error`).text(message).show();
        $(`#${fieldId}`).addClass('error');
    }

    clearFieldError(fieldId) {
        $(`#${fieldId}Error`).hide();
        $(`#${fieldId}`).removeClass('error');
    }

    showLoading() {
        $('#loading').show();
        $('.submit-button').prop('disabled', true);
    }

    hideLoading() {
        $('#loading').hide();
        $('.submit-button').prop('disabled', false);
    }

    // Обработка входа
    async handleLogin() {
        this.clearMessages();
        this.clearErrors();

        const phone = this.sanitizeInput($('#loginPhone').val().trim());
        const password = this.sanitizeInput($('#loginPassword').val());

        let hasErrors = false;

        if (!phone) {
            this.showFieldError('loginPhone', 'Введите номер телефона');
            hasErrors = true;
        } else if (!this.validatePhone(phone)) {
            this.showFieldError('loginPhone', 'Неверный формат номера телефона');
            hasErrors = true;
        }

        if (!password) {
            this.showFieldError('loginPassword', 'Введите пароль');
            hasErrors = true;
        } else if (!this.validatePassword(password)) {
            this.showFieldError('loginPassword', 'Пароль должен содержать минимум 6 символов');
            hasErrors = true;
        }

        if (hasErrors) return;

        this.showLoading();

        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/auth/login`,
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({
                    phone_e164: phone,
                    password: password
                })
            });

            this.hideLoading();
            
            if (response.message) {
                console.log('Успешная авторизация:', response);
                this.currentUser = response.user;
                localStorage.setItem('authToken', response.token);
                localStorage.setItem('currentUser', JSON.stringify(response.user));
                
                console.log('Токен сохранен:', response.token);
                console.log('Пользователь сохранен:', response.user);
                
                this.showSuccess('Успешная авторизация!');
                
                // Проверяем роль пользователя для перехода
                setTimeout(() => {
                    console.log('Переход на страницу...');
                    if (this.isAdmin(response.user)) {
                        console.log('Переход в админ панель');
                        window.location.href = 'admin_full.html';
                    } else {
                        console.log('Переход в панель пользователя');
                        window.location.href = 'dashboard.html';
                    }
                }, 1500);
            }
        } catch (xhr) {
            this.hideLoading();
            const response = xhr.responseJSON;
            if (response && response.error) {
                this.showError(response.error);
            } else {
                this.showError('Ошибка авторизации. Попробуйте еще раз.');
            }
        }
    }

    // Обработка регистрации
    async handleRegister() {
        this.clearMessages();
        this.clearErrors();

        const phone = this.sanitizeInput($('#registerPhone').val().trim());
        const email = this.sanitizeInput($('#registerEmail').val().trim());
        const fio = this.sanitizeInput($('#registerFio').val().trim());

        let hasErrors = false;

        if (!phone) {
            this.showFieldError('registerPhone', 'Введите номер телефона');
            hasErrors = true;
        } else if (!this.validatePhone(phone)) {
            this.showFieldError('registerPhone', 'Неверный формат номера телефона');
            hasErrors = true;
        }

        if (!email) {
            this.showFieldError('registerEmail', 'Введите email');
            hasErrors = true;
        } else if (!this.validateEmail(email)) {
            this.showFieldError('registerEmail', 'Неверный формат email');
            hasErrors = true;
        }

        if (fio && !this.validateFio(fio)) {
            this.showFieldError('registerFio', 'ФИО должно содержать от 2 до 100 символов');
            hasErrors = true;
        }

        if (hasErrors) return;

        this.showLoading();

        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/auth/register`,
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({
                    phone_e164: phone,
                    email: email,
                    fio: fio || null
                })
            });

            this.hideLoading();
            
            if (response.message) {
                this.showSuccess('Регистрация успешна! Пароль отправлен на email. Ожидайте подтверждения администратора.');
                
                // Переключаемся на форму входа
                setTimeout(() => {
                    this.switchTab('login');
                    $('#loginPhone').val(phone);
                }, 2000);
            }
        } catch (xhr) {
            this.hideLoading();
            const response = xhr.responseJSON;
            if (response && response.error) {
                this.showError(response.error);
            } else {
                this.showError('Ошибка регистрации. Попробуйте еще раз.');
            }
        }
    }

    // Обработка доступа к админ панели
    async handleAdminAccess() {
        const token = localStorage.getItem('authToken');
        if (!token) {
            this.showError('Необходимо авторизоваться для доступа к админ панели');
            return;
        }

        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/auth/profile`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.user && this.isAdmin(response.user)) {
                window.location.href = 'admin_full.html';
            } else {
                this.showError('У вас нет прав доступа к админ панели');
            }
        } catch (error) {
            localStorage.removeItem('authToken');
            localStorage.removeItem('currentUser');
            this.showError('Сессия истекла. Войдите в систему заново.');
        }
    }

    // Проверка существующей авторизации
    async checkExistingAuth() {
        const token = localStorage.getItem('authToken');
        if (!token) return;

        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/auth/profile`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.user) {
                this.currentUser = response.user;
                if (this.isAdmin(response.user)) {
                    window.location.href = 'admin_full.html';
                } else {
                    window.location.href = 'dashboard.html';
                }
            }
        } catch (error) {
            localStorage.removeItem('authToken');
            localStorage.removeItem('currentUser');
        }
    }
}

// Инициализация при загрузке страницы
$(document).ready(() => {
    new AuthManager();
});
