/**
 * Менеджер станций для админ панели
 */
class StationsManager {
    constructor(apiBase, showNotification) {
        this.API_BASE = apiBase;
        this.showNotification = showNotification;
    }

    // Загрузка станций
    async loadStations() {
        console.log('🔄 StationsManager: Начинаем загрузку станций');
        console.trace('StationsManager: loadStations вызвана из:');
        
        console.log('👁️ StationsManager: Показываем индикатор загрузки');
        $('#stationsLoading').show();
        $('.stations-grid').hide();
        $('#noStations').hide();
        $('.stations-grid').empty();

        try {
            console.log('📡 StationsManager: Вызываем getStations()');
            const stations = await this.getStations();
            console.log('✅ StationsManager: Получены станции:', stations.length);
            
            console.log('🖥️ StationsManager: Отображаем станции');
            this.displayStations(stations);
            
            console.log('📡 StationsManager: Загружаем группы для станций');
            await this.loadStationGroups();
            
            console.log('📢 StationsManager: Показываем уведомление');
            this.showNotification(`Загружено ${stations.length} станций`, 'success');
            
            console.log('✅ StationsManager: Загрузка завершена успешно');
            console.log('🏁 StationsManager: loadStations полностью завершена');
            
            // Скрываем индикатор загрузки
            console.log('👁️ StationsManager: Скрываем индикатор загрузки');
            $('#stationsLoading').hide();
            console.log('👁️ StationsManager: Индикатор загрузки скрыт, видимость:', $('#stationsLoading').is(':visible'));
        } catch (error) {
            $('#stationsLoading').hide();
            console.error('❌ StationsManager: Ошибка загрузки станций:', error);
            this.showNotification('Ошибка загрузки станций', 'error');
        }
    }

    // Получение станций
    async getStations() {
        console.log('🌐 StationsManager: Загружаем станции с сервера...');
        const token = localStorage.getItem('authToken');
        
        if (!token) {
            console.error('❌ StationsManager: Токен авторизации не найден');
            throw new Error('Токен авторизации не найден');
        }
        
        try {
            console.log('📡 StationsManager: Отправляем запрос к API /api/stations');
            const response = await $.ajax({
                url: `${this.API_BASE}/api/stations`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            console.log('📊 StationsManager: Ответ API:', response);
            const stations = response.data || [];
            console.log('📈 StationsManager: Получено станций:', stations.length);
            
            return stations;
        } catch (error) {
            console.error('❌ StationsManager: Ошибка получения станций:', error);
            console.error('❌ StationsManager: Статус ошибки:', error.status);
            console.error('❌ StationsManager: Текст ошибки:', error.responseText);
            return [];
        }
    }

    // Отображение станций
    displayStations(stations) {
        console.log('🖥️ StationsManager: Начинаем отображение станций:', stations.length);
        
        if (stations.length === 0) {
            console.log('📭 StationsManager: Нет станций для отображения');
            $('#noStations').show();
            $('.stations-grid').hide();
            return;
        }

        console.log('📋 StationsManager: Создаем сетку станций');
        const grid = this.createStationsGrid(stations);
        $('.stations-grid').html(grid).show();
        $('#noStations').hide();
        console.log('✅ StationsManager: Сетка станций отображена');
    }

    // Создание сетки станций
    createStationsGrid(stations) {
        let grid = '';

        stations.forEach(station => {
            const statusText = this.getStatusText(station.status);
            const statusClass = this.getStatusClass(station.status);
            
            grid += `
                <div class="station-card" data-group-id="${station.org_unit_id || ''}" onclick="adminManager.onStationClick(${station.station_id})" style="cursor: pointer;">
                    <div class="station-header">
                        <h3>Box ID: ${station.box_id}</h3>
                        <span class="status-badge ${statusClass}">${statusText}</span>
                    </div>
                    <div class="station-info">
                        <p><strong>ID станции:</strong> ${station.station_id}</p>
                        <p><strong>ICCID:</strong> ${station.iccid || 'Не указан'}</p>
                        <p><strong>Слотов:</strong> ${station.slots_declared || 0}</p>
                        <p><strong>Занято:</strong> ${parseInt(station.slots_declared || 0) - parseInt(station.remain_num || 0)}</p>
                        <p><strong>Свободно:</strong> ${station.remain_num || 0}</p>
                        <p><strong>Последний контакт:</strong> ${station.last_seen ? new Date(station.last_seen).toLocaleString() : 'Никогда'}</p>
                    </div>
                    <div class="station-actions" onclick="event.stopPropagation();">
                        <div style="display: flex; gap: 8px;">
                            ${station.status === 'pending' ? 
                                `<button class="action-btn success" onclick="adminManager.approveStation(${station.station_id})">Одобрить</button>` : 
                                `<button class="action-btn primary" onclick="adminManager.editStation(${station.station_id})">Редактировать</button>`
                            }
                            <button class="action-btn danger" onclick="adminManager.deleteStation(${station.station_id})">Удалить</button>
                        </div>
                        
                        <!-- Дополнительные функции станции -->
                        <div class="station-extra-actions">
                            <div style="display: flex; gap: 6px; margin-bottom: 6px;">
                                <button class="action-btn small warning" onclick="adminManager.restartStation(${station.station_id})" title="Перезагрузить станцию">
                                    Перезагрузка
                                </button>
                                <button class="action-btn small info" onclick="adminManager.queryStationInventory(${station.station_id})" title="Запросить инвентарь">
                                    Инвентарь
                                </button>
                                <button class="action-btn small secondary" onclick="adminManager.queryStationStatus(${station.station_id})" title="Запросить статус">
                                    Статус
                                </button>
                            </div>
                            <div style="display: flex; gap: 6px;">
                                <button class="action-btn small primary" onclick="adminManager.queryServerAddress(${station.station_id})" title="Запросить адрес сервера">
                                    Адрес сервера
                                </button>
                                <button class="action-btn small info" onclick="adminManager.getStationServerAddress(${station.station_id})" title="Получить адрес сервера">
                                    Получить адрес
                                </button>
                                <button class="action-btn small warning" onclick="adminManager.showSetServerAddressModal(${station.station_id})" title="Установить адрес сервера">
                                    Установить адрес
                                </button>
                                <button class="action-btn small info" onclick="adminManager.queryVoiceVolume(${station.station_id})" title="Запросить уровень громкости">
                                    🔊 Громкость
                                </button>
                                <button class="action-btn small warning" onclick="adminManager.showSetVoiceVolumeModal(${station.station_id})" title="Установить уровень громкости">
                                    🔊 Установить
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        });

        return grid;
    }

    // Фильтрация станций
    async filterStations() {
        console.log('🔍 StationsManager: Начинаем фильтрацию станций');
        
        const searchTerm = $('#stationSearch').val().toLowerCase();
        const groupFilter = $('#stationGroupFilter').val();
        const statusFilter = $('#stationStatusFilter').val();
        
        console.log('🔍 StationsManager: Параметры фильтрации:', {
            searchTerm,
            groupFilter,
            statusFilter
        });
        
        // Показываем индикатор загрузки
        $('#stationsLoading').show();
        $('.stations-grid').hide();
        $('#noStations').hide();
        
        try {
            console.log('📡 StationsManager: Загружаем станции для фильтрации');
            // Загружаем станции с сервера
            const stations = await this.getStations();
            
            // Если все фильтры пустые, показываем все станции
            if (!searchTerm && !groupFilter && !statusFilter) {
                console.log('🔍 StationsManager: Фильтры пустые, показываем все станции');
                this.displayStations(stations);
                $('#stationsLoading').hide();
                return;
            }
            
            console.log('🔍 StationsManager: Применяем фильтры к', stations.length, 'станциям');
            
            // Фильтруем данные на клиенте
            let filteredStations = stations;
            
            // Фильтр по поиску
            if (searchTerm) {
                const beforeCount = filteredStations.length;
                filteredStations = filteredStations.filter(station => 
                    station.box_id.toLowerCase().includes(searchTerm) ||
                    (station.iccid && station.iccid.toLowerCase().includes(searchTerm))
                );
                console.log(`🔍 StationsManager: Фильтр по поиску "${searchTerm}": ${beforeCount} -> ${filteredStations.length}`);
            }
            
            // Фильтр по группе
            if (groupFilter) {
                const beforeCount = filteredStations.length;
                filteredStations = filteredStations.filter(station => 
                    station.org_unit_id == groupFilter
                );
                console.log(`🔍 StationsManager: Фильтр по группе "${groupFilter}": ${beforeCount} -> ${filteredStations.length}`);
            }
            
            // Фильтр по статусу
            if (statusFilter) {
                const beforeCount = filteredStations.length;
                const statusMap = {
                    'Активна': 'active',
                    'Неактивна': 'inactive',
                    'Ожидает': 'pending'
                };
                const expectedStatus = statusMap[statusFilter];
                filteredStations = filteredStations.filter(station => 
                    station.status === expectedStatus
                );
                console.log(`🔍 StationsManager: Фильтр по статусу "${statusFilter}": ${beforeCount} -> ${filteredStations.length}`);
            }
            
            console.log(`🔍 StationsManager: Результат фильтрации: ${filteredStations.length} станций`);
            
            // Отображаем отфильтрованные данные
            this.displayStations(filteredStations);
            $('#stationsLoading').hide();
            
        } catch (error) {
            $('#stationsLoading').hide();
            console.error('❌ StationsManager: Ошибка фильтрации станций:', error);
            this.showNotification('Ошибка фильтрации станций', 'error');
        }
    }

    // Сброс фильтров станций
    async resetStationFilters() {
        console.log('🔄 StationsManager: Сбрасываем фильтры станций');
        $('#stationSearch').val('');
        $('#stationGroupFilter').val('');
        $('#stationStatusFilter').val('');
        
        // Показываем индикатор загрузки
        $('#stationsLoading').show();
        $('.stations-grid').hide();
        $('#noStations').hide();
        
        try {
            // Загружаем станции с сервера
            const stations = await this.getStations();
            this.displayStations(stations);
            $('#stationsLoading').hide();
        } catch (error) {
            $('#stationsLoading').hide();
            console.error('Ошибка сброса фильтров станций:', error);
            this.showNotification('Ошибка сброса фильтров станций', 'error');
        }
    }

    // Загрузка групп для станций
    async loadStationGroups() {
        console.log('📡 StationsManager: Загружаем группы для станций');
        const token = localStorage.getItem('authToken');
        
        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/api/org-units`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            const groups = response.data || [];
            console.log('📈 StationsManager: Получено групп:', groups.length);
            this.populateGroupSelects(groups);
        } catch (error) {
            console.error('❌ StationsManager: Ошибка загрузки групп:', error);
        }
    }

    // Заполнение селектов групп
    populateGroupSelects(groups) {
        console.log('📋 StationsManager: Заполняем селекты групп');
        const approveSelect = $('#approveStationGroup');
        const editSelect = $('#editStationGroup');
        const filterSelect = $('#stationGroupFilter');
        
        // Очищаем и заполняем селекты
        [approveSelect, editSelect, filterSelect].forEach(select => {
            if (select.length) {
                select.empty();
                if (select.attr('id') === 'editStationGroup') {
                    select.append('<option value="">Не назначена</option>');
                } else if (select.attr('id') === 'stationGroupFilter') {
                    select.append('<option value="">Все группы</option>');
                } else {
                    select.append('<option value="">Выберите группу/подгруппу</option>');
                }
                
                groups.forEach(group => {
                    const typeText = group.unit_type === 'group' ? 'Группа' : 'Подгруппа';
                    select.append(`<option value="${group.org_unit_id}">${group.name} (${typeText})</option>`);
                });
            }
        });
            console.log('✅ StationsManager: Селекты групп заполнены');
            console.log('👁️ StationsManager: После заполнения селектов, индикатор загрузки видимый:', $('#stationsLoading').is(':visible'));
    }

    // Удаление станции
    async deleteStation(stationId) {
        if (!confirm('Вы уверены, что хотите удалить эту станцию? Это действие нельзя отменить.')) {
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            
            // Сначала пытаемся удалить секретный ключ станции
            try {
                await $.ajax({
                    url: `${this.API_BASE}/api/station-secret-keys`,
                    method: 'DELETE',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    data: JSON.stringify({ station_id: parseInt(stationId) })
                });
            } catch (secretKeyError) {
                // Если секретный ключ не найден, это не критично
                console.log('Секретный ключ не найден или уже удален:', secretKeyError.status);
            }
            
            // Удаляем саму станцию
            await $.ajax({
                url: `${this.API_BASE}/api/stations/${stationId}`,
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            this.showNotification('Станция успешно удалена', 'success');
            
            // Перезагружаем станции без рекурсии
            console.log('🔄 StationsManager: Перезагружаем станции после удаления');
            $('#stationsLoading').show();
            $('.stations-grid').hide();
            $('#noStations').hide();
            
            try {
                const stations = await this.getStations();
                this.displayStations(stations);
                $('#stationsLoading').hide();
            } catch (error) {
                $('#stationsLoading').hide();
                console.error('Ошибка перезагрузки станций после удаления:', error);
            }
            
        } catch (error) {
            console.error('Ошибка удаления станции:', error);
            this.showNotification('Ошибка удаления станции', 'error');
        }
    }

    // Получение текста статуса
    getStatusText(status) {
        const statusMap = {
            'active': 'Активна',
            'inactive': 'Неактивна',
            'pending': 'Ожидает'
        };
        return statusMap[status] || 'Неизвестно';
    }

    // Получение класса статуса
    getStatusClass(status) {
        const classMap = {
            'active': 'status-active',
            'inactive': 'status-inactive',
            'pending': 'status-pending'
        };
        return classMap[status] || 'status-unknown';
    }
}
