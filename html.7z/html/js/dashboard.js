/**
 * Модуль панели пользователя
 */
class DashboardManager {
    constructor() {
        this.API_BASE = 'http://localhost:8000/api';
        this.currentUser = null;
        this.init();
    }

    init() {
        this.bindEvents();
        this.checkAuth();
    }

    bindEvents() {
        $('#logoutBtn').on('click', () => {
            this.logout();
        });

        // Обработчики действий
        $('#borrowPowerbank').on('click', (e) => {
            e.preventDefault();
            this.showComingSoon('Взять повербанк');
        });

        $('#returnPowerbank').on('click', (e) => {
            e.preventDefault();
            this.showComingSoon('Вернуть повербанк');
        });

        $('#myOrders').on('click', (e) => {
            e.preventDefault();
            this.showComingSoon('Мои заказы');
        });

        $('#editProfile').on('click', (e) => {
            e.preventDefault();
            this.showComingSoon('Редактировать профиль');
        });
    }

    // Проверка авторизации
    async checkAuth() {
        const token = localStorage.getItem('authToken');
        console.log('Проверка авторизации. Токен:', token ? 'есть' : 'нет');
        if (!token) {
            console.log('Токен не найден, перенаправление на страницу входа');
            window.location.href = 'auth.html';
            return;
        }

        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/auth/profile`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.user) {
                console.log('Профиль пользователя получен:', response.user);
                this.currentUser = response.user;
                this.displayUserInfo(response.user);
                $('#loading').hide();
                $('#content').show();
            } else {
                console.log('Пользователь не найден в ответе');
            }
        } catch (error) {
            console.error('Ошибка проверки авторизации:', error);
            console.error('Статус ответа:', error.status);
            console.error('Текст ответа:', error.responseText);
            localStorage.removeItem('authToken');
            localStorage.removeItem('currentUser');
            window.location.href = 'auth.html';
        }
    }

    // Отображение информации о пользователе
    displayUserInfo(user) {
        $('#userName').text(user.fio || user.phone_e164);
        $('#userId').text(user.user_id);
        $('#userPhone').text(user.phone_e164);
        $('#userEmail').text(user.email);
        $('#userFio').text(user.fio || 'Не указано');
        $('#userCreatedAt').text(new Date(user.created_at).toLocaleString('ru-RU'));
        
        // Статус с соответствующим стилем
        const statusElement = $('#userStatus');
        statusElement.text(user.status);
        statusElement.removeClass('status-active status-pending status-blocked');
        
        switch(user.status) {
            case 'active':
                statusElement.addClass('status-active');
                break;
            case 'pending':
                statusElement.addClass('status-pending');
                break;
            case 'blocked':
                statusElement.addClass('status-blocked');
                break;
        }
    }

    // Показать сообщение "скоро будет"
    showComingSoon(feature) {
        alert(`Функция "${feature}" будет реализована в следующих версиях`);
    }

    // Показать ошибку
    showError(message) {
        $('#errorMessage').text(message).show();
    }

    // Выход из системы
    logout() {
        localStorage.removeItem('authToken');
        localStorage.removeItem('currentUser');
        window.location.href = 'auth.html';
    }
}

// Инициализация при загрузке страницы
$(document).ready(() => {
    new DashboardManager();
});
