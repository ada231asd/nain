/**
 * Менеджер пользователей для админ панели
 */
class UsersManager {
    constructor(apiBase, showNotification) {
        this.API_BASE = apiBase;
        this.showNotification = showNotification;
        this.usersCache = null;
        this.usersCacheTime = 0;
        this.CACHE_DURATION = 30000; // 30 секунд
    }

    // Загрузка пользователей
    async loadUsers() {
        $('#usersLoading').show();
        $('.users-table').hide();
        $('#noUsers').hide();
        $('.users-table').empty();

        try {
            const users = await this.getUsers();
            this.displayUsers(users);
            $('#usersLoading').hide();
        } catch (error) {
            $('#usersLoading').hide();
            console.error('Ошибка загрузки пользователей:', error);
            this.showNotification('Ошибка загрузки пользователей: ' + error.message, 'error');
        }
    }

    // Получение пользователей с кэшированием
    async getUsers() {
        const now = Date.now();
        
        // Проверяем кэш
        if (this.usersCache && (now - this.usersCacheTime) < this.CACHE_DURATION) {
            return this.usersCache;
        }
        
        const token = localStorage.getItem('authToken');
        
        if (!token) {
            throw new Error('Токен авторизации не найден');
        }
        
        try {
            // Получаем всех пользователей и роли параллельно с таймаутами
            const [usersResponse, rolesResponse, groupsResponse] = await Promise.allSettled([
                $.ajax({
                    url: `${this.API_BASE}/api/users`,
                    method: 'GET',
                    headers: { 'Authorization': `Bearer ${token}` },
                    timeout: 10000 // 10 секунд таймаут для пользователей
                }),
                $.ajax({
                    url: `${this.API_BASE}/api/user-roles`,
                    method: 'GET',
                    headers: { 'Authorization': `Bearer ${token}` },
                    timeout: 5000 // 5 секунд таймаут для ролей
                }),
                $.ajax({
                    url: `${this.API_BASE}/api/org-units`,
                    method: 'GET',
                    headers: { 'Authorization': `Bearer ${token}` },
                    timeout: 5000 // 5 секунд таймаут для групп
                })
            ]);

            const users = usersResponse.status === 'fulfilled' ? (usersResponse.value.data || []) : [];
            const roles = rolesResponse.status === 'fulfilled' ? (rolesResponse.value.data || []) : [];
            const groups = groupsResponse.status === 'fulfilled' ? (groupsResponse.value.data || []) : [];

            // Объединяем данные пользователей с ролями и группами
            const enrichedUsers = users.map(user => {
                // Роль уже приходит из API в поле user.role
                // Если роль не указана, устанавливаем по умолчанию
                if (!user.role) {
                    user.role = 'user';
                }

                // Находим группу пользователя по parent_org_unit_id
                const userGroup = groups.find(group => group.org_unit_id === user.parent_org_unit_id);
                if (userGroup) {
                    user.group_name = userGroup.name;
                    user.group_type = userGroup.unit_type;
                } else {
                    user.group_name = 'Не назначена';
                    user.group_type = '';
                }

                return user;
            });

            // Кэшируем результат
            this.usersCache = enrichedUsers;
            this.usersCacheTime = now;

            return enrichedUsers;
        } catch (error) {
            console.error('Ошибка загрузки пользователей:', error);
            throw error;
        }
    }

    // Отображение пользователей
    displayUsers(users) {
        if (!users || users.length === 0) {
            $('#noUsers').show();
            $('.users-table').hide();
            return;
        }

        // Отображаем всех пользователей включая service_admin
        const table = this.createUsersTable(users);
        $('.users-table').html(table).show();
        $('#noUsers').hide();
    }

    // Создание таблицы пользователей
    createUsersTable(users) {
        let table = `
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>ФИО</th>
                        <th>Телефон</th>
                        <th>Email</th>
                        <th>Роль</th>
                        <th>Статус</th>
                        <th>Группа</th>
                        <th>Последний вход</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
        `;

        users.forEach(user => {
            const roleText = this.getRoleName(user.role);
            const statusText = this.getStatusName(user.статус || user.status);
            const lastLogin = user.last_login_at ? new Date(user.last_login_at).toLocaleString() : 'Никогда';
            
            // Проверяем доступность adminManager при создании кнопки
            const adminManagerExists = !!window.adminManager;
            console.log(`👤 UsersManager: Создаем кнопки для пользователя ${user.user_id}, adminManager существует:`, adminManagerExists);
            if (!adminManagerExists) {
                console.error('❌ UsersManager: adminManager не найден при создании кнопки!');
                console.log('Доступные объекты в window:', Object.keys(window).filter(key => key.includes('admin')));
            }
            
            table += `
                <tr>
                    <td>${user.user_id}</td>
                    <td>${user.fio || 'Не указано'}</td>
                    <td>${user.phone_e164 || 'Не указан'}</td>
                    <td>${user.email || 'Не указан'}</td>
                    <td>${roleText}</td>
                    <td>${statusText}</td>
                    <td>${user.group_name} ${user.group_type ? `(${user.group_type})` : ''}</td>
                    <td>${lastLogin}</td>
                    <td>
                        <button class="action-btn primary" onclick="adminManager.editUser(${user.user_id})">Редактировать</button>
                        ${(user.статус || user.status) === 'pending' ? 
                            `<button class="action-btn success" onclick="adminManager.approveUser(${user.user_id})">Одобрить</button>
                             <button class="action-btn danger" onclick="adminManager.rejectUser(${user.user_id})">Отклонить</button>` :
                            ''
                        }
                        <button class="action-btn danger delete-user-btn" onclick="adminManager.deleteUser(${user.user_id})" title="Удалить пользователя" data-user-id="${user.user_id}">Удалить</button>
                    </td>
                </tr>
            `;
        });

        table += `
                </tbody>
            </table>
        `;

        // Добавляем jQuery обработчики для стилизации кнопок удаления
        setTimeout(() => {
            this.styleDeleteButtons();
        }, 100);

        return table;
    }

    // Фильтрация пользователей
    async filterUsers() {
        const searchTerm = $('#userSearch').val().toLowerCase();
        const roleFilter = $('#userRoleFilter').val();
        const statusFilter = $('#userStatusFilter').val();
        
        // Показываем индикатор загрузки
        $('#usersLoading').show();
        $('.users-table').hide();
        $('#noUsers').hide();
        
        try {
            // Загружаем пользователей с сервера
            const users = await this.getUsers();
            
            // Если все фильтры пустые, показываем всех пользователей
            if (!searchTerm && !roleFilter && !statusFilter) {
                this.displayUsers(users);
                $('#usersLoading').hide();
                return;
            }
            
            // Фильтруем данные на клиенте
            let filteredUsers = users;
            
            // Фильтр по поиску
            if (searchTerm) {
                filteredUsers = filteredUsers.filter(user => 
                    user.fio.toLowerCase().includes(searchTerm) ||
                    user.email.toLowerCase().includes(searchTerm) ||
                    user.phone_e164.includes(searchTerm)
                );
            }
            
            // Фильтр по роли
            if (roleFilter) {
                filteredUsers = filteredUsers.filter(user => 
                    user.role === roleFilter
                );
            }
            
            // Фильтр по статусу
            if (statusFilter) {
                filteredUsers = filteredUsers.filter(user => 
                    (user.статус || user.status) === statusFilter
                );
            }
            
            // Отображаем отфильтрованные данные
            this.displayUsers(filteredUsers);
            $('#usersLoading').hide();
            
        } catch (error) {
            $('#usersLoading').hide();
            console.error('Ошибка фильтрации пользователей:', error);
            this.showNotification('Ошибка фильтрации пользователей', 'error');
        }
    }

    // Очистка кэша пользователей
    clearUsersCache() {
        this.usersCache = null;
        this.usersCacheTime = 0;
    }


    // Универсальная функция для API запросов (как в api_test_frontend.html)
    async apiRequest(url, method = 'GET', data = null, headers = {}) {
        const token = localStorage.getItem('authToken');
        console.log('🌐 UsersManager: API запрос:', method, this.API_BASE + url);
        console.log('🔑 UsersManager: Токен:', token ? 'есть' : 'нет');
        
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                ...(token && { 'Authorization': `Bearer ${token}` }),
                ...headers
            }
        };
        
        if (data) {
            options.body = JSON.stringify(data);
        }
        
        console.log('📤 UsersManager: Опции запроса:', options);
        
        try {
            const response = await fetch(this.API_BASE + url, options);
            console.log('📥 UsersManager: Ответ сервера:', response.status, response.statusText);
            
            const result = await response.json();
            console.log('📊 UsersManager: Данные ответа:', result);
            
            return {
                success: response.ok,
                status: response.status,
                data: result
            };
        } catch (error) {
            console.error('❌ UsersManager: Ошибка API запроса:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Получение названия роли
    getRoleName(role) {
        const roleMap = {
            'service_admin': 'Админ сервиса',
            'group_admin': 'Админ группы',
            'subgroup_admin': 'Админ подгруппы',
            'user': 'Пользователь'
        };
        return roleMap[role] || 'Не назначена';
    }

    // Получение названия статуса
    getStatusName(status) {
        const statusMap = {
            'active': 'Активен',
            'pending': 'Ожидает',
            'blocked': 'Заблокирован',
            'inactive': 'Неактивен'
        };
        return statusMap[status] || 'Неизвестно';
    }

    // Красивый диалог подтверждения удаления с jQuery
    showDeleteConfirmation(userId) {
        return new Promise((resolve) => {
            // Создаем модальное окно
            const modalHtml = `
                <div id="deleteConfirmModal" class="delete-modal-overlay">
                    <div class="delete-modal-content">
                        <div class="delete-modal-header">
                            <h3>Подтверждение удаления</h3>
                        </div>
                        <div class="delete-modal-body">
                            <p>Вы уверены, что хотите удалить пользователя с ID <strong>${userId}</strong>?</p>
                            <p class="warning-text">Это действие нельзя отменить!</p>
                        </div>
                        <div class="delete-modal-footer">
                            <button class="btn btn-cancel" id="cancelDelete">Отмена</button>
                            <button class="btn btn-danger" id="confirmDelete">Удалить</button>
                        </div>
                    </div>
                </div>
            `;
            
            // Добавляем стили для модального окна
            const modalStyles = `
                <style>
                .delete-modal-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0, 0, 0, 0.5);
                    z-index: 9999;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                }
                .delete-modal-content {
                    background: white;
                    border-radius: 8px;
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
                    max-width: 400px;
                    width: 90%;
                    animation: modalSlideIn 0.3s ease;
                }
                .delete-modal-header {
                    padding: 20px 20px 0;
                    border-bottom: 1px solid #eee;
                }
                .delete-modal-header h3 {
                    margin: 0 0 15px;
                    color: #333;
                    font-size: 18px;
                }
                .delete-modal-body {
                    padding: 20px;
                }
                .delete-modal-body p {
                    margin: 0 0 10px;
                    color: #666;
                    line-height: 1.5;
                }
                .warning-text {
                    color: #dc3545;
                    font-weight: bold;
                }
                .delete-modal-footer {
                    padding: 15px 20px 20px;
                    text-align: right;
                    border-top: 1px solid #eee;
                }
                .btn {
                    padding: 8px 16px;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                    margin-left: 10px;
                    transition: all 0.2s ease;
                }
                .btn-cancel {
                    background: #6c757d;
                    color: white;
                }
                .btn-cancel:hover {
                    background: #5a6268;
                }
                .btn-danger {
                    background: #dc3545;
                    color: white;
                }
                .btn-danger:hover {
                    background: #c82333;
                }
                @keyframes modalSlideIn {
                    from {
                        opacity: 0;
                        transform: translateY(-20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
                </style>
            `;
            
            // Добавляем стили и модальное окно
            $('head').append(modalStyles);
            $('body').append(modalHtml);
            
            const $modal = $('#deleteConfirmModal');
            
            // Обработчики событий
            $('#cancelDelete').on('click', () => {
                $modal.remove();
                resolve(false);
            });
            
            $('#confirmDelete').on('click', () => {
                $modal.remove();
                resolve(true);
            });
            
            // Закрытие по клику вне модального окна
            $modal.on('click', (e) => {
                if (e.target === $modal[0]) {
                    $modal.remove();
                    resolve(false);
                }
            });
            
            // Закрытие по Escape
            $(document).on('keydown.deleteModal', (e) => {
                if (e.key === 'Escape') {
                    $modal.remove();
                    $(document).off('keydown.deleteModal');
                    resolve(false);
                }
            });
        });
    }

    // Стилизация кнопок удаления с помощью jQuery
    styleDeleteButtons() {
        $('.delete-user-btn').each(function() {
            const $btn = $(this);
            
            // Добавляем дополнительные стили
            $btn.css({
                'background-color': '#dc3545',
                'color': 'white',
                'border': '1px solid #dc3545',
                'padding': '6px 12px',
                'border-radius': '4px',
                'cursor': 'pointer',
                'font-size': '12px',
                'transition': 'all 0.2s ease',
                'margin-left': '5px'
            });
            
            // Эффекты при наведении
            $btn.hover(
                function() {
                    $(this).css({
                        'background-color': '#c82333',
                        'border-color': '#bd2130',
                        'transform': 'translateY(-1px)',
                        'box-shadow': '0 2px 4px rgba(0,0,0,0.2)'
                    });
                },
                function() {
                    $(this).css({
                        'background-color': '#dc3545',
                        'border-color': '#dc3545',
                        'transform': 'translateY(0)',
                        'box-shadow': 'none'
                    });
                }
            );
            
            // Эффект при нажатии
            $btn.mousedown(function() {
                $(this).css({
                    'transform': 'translateY(1px)',
                    'box-shadow': 'inset 0 1px 2px rgba(0,0,0,0.2)'
                });
            });
            
            $btn.mouseup(function() {
                $(this).css({
                    'transform': 'translateY(0)',
                    'box-shadow': 'none'
                });
            });
        });
    }

    // Удаление пользователя (по примеру из api_test_frontend.html)
    async deleteUser(userId) {
        // Показываем красивый диалог подтверждения с jQuery
        const confirmed = await this.showDeleteConfirmation(userId);
        
        if (!confirmed) {
            return;
        }

        try {
            console.log(`UsersManager: Удаляем пользователя с ID ${userId}`);
            
            const result = await this.apiRequest(`/api/users/${userId}`, 'DELETE');
            
            if (result.success) {
                console.log('UsersManager: Пользователь успешно удален');
                this.showNotification('Пользователь успешно удален', 'success');
                
                // Очищаем кэш и перезагружаем список пользователей
                this.clearUsersCache();
                await this.loadUsers();
            } else {
                console.error('UsersManager: Ошибка удаления пользователя:', result.error || result.data);
                this.showNotification(`Ошибка удаления пользователя: ${result.error || JSON.stringify(result.data)}`, 'error');
            }
        } catch (error) {
            console.error('UsersManager: Исключение при удалении пользователя:', error);
            this.showNotification(`Ошибка удаления пользователя: ${error.message}`, 'error');
        }
    }
}
