/**
 * Расширенный модуль админ панели ПО "Заряд"
 */
class AdminFullManager {
    constructor() {
        this.API_BASE = 'http://localhost:8000';
        this.currentUser = null;
        this.currentSection = 'dashboard';
        this.usersManager = new UsersManager(this.API_BASE, this.showNotification.bind(this));
        this.stationsManager = new StationsManager(this.API_BASE, this.showNotification.bind(this));
        this.groupsManager = new GroupsManager(this.API_BASE, this.showNotification.bind(this));
    }

    init() {
        this.bindEvents();
        this.checkAuth();
        this.startRealTimeUpdates();
        
        // Инициализируем модальные окна групп
        this.groupsManager.initModals();
        
        // Панель управления загрузится автоматически в $(document).ready
    }
    
    // Запуск обновлений в реальном времени
    startRealTimeUpdates() {
        console.log('⏰ AdminFullManager: Запускаем обновления в реальном времени');
        
        // Обновляем данные каждые 30 секунд
        setInterval(() => {
            console.log('⏰ AdminFullManager: setInterval сработал, текущий раздел:', this.currentSection);
            if (this.currentSection === 'dashboard') {
                console.log('📊 AdminFullManager: Обновляем dashboard');
                this.loadDashboard();
            } else if (this.currentSection === 'users') {
                console.log('👥 AdminFullManager: Обновляем users');
                this.loadUsers();
            }
        }, 30000);
        
        // Обновляем данные при переключении вкладок
        $(document).on('visibilitychange', () => {
            console.log('👁️ AdminFullManager: visibilitychange сработал, документ скрыт:', document.hidden);
            if (!document.hidden) {
                console.log('👁️ AdminFullManager: Документ стал видимым, текущий раздел:', this.currentSection);
                if (this.currentSection === 'dashboard') {
                    console.log('📊 AdminFullManager: Обновляем dashboard при переключении вкладки');
                    this.loadDashboard();
                } else if (this.currentSection === 'users') {
                    console.log('👥 AdminFullManager: Обновляем users при переключении вкладки');
                    this.loadUsers();
                }
            }
        });
    }

    bindEvents() {
        // Навигация по разделам
        $('.nav-tab').on('click', (e) => {
            const section = $(e.currentTarget).data('section');
            this.switchSection(section);
        });

        // Выход из системы
        $('#logoutBtn').on('click', () => {
            this.logout();
        });



        // Кнопки действий
        $('#addUserBtn').on('click', () => this.showAddUserModal());
        $('#addStationBtn').on('click', () => this.showAddStationModal());
        $('#searchLogsBtn').on('click', () => this.searchLogs());
        
        // Кнопки групп
        $('#addGroupBtn').on('click', () => this.showAddGroupModal());
        $('#addSubgroupBtn').on('click', () => this.showAddSubgroupModal());

        // Фильтры
        $('#userSearch, #userRoleFilter, #userStatusFilter').on('input change', () => this.filterUsers());
        $('#stationSearch, #stationGroupFilter, #stationStatusFilter').on('input change', () => this.filterStations());
        $('#resetStationFilters').on('click', () => this.resetStationFilters());
        $('#powerbankSearch, #powerbankStatusFilter').on('input change', () => this.filterPowerbanks());
        $('#groupSearch, #groupTypeFilter').on('input change', () => this.filterGroups());
        
        // Модальное окно редактирования пользователя
        $('#cancelEditUser').on('click', () => this.closeEditUserModal());
        $('#editUserModal .modal-close').on('click', () => this.closeEditUserModal());
        $('#saveEditUser').on('click', () => this.saveUserChanges());
        
        // Модальное окно одобрения станции
        $('#cancelApproveStation').on('click', () => this.closeApproveStationModal());
        $('#approveStationModal .modal-close').on('click', () => this.closeApproveStationModal());
        $('#saveApproveStation').on('click', () => this.saveStationApproval());
        
        
        
        // Модальные окна групп
        $('#cancelAddGroup, #cancelAddSubgroup, #cancelEditGroup').on('click', () => this.closeGroupModals());
        $('#addGroupModal .modal-close, #addSubgroupModal .modal-close, #editGroupModal .modal-close').on('click', () => this.closeGroupModals());
        $('#saveAddGroup').on('click', () => this.saveAddGroup());
        $('#saveAddSubgroup').on('click', () => this.saveAddSubgroup());
        $('#saveEditGroup').on('click', () => this.saveEditGroup());
        
        // Закрытие модальных окон по клику вне области
        $('#addGroupModal, #addSubgroupModal, #editGroupModal').on('click', (e) => {
            if (e.target.id === 'addGroupModal' || e.target.id === 'addSubgroupModal' || e.target.id === 'editGroupModal') {
                this.closeGroupModals();
            }
        });
        
        
        
        // Модальное окно просмотра станции
        $('#closeViewStation').on('click', () => this.closeViewStationModal());
        $('#viewStationModal .modal-close').on('click', () => this.closeViewStationModal());
        
        // Модальное окно редактирования станции
        $('#cancelEditStation').on('click', () => this.closeEditStationModal());
        $('#editStationModal .modal-close').on('click', () => this.closeEditStationModal());
        $('#saveEditStation').on('click', () => this.saveStationChanges());
        
        // Модальное окно одобрения аккумулятора
        $('#cancelApprovePowerbank').on('click', () => this.closeApprovePowerbankModal());
        $('#approvePowerbankModal .modal-close').on('click', () => this.closeApprovePowerbankModal());
        $('#saveApprovePowerbank').on('click', () => this.savePowerbankApproval());
        
        // Модальное окно редактирования аккумулятора
        $('#cancelEditPowerbank').on('click', () => this.closeEditPowerbankModal());
        $('#editPowerbankModal .modal-close').on('click', () => this.closeEditPowerbankModal());
        $('#saveEditPowerbank').on('click', () => this.savePowerbankChanges());
        
        // Закрытие модальных окон по клику вне их
        $('#editUserModal').on('click', (e) => {
            if (e.target.id === 'editUserModal') {
                this.closeEditUserModal();
            }
        });
        
        $('#approveStationModal').on('click', (e) => {
            if (e.target.id === 'approveStationModal') {
                this.closeApproveStationModal();
            }
        });
        
        $('#viewStationModal').on('click', (e) => {
            if (e.target.id === 'viewStationModal') {
                this.closeViewStationModal();
            }
        });
        
        $('#editStationModal').on('click', (e) => {
            if (e.target.id === 'editStationModal') {
                this.closeEditStationModal();
            }
        });
        
        $('#approvePowerbankModal').on('click', (e) => {
            if (e.target.id === 'approvePowerbankModal') {
                this.closeApprovePowerbankModal();
            }
        });
        
        $('#editPowerbankModal').on('click', (e) => {
            if (e.target.id === 'editPowerbankModal') {
                this.closeEditPowerbankModal();
            }
        });
    }

    // Проверка авторизации
    async checkAuth() {
        const token = localStorage.getItem('authToken');
        if (!token) {
            window.location.href = 'auth.html';
            return;
        }

        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/api/auth/profile`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.data && response.data.user) {
                this.currentUser = response.data.user;
                
                // Получаем роль пользователя из отдельного API
                try {
                    const roleResponse = await $.ajax({
                        url: `${this.API_BASE}/api/user-roles`,
                        method: 'GET',
                        headers: { 'Authorization': `Bearer ${token}` }
                    });
                    
                    // Находим роль текущего пользователя
                    const userRole = roleResponse.data?.find(role => role.user_id === response.data.user.user_id);
                    if (userRole) {
                        this.currentUser.role = userRole.role;
                    }
                } catch (roleError) {
                    console.warn('Не удалось загрузить роль пользователя:', roleError);
                    // Используем роль по умолчанию
                    this.currentUser.role = this.currentUser.role || 'user';
                }
                
                this.displayUserInfo(this.currentUser);
                
                // Проверяем права доступа
                if (!this.isAdmin(this.currentUser)) {
                    this.showNotification('У вас нет прав доступа к админ панели', 'error');
                    setTimeout(() => {
                        window.location.href = 'auth.html';
                    }, 2000);
                    return;
                }
                
                // Панель управления загрузится автоматически в $(document).ready
            }
        } catch (error) {
            console.error('Ошибка проверки авторизации:', error);
            localStorage.removeItem('authToken');
            localStorage.removeItem('currentUser');
            window.location.href = 'auth.html';
        }
    }

    // Проверка роли администратора
    isAdmin(user) {
        return user && ['service_admin'].includes(user.role);
    }

    // Отображение информации о пользователе
    displayUserInfo(user) {
        const userName = user.fio || user.phone_e164 || 'Пользователь';
        const userRole = this.getRoleName(user.role);
        $('#userName').text(`${userName} (${userRole})`);
        
        // Убираем индикатор загрузки
        $('#userName').removeClass('loading');
    }
    
    // Получение названия роли
    getRoleName(role) {
        const roleNames = {
            'service_admin': 'Админ сервиса',
            'user': 'Пользователь'
        };
        return roleNames[role] || role || 'Пользователь';
    }

    // Переключение разделов
    switchSection(section) {
        console.log('🔄 AdminFullManager: Переключаемся на раздел:', section);
        
        $('.nav-tab').removeClass('active');
        $(`.nav-tab[data-section="${section}"]`).addClass('active');
        
        $('.admin-section').removeClass('active');
        $(`#${section}-section`).addClass('active');
        
        this.currentSection = section;
        
        // Загружаем данные для раздела асинхронно
        console.log('📡 AdminFullManager: Загружаем данные для раздела:', section);
        this.loadSectionData(section);
    }
    
    // Асинхронная загрузка данных раздела
    async loadSectionData(section) {
        console.log('📡 AdminFullManager: loadSectionData вызвана для раздела:', section);
        try {
            switch(section) {
                case 'dashboard':
                    console.log('📊 AdminFullManager: Загружаем dashboard');
                    await this.loadDashboard();
                    break;
                case 'users':
                    console.log('👥 AdminFullManager: Загружаем users');
                    await this.loadUsers();
                    break;
                case 'stations':
                    console.log('🏭 AdminFullManager: Загружаем stations');
                    await this.loadStations();
                    break;
                case 'powerbanks':
                    console.log('🔋 AdminFullManager: Загружаем powerbanks');
                    await this.loadPowerbanks();
                    break;
                case 'groups':
                    console.log('🏢 AdminFullManager: Загружаем groups');
                    await this.loadGroups();
                    break;
                case 'logs':
                    console.log('📝 AdminFullManager: Загружаем logs');
                    this.loadLogs();
                    break;
            }
            console.log('✅ AdminFullManager: loadSectionData завершена для раздела:', section);
        } catch (error) {
            console.error('❌ AdminFullManager: Ошибка загрузки раздела:', section, error);
            this.showNotification('Ошибка загрузки раздела', 'error');
        }
    }



    // Загрузка панели управления
    async loadDashboard() {
        try {
            // Показываем индикатор загрузки
            $('#totalUsers, #pendingUsers, #activeUsers, #totalStations, #inactiveStations, #pendingStations, #totalPowerbanks, #brokenPowerbanks, #pendingPowerbanks').text('...');
            
            // Загружаем статистику асинхронно
            const stats = await this.getDashboardStats();
            this.displayDashboardStats(stats);
            
            // Убираем индикатор загрузки только после успешной загрузки
            // Не показываем уведомление для автоматической загрузки
        } catch (error) {
            console.error('Ошибка загрузки статистики:', error);
            this.showNotification('Ошибка загрузки статистики', 'error');
        }
    }

    // Получение статистики - асинхронная загрузка всех данных
    async getDashboardStats() {
        const token = localStorage.getItem('authToken');
        
        try {
            // Загружаем все данные параллельно
            const [pendingUsersResponse, allUsersResponse, stationsResponse, powerbanksResponse] = await Promise.allSettled([
                // Пользователи на подтверждение
                $.ajax({
                    url: `${this.API_BASE}/api/admin/pending-users`,
                    method: 'GET',
                    headers: { 'Authorization': `Bearer ${token}` }
                }),
                // Все пользователи
                $.ajax({
                    url: `${this.API_BASE}/api/users`,
                    method: 'GET',
                    headers: { 'Authorization': `Bearer ${token}` }
                }),
                // Станции
                $.ajax({
                    url: `${this.API_BASE}/api/stations`,
                    method: 'GET',
                    headers: { 'Authorization': `Bearer ${token}` }
                }),
                // Аккумуляторы
                $.ajax({
                    url: `${this.API_BASE}/api/powerbanks`,
                    method: 'GET',
                    headers: { 'Authorization': `Bearer ${token}` }
                }),
            ]);

            // Обрабатываем результаты
            const pendingUsers = pendingUsersResponse.status === 'fulfilled' && pendingUsersResponse.value.users ? 
                pendingUsersResponse.value.users.length : 0;
            
            const allUsers = allUsersResponse.status === 'fulfilled' && allUsersResponse.value.data ? 
                allUsersResponse.value.data : [];
            
            const totalUsers = allUsers.length;
            const activeUsers = allUsers.filter(u => u.status === 'active').length;
            const blockedUsers = allUsers.filter(u => u.status === 'blocked').length;
            
            const totalStations = stationsResponse.status === 'fulfilled' && stationsResponse.value.data ? 
                stationsResponse.value.data.length : 0;
            
            const inactiveStations = stationsResponse.status === 'fulfilled' && stationsResponse.value.data ? 
                stationsResponse.value.data.filter(s => s.status === 'inactive').length : 0;
            
            const pendingStations = stationsResponse.status === 'fulfilled' && stationsResponse.value.data ? 
                stationsResponse.value.data.filter(s => s.status === 'pending').length : 0;
            
            const totalPowerbanks = powerbanksResponse.status === 'fulfilled' && powerbanksResponse.value.data ? 
                powerbanksResponse.value.data.length : 0;
            
            const brokenPowerbanks = powerbanksResponse.status === 'fulfilled' && powerbanksResponse.value.data ? 
                powerbanksResponse.value.data.filter(p => p.status === 'user_reported_broken' || p.status === 'system_error').length : 0;
            
            const pendingPowerbanks = powerbanksResponse.status === 'fulfilled' && powerbanksResponse.value.data ? 
                powerbanksResponse.value.data.filter(p => p.status === 'pending').length : 0;
            


            return {
                totalUsers: totalUsers,
                pendingUsers: pendingUsers,
                activeUsers: activeUsers,
                totalStations: totalStations,
                inactiveStations: inactiveStations,
                pendingStations: pendingStations,
                totalPowerbanks: totalPowerbanks,
                brokenPowerbanks: brokenPowerbanks,
                pendingPowerbanks: pendingPowerbanks,
            };
        } catch (error) {
            console.error('Ошибка загрузки статистики:', error);
            this.showNotification('Ошибка загрузки статистики', 'error');
            return {
                totalUsers: 0,
                pendingUsers: 0,
                activeUsers: 0,
                totalStations: 0,
                inactiveStations: 0,
                pendingStations: 0,
                totalPowerbanks: 0,
                brokenPowerbanks: 0,
                pendingPowerbanks: 0,
            };
        }
    }

    // Отображение статистики
    displayDashboardStats(stats) {
        $('#totalUsers').text(stats.totalUsers || 0);
        $('#pendingUsers').text(stats.pendingUsers || 0);
        $('#activeUsers').text(stats.activeUsers || 0);
        $('#totalStations').text(stats.totalStations || 0);
        $('#inactiveStations').text(stats.inactiveStations || 0);
        $('#pendingStations').text(stats.pendingStations || 0);
        $('#totalPowerbanks').text(stats.totalPowerbanks || 0);
        $('#brokenPowerbanks').text(stats.brokenPowerbanks || 0);
        $('#pendingPowerbanks').text(stats.pendingPowerbanks || 0);
        
        // Загружаем последние действия
        this.loadRecentActions();
    }
    
    // Загрузка последних действий
    async loadRecentActions() {
        try {
            const token = localStorage.getItem('authToken');
            
            // Загружаем последние действия из заказов
            const ordersResponse = await $.ajax({
                url: `${this.API_BASE}/api/orders`,
                method: 'GET',
                headers: { 'Authorization': `Bearer ${token}` },
                data: { limit: 5 }
            });
            
            if (ordersResponse.data && ordersResponse.data.length > 0) {
                let actionsHtml = '';
                ordersResponse.data.forEach(order => {
                    const time = new Date(order.timestamp).toLocaleString('ru-RU');
                    const action = order.status === 'borrow' ? 'Выдача' : 'Возврат';
                    actionsHtml += `
                        <div class="action-item">
                            <div>${action} повербанка #${order.powerbank_id}</div>
                            <div class="action-time">${time}</div>
                        </div>
                    `;
                });
                $('#recentActions').html(actionsHtml);
            } else {
                $('#recentActions').html('<div class="action-item">Нет недавних действий</div>');
            }
        } catch (error) {
            console.error('Ошибка загрузки последних действий:', error);
            $('#recentActions').html('<div class="action-item">Ошибка загрузки</div>');
        }
    }

    // Система уведомлений
    showNotification(message, type = 'info') {
        const notification = $(`
            <div class="notification notification-${type}">
                <span class="notification-message">${message}</span>
                <button class="notification-close">&times;</button>
            </div>
        `);
        
        // Добавляем в контейнер уведомлений
        if ($('#notifications').length === 0) {
            $('body').append('<div id="notifications"></div>');
        }
        
        $('#notifications').append(notification);
        
        // Автоматическое скрытие через 5 секунд
        setTimeout(() => {
            notification.fadeOut(300, function() {
                $(this).remove();
            });
        }, 5000);
        
        // Закрытие по клику
        notification.find('.notification-close').click(function() {
            notification.fadeOut(300, function() {
                $(this).remove();
            });
        });
    }

    // Загрузка пользователей
    async loadUsers() {
        await this.usersManager.loadUsers();
    }

    // Загрузка групп
    async loadGroups() {
        console.log('🏢 AdminFullManager: Загружаем группы');
        await this.groupsManager.loadGroups();
    }


    // Получение пользователей с кэшированием
    async getUsers() {
        return await this.usersManager.getUsers();
    }

    // Очистка кэша пользователей
    clearUsersCache() {
        this.usersManager.clearUsersCache();
    }

    // Отображение пользователей
    displayUsers(users) {
        this.usersManager.displayUsers(users);
    }

    // Создание таблицы пользователей
    createUsersTable(users) {
        return this.usersManager.createUsersTable(users);
    }

    // Загрузка станций
    async loadStations() {
        console.log('🔄 AdminFullManager: Делегируем загрузку станций в StationsManager');
        console.trace('AdminFullManager: loadStations вызвана из:');
        await this.stationsManager.loadStations();
        console.log('🏁 AdminFullManager: loadStations завершена');
    }

    // Получение станций
    async getStations() {
        console.log('🔄 AdminFullManager: Делегируем получение станций в StationsManager');
        return await this.stationsManager.getStations();
    }

    // Отображение станций
    displayStations(stations) {
        console.log('🖥️ AdminFullManager: Делегируем отображение станций в StationsManager');
        this.stationsManager.displayStations(stations);
    }

    // Загрузка аккумуляторов
    async loadPowerbanks() {
        $('#powerbanksLoading').show();
        $('.powerbanks-table').hide();
        $('#noPowerbanks').hide();
        $('.powerbanks-table').empty();

        try {
            const powerbanks = await this.getPowerbanks();
            this.displayPowerbanks(powerbanks);
            this.showNotification(`Загружено ${powerbanks.length} аккумуляторов`, 'success');
        } catch (error) {
            $('#powerbanksLoading').hide();
            console.error('Ошибка загрузки аккумуляторов:', error);
            this.showNotification('Ошибка загрузки аккумуляторов', 'error');
        }
    }

    // Получение аккумуляторов
    async getPowerbanks() {
        const token = localStorage.getItem('authToken');
        
        try {
            // Пытаемся получить аккумуляторы через API
            const response = await $.ajax({
                url: `${this.API_BASE}/api/powerbanks`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            return response.data || [];
        } catch (error) {
            console.error('Ошибка загрузки аккумуляторов:', error);
            // Возвращаем заглушку если API недоступен
            return [
                {
                    id: 1,
                    model: 'PowerBank Pro 10000',
                    status: 'available',
                    location: 'Станция №1',
                    battery: 85
                },
                {
                    id: 2,
                    model: 'PowerBank Pro 10000',
                    status: 'borrowed',
                    location: 'У пользователя',
                    battery: 45
                }
            ];
        }
    }

    // Отображение аккумуляторов
    displayPowerbanks(powerbanks) {
        $('#powerbanksLoading').hide();
        
        if (powerbanks.length === 0) {
            $('#noPowerbanks').show();
            $('.powerbanks-table').hide();
            return;
        }

        let table = `
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Серийный номер</th>
                        <th>Статус</th>
                        <th>Группа</th>
                        <th>Заряд (SOH)</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
        `;

        powerbanks.forEach(powerbank => {
            const statusText = powerbank.status === 'active' ? 'Активен' :
                              powerbank.status === 'user_reported_broken' ? 'Неисправен' :
                              powerbank.status === 'system_error' ? 'Ошибка системы' :
                              powerbank.status === 'written_off' ? 'Списан' :
                              powerbank.status === 'unknown' ? 'Неизвестно' :
                              powerbank.status === 'pending' ? 'Ожидает' : powerbank.status;
            
            const batteryColor = powerbank.soh > 50 ? 'green' : 
                                 powerbank.soh > 20 ? 'orange' : 'red';
            
            table += `
                <tr>
                    <td>${powerbank.id}</td>
                    <td>${powerbank.serial_number}</td>
                    <td><span class="status-badge status-${powerbank.status}">${statusText}</span></td>
                    <td>${powerbank.org_unit_id ? `Группа ${powerbank.org_unit_id}` : 'Не назначен'}</td>
                    <td><span style="color: ${batteryColor}">${powerbank.soh || 0}%</span></td>
                    <td>
                        ${powerbank.status === 'unknown' ? 
                            `<button class="action-btn success" onclick="adminManager.approvePowerbank(${powerbank.id})">Одобрить</button>` : 
                            `<button class="action-btn primary" onclick="adminManager.editPowerbank(${powerbank.id})">Редактировать</button>`
                        }
                        <button class="action-btn warning" onclick="adminManager.forceEjectPowerbank(${powerbank.id})">Принудительно извлечь</button>
                        <button class="action-btn danger" onclick="adminManager.deletePowerbank(${powerbank.id})">Удалить</button>
                    </td>
                </tr>
            `;
        });

        table += `
                </tbody>
            </table>
        `;

        $('.powerbanks-table').html(table).show();
        $('#noPowerbanks').hide();
    }



    // Загрузка логов
    loadLogs() {
        $('#logsContent').html(`
            <div class="empty-state">
                <div class="empty-state-icon">📋</div>
                <p>Выберите параметры для просмотра логов</p>
            </div>
        `);
    }

    // Фильтрация пользователей
    async filterUsers() {
        await this.usersManager.filterUsers();
    }

    // Фильтрация станций
    async filterStations() {
        console.log('🔍 AdminFullManager: Делегируем фильтрацию станций в StationsManager');
        await this.stationsManager.filterStations();
    }

    // Фильтрация групп
    async filterGroups() {
        console.log('🔍 AdminFullManager: Делегируем фильтрацию групп в GroupsManager');
        await this.groupsManager.filterGroups();
    }


    // Сброс фильтров станций
    async resetStationFilters() {
        console.log('🔄 AdminFullManager: Делегируем сброс фильтров станций в StationsManager');
        await this.stationsManager.resetStationFilters();
    }


    // Удаление станции
    async deleteStation(stationId) {
        console.log('🗑️ AdminFullManager: Делегируем удаление станции в StationsManager');
        await this.stationsManager.deleteStation(stationId);
    }

    // Фильтрация аккумуляторов
    async filterPowerbanks() {
        const searchTerm = $('#powerbankSearch').val().toLowerCase();
        const statusFilter = $('#powerbankStatusFilter').val();
        
        // Показываем индикатор загрузки
        $('#powerbanksLoading').show();
        $('.powerbanks-table').hide();
        $('#noPowerbanks').hide();
        
        try {
            // Загружаем повербанки с сервера
            const powerbanks = await this.getPowerbanks();
            
            // Если все фильтры пустые, показываем все повербанки
            if (!searchTerm && !statusFilter) {
                this.displayPowerbanks(powerbanks);
                $('#powerbanksLoading').hide();
                return;
            }
            
            // Фильтруем данные на клиенте
            let filteredPowerbanks = powerbanks;
            
            // Фильтр по поиску
            if (searchTerm) {
                filteredPowerbanks = filteredPowerbanks.filter(powerbank => 
                    powerbank.serial_number.toLowerCase().includes(searchTerm)
                );
            }
            
            // Фильтр по статусу
            if (statusFilter) {
                const statusMap = {
                    'Активен': 'active',
                    'Неисправен': 'user_reported_broken',
                    'Ошибка системы': 'system_error',
                    'Списан': 'written_off',
                    'Неизвестно': 'unknown',
                    'Ожидает': 'pending'
                };
                const expectedStatus = statusMap[statusFilter];
                filteredPowerbanks = filteredPowerbanks.filter(powerbank => 
                    powerbank.status === expectedStatus
                );
            }
            
            // Отображаем отфильтрованные данные
            this.displayPowerbanks(filteredPowerbanks);
            $('#powerbanksLoading').hide();
            
        } catch (error) {
            $('#powerbanksLoading').hide();
            console.error('Ошибка фильтрации повербанков:', error);
            this.showNotification('Ошибка фильтрации повербанков', 'error');
        }
    }

    // Подтверждение пользователя
    async approveUser(userId) {
        const token = localStorage.getItem('authToken');
        
        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/api/admin/approve-user`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({ user_id: userId })
            });
            
            // Проверяем успешность операции
            if (response && (response.success === true || response.status === 'success' || response.message)) {
                this.showNotification('Пользователь подтвержден', 'success');
                this.clearUsersCache();
                this.loadUsers();
            } else {
                // Если нет явного success, но и нет ошибки - считаем успешным
                this.showNotification('Пользователь подтвержден', 'success');
                this.clearUsersCache();
                this.loadUsers();
            }
        } catch (error) {
            console.error('Ошибка подтверждения пользователя:', error);
            
            // Проверяем, не подтвердился ли пользователь несмотря на ошибку
            if (error.status === 200 || error.responseText) {
                this.showNotification('Пользователь подтвержден', 'success');
                this.loadUsers();
            } else {
                this.showNotification('Ошибка подтверждения пользователя', 'error');
            }
        }
    }

    // Отклонение пользователя
    async rejectUser(userId) {
        const token = localStorage.getItem('authToken');
        
        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/api/admin/reject-user`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({ user_id: userId })
            });
            
            // Проверяем успешность операции
            if (response && (response.success === true || response.status === 'success' || response.message)) {
                this.showNotification('Пользователь отклонен', 'success');
                this.clearUsersCache();
                this.loadUsers();
            } else {
                // Если нет явного success, но и нет ошибки - считаем успешным
                this.showNotification('Пользователь отклонен', 'success');
                this.clearUsersCache();
                this.loadUsers();
            }
        } catch (error) {
            console.error('Ошибка отклонения пользователя:', error);
            
            // Проверяем, не отклонился ли пользователь несмотря на ошибку
            if (error.status === 200 || error.responseText) {
                this.showNotification('Пользователь отклонен', 'success');
                this.loadUsers();
            } else {
                this.showNotification('Ошибка отклонения пользователя', 'error');
            }
        }
    }

    // Удаление пользователя
    async deleteUser(userId) {
        // Делегируем вызов в usersManager
        await this.usersManager.deleteUser(userId);
    }

    // Редактирование группы
    async editGroup(groupId) {
        console.log('🏢 AdminFullManager: Редактирование группы', groupId);
        
        try {
            // Получаем данные группы
            const group = await this.groupsManager.getGroupById(groupId);
            
            if (!group) {
                this.showNotification('Группа не найдена', 'error');
                return;
            }
            
            // Заполняем форму данными группы
            $('#editGroupId').val(group.org_unit_id);
            $('#editGroupName').val(group.name || '');
            $('#editGroupType').val(group.unit_type || 'group');
            $('#editGroupAddress').val(group.adress || '');
            $('#editGroupLogo').val(group.logo_url || '');
            
            // Загружаем группы для выбора родительской
            await this.groupsManager.loadGroupsForSelect('#editParentGroup', groupId);
            
            // Устанавливаем текущую родительскую группу
            $('#editParentGroup').val(group.parent_org_unit_id || '');
            
            // Показываем/скрываем поле родительской группы в зависимости от типа
            if (group.unit_type === 'subgroup') {
                $('#editParentGroupField').show();
            } else {
                $('#editParentGroupField').hide();
            }
            
            // Добавляем обработчик изменения типа
            $('#editGroupType').off('change.editType').on('change.editType', function() {
                const type = $(this).val();
                if (type === 'subgroup') {
                    $('#editParentGroupField').show();
                } else {
                    $('#editParentGroupField').hide();
                    $('#editParentGroup').val('');
                }
            });
            
            // Показываем предварительный просмотр логотипа
            if (group.logo_url) {
                $('#editPreviewImage').attr('src', group.logo_url);
                $('#editLogoPreview').show();
            } else {
                $('#editLogoPreview').hide();
            }
            
            // Показываем модальное окно
            $('#editGroupModal').show();
            
        } catch (error) {
            console.error('Ошибка загрузки данных группы:', error);
            this.showNotification('Ошибка загрузки данных группы', 'error');
        }
    }

    // Удаление группы
    async deleteGroup(groupId) {
        console.log('🏢 AdminFullManager: Удаление группы', groupId);
        await this.groupsManager.deleteGroup(groupId);
    }

    // Показать модальное окно создания группы
    async showAddGroupModal() {
        console.log('🏢 AdminFullManager: Показываем модальное окно создания группы');
        
        // Очищаем форму
        $('#addGroupForm')[0].reset();
        $('#logoPreview').hide();
        
        // Устанавливаем тип "группа"
        $('#groupType').val('group');
        
        // Скрываем поле родительской группы для обычных групп
        $('#parentGroupField').hide();
        
        // Добавляем обработчик изменения типа
        $('#groupType').off('change.groupType').on('change.groupType', function() {
            const type = $(this).val();
            if (type === 'subgroup') {
                $('#parentGroupField').show();
            } else {
                $('#parentGroupField').hide();
                $('#parentGroup').val('');
            }
        });
        
        // Показываем модальное окно
        $('#addGroupModal').show();
    }

    // Показать модальное окно создания подгруппы
    async showAddSubgroupModal() {
        console.log('🏢 AdminFullManager: Показываем модальное окно создания подгруппы');
        
        // Очищаем форму
        $('#addSubgroupForm')[0].reset();
        $('#subgroupLogoPreview').hide();
        
        // Загружаем группы для выбора родительской
        await this.groupsManager.loadGroupsForSelect('#subgroupParentGroup');
        
        // Показываем модальное окно
        $('#addSubgroupModal').show();
    }

    // Закрытие модальных окон групп
    closeGroupModals() {
        $('#addGroupModal, #addSubgroupModal, #editGroupModal').hide();
        $('#addGroupForm, #addSubgroupForm, #editGroupForm')[0].reset();
        $('#logoPreview, #subgroupLogoPreview, #editLogoPreview').hide();
    }

    // Сохранение новой группы
    async saveAddGroup() {
        try {
            const formData = {
                name: $('#groupName').val(),
                unit_type: $('#groupType').val(),
                parent_org_unit_id: $('#parentGroup').val() || null,
                adress: $('#groupAddress').val() || null,
                logo_url: $('#groupLogo').val() || null
            };
            
            // Валидация
            if (!formData.name) {
                this.showNotification('Введите название группы', 'error');
                return;
            }
            
            const result = await this.groupsManager.createGroup(formData);
            
            if (result) {
                this.closeGroupModals();
                await this.loadGroups();
            }
        } catch (error) {
            console.error('Ошибка создания группы:', error);
            this.showNotification('Ошибка создания группы: ' + error.message, 'error');
        }
    }

    // Сохранение новой подгруппы
    async saveAddSubgroup() {
        try {
            const formData = {
                name: $('#subgroupName').val(),
                unit_type: 'subgroup',
                parent_org_unit_id: $('#subgroupParentGroup').val() || null,
                adress: $('#subgroupAddress').val() || null,
                logo_url: $('#subgroupLogo').val() || null
            };
            
            // Валидация
            if (!formData.name) {
                this.showNotification('Введите название подгруппы', 'error');
                return;
            }
            
            if (!formData.parent_org_unit_id) {
                this.showNotification('Выберите родительскую группу', 'error');
                return;
            }
            
            const result = await this.groupsManager.createGroup(formData);
            
            if (result) {
                this.closeGroupModals();
                await this.loadGroups();
            }
        } catch (error) {
            console.error('Ошибка создания подгруппы:', error);
            this.showNotification('Ошибка создания подгруппы: ' + error.message, 'error');
        }
    }

    // Сохранение изменений группы
    async saveEditGroup() {
        try {
            const groupId = $('#editGroupId').val();
            const formData = {
                name: $('#editGroupName').val(),
                unit_type: $('#editGroupType').val(),
                parent_org_unit_id: $('#editParentGroup').val() || null,
                adress: $('#editGroupAddress').val() || null,
                logo_url: $('#editGroupLogo').val() || null
            };
            
            // Валидация
            if (!formData.name) {
                this.showNotification('Введите название группы', 'error');
                return;
            }
            
            const result = await this.groupsManager.updateGroup(groupId, formData);
            
            if (result) {
                this.closeGroupModals();
                await this.loadGroups();
            }
        } catch (error) {
            console.error('Ошибка обновления группы:', error);
            this.showNotification('Ошибка обновления группы: ' + error.message, 'error');
        }
    }


    // Редактирование пользователя
    async editUser(userId) {
        try {
            // Получаем данные пользователя
            const users = await this.getUsers();
            const user = users.find(u => u.user_id == userId);
            
            if (!user) {
                this.showNotification('Пользователь не найден', 'error');
                return;
            }
            
            // Заполняем форму данными пользователя
            $('#editUserId').val(user.user_id);
            $('#editUserFio').val(user.fio || '');
            $('#editUserPhone').val(user.phone_e164 || '');
            $('#editUserEmail').val(user.email || '');
            $('#editUserRole').val(user.role || 'user');
            $('#editUserStatus').val(user.статус || 'pending');
            
            // Загружаем все группы и подгруппы для выбора
            await this.groupsManager.loadAllOrgUnitsForSelect('#editUserGroup');
            
            // Устанавливаем текущую группу
            $('#editUserGroup').val(user.parent_org_unit_id || '');
            
            // Показываем модальное окно
            $('#editUserModal').show();
            
        } catch (error) {
            console.error('Ошибка загрузки данных пользователя:', error);
            this.showNotification('Ошибка загрузки данных пользователя', 'error');
        }
    }




    // Сохранение изменений пользователя
    async saveUserChanges() {
        try {
            const formData = {
                fio: $('#editUserFio').val(),
                phone_e164: $('#editUserPhone').val(),
                email: $('#editUserEmail').val(),
                role: $('#editUserRole').val(),
                parent_org_unit_id: $('#editUserGroup').val() || '',
                статус: $('#editUserStatus').val()
            };
            
            // Валидация обязательных полей
            if (!formData.fio) {
                this.showNotification('Введите ФИО пользователя', 'error');
                return;
            }
            if (!formData.phone_e164) {
                this.showNotification('Введите телефон пользователя', 'error');
                return;
            }
            if (!formData.email) {
                this.showNotification('Введите email пользователя', 'error');
                return;
            }
            if (!formData.role) {
                this.showNotification('Выберите роль пользователя', 'error');
                return;
            }
            if (!formData.статус) {
                this.showNotification('Выберите статус пользователя', 'error');
                return;
            }
            
            const token = localStorage.getItem('authToken');
            
            console.log('🔍 AdminFullManager: Сохраняем пользователя с данными:', formData);
            
            // Обновляем данные пользователя одним запросом
            const response = await $.ajax({
                url: `${this.API_BASE}/api/users/${$('#editUserId').val()}`,
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify(formData)
            });
            
            console.log('📡 AdminFullManager: Ответ от API обновления пользователя:', response);
            
            if (response.success) {
                this.showNotification('Пользователь успешно обновлен', 'success');
                this.closeEditUserModal();
                
                // Очищаем кэш и перезагружаем данные
                this.clearUsersCache();
                this.loadUsers();
            } else {
                this.showNotification(response.error || 'Ошибка обновления пользователя', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка сохранения пользователя:', error);
            this.showNotification('Ошибка сохранения пользователя', 'error');
        }
    }
    
    // Обновление роли пользователя
    async updateUserRole(userId, role) {
        try {
            const token = localStorage.getItem('authToken');
            
            // Сначала удаляем старую роль
            await $.ajax({
                url: `${this.API_BASE}/api/user-roles`,
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` },
                data: { user_id: userId }
            });
            
            // Добавляем новую роль
            await $.ajax({
                url: `${this.API_BASE}/api/user-roles`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    user_id: userId,
                    role: role
                })
            });
            
        } catch (error) {
            console.error('Ошибка обновления роли:', error);
            throw error;
        }
    }
    
    // Закрытие модального окна редактирования
    closeEditUserModal() {
        $('#editUserModal').hide();
        $('#editUserForm')[0].reset();
    }

    // Одобрение станции
    async approveStation(stationId) {
        try {
            // Получаем данные станции
            const stations = await this.getStations();
            const station = stations.find(s => s.station_id == stationId);
            
            if (!station) {
                this.showNotification('Станция не найдена', 'error');
                return;
            }
            
            
            // Заполняем форму данными станции
            $('#approveStationId').val(station.station_id);
            
            
            // Показываем модальное окно
            $('#approveStationModal').show();
            
        } catch (error) {
            console.error('Ошибка загрузки данных станции:', error);
            this.showNotification('Ошибка загрузки данных станции', 'error');
        }
    }

    // Редактирование станции
    async editStation(stationId) {
        try {
            // Получаем данные станции
            const stations = await this.getStations();
            const station = stations.find(s => s.station_id == stationId);
            
            if (!station) {
                this.showNotification('Станция не найдена', 'error');
                return;
            }
            
            // Заполняем форму данными станции
            $('#editStationId').val(station.station_id);
            $('#editStationBoxId').val(station.box_id);
            $('#editStationIccid').val(station.iccid || '');
            
            // Загружаем все группы и подгруппы для выбора
            await this.groupsManager.loadAllOrgUnitsForSelect('#editStationGroup');
            
            // Устанавливаем текущую группу
            $('#editStationGroup').val(station.org_unit_id || '');
            
            // Показываем модальное окно
            $('#editStationModal').show();
            
        } catch (error) {
            console.error('Ошибка загрузки данных станции:', error);
            this.showNotification('Ошибка загрузки данных станции', 'error');
        }
    }


    // Сохранение одобрения станции
    async saveStationApproval() {
        try {
            const stationId = $('#approveStationId').val();
            const secretKey = $('#approveStationKey').val();
            const orgUnitId = $('#approveStationGroup').val();
            
            
            // Валидация
            if (!secretKey || !orgUnitId) {
                let errorMessage = 'Заполните все обязательные поля:';
                if (!secretKey) errorMessage += ' Секретный ключ';
                if (!orgUnitId) errorMessage += ' Группа/Подгруппа';
                
                this.showNotification(errorMessage, 'error');
                return;
            }
            
            const token = localStorage.getItem('authToken');
            
            // 1. Обновляем станцию (статус и группу)
            const stationData = {
                org_unit_id: orgUnitId,
                status: 'active' // Меняем статус на активный
            };
            
            await $.ajax({
                url: `${this.API_BASE}/api/stations/${stationId}`,
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify(stationData)
            });
            
            // 2. Создаем секретный ключ для станции
            const secretKeyData = {
                station_id: parseInt(stationId),
                key_value: secretKey
            };
            
            await $.ajax({
                url: `${this.API_BASE}/api/station-secret-keys`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify(secretKeyData)
            });
            
            this.showNotification('Станция успешно одобрена', 'success');
            this.closeApproveStationModal();
            
            // Перезагружаем данные станций
            console.log('🔄 AdminFullManager: Перезагружаем станции после одобрения');
            await this.stationsManager.loadStations();
            
        } catch (error) {
            console.error('Ошибка одобрения станции:', error);
            this.showNotification('Ошибка одобрения станции', 'error');
        }
    }

    // Сохранение изменений станции
    async saveStationChanges() {
        try {
            const formData = {
                station_id: $('#editStationId').val(),
                org_unit_id: $('#editStationGroup').val()
            };
            
            // Валидация
            if (!formData.org_unit_id) {
                this.showNotification('Выберите группу/подгруппу', 'error');
                return;
            }
            
            const token = localStorage.getItem('authToken');
            
            // Обновляем станцию
            const response = await $.ajax({
                url: `${this.API_BASE}/api/stations/${formData.station_id}`,
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify(formData)
            });
            
            this.showNotification('Станция успешно обновлена', 'success');
            this.closeEditStationModal();
            
            // Перезагружаем данные станций
            console.log('🔄 AdminFullManager: Перезагружаем станции после редактирования');
            await this.stationsManager.loadStations();
            
        } catch (error) {
            console.error('Ошибка сохранения станции:', error);
            this.showNotification('Ошибка сохранения станции', 'error');
        }
    }

    // Закрытие модального окна одобрения станции
    closeApproveStationModal() {
        $('#approveStationModal').hide();
        $('#approveStationForm')[0].reset();
    }

    // Закрытие модального окна редактирования станции
    closeEditStationModal() {
        $('#editStationModal').hide();
        $('#editStationForm')[0].reset();
        $('#editStationCurrentGroup').val('');
    }

    // Модальные окна
    showAddUserModal() {
        alert('Функция добавления пользователя будет реализована');
    }

    showAddStationModal() {
        alert('Функция добавления станции будет реализована');
    }


    // Одобрение аккумулятора
    async approvePowerbank(powerbankId) {
        try {
            // Получаем данные аккумулятора
            const powerbanks = await this.getPowerbanks();
            const powerbank = powerbanks.find(p => p.id == powerbankId);
            
            if (!powerbank) {
                this.showNotification('Аккумулятор не найден', 'error');
                return;
            }
            
            // Заполняем форму данными аккумулятора
            $('#approvePowerbankId').val(powerbank.id);
            $('#approvePowerbankSerial').val(powerbank.serial_number);
            
            // Загружаем все группы и подгруппы для выбора
            await this.groupsManager.loadAllOrgUnitsForSelect('#approvePowerbankGroup');
            
            // Показываем модальное окно
            $('#approvePowerbankModal').show();
            
        } catch (error) {
            console.error('Ошибка загрузки данных аккумулятора:', error);
            this.showNotification('Ошибка загрузки данных аккумулятора', 'error');
        }
    }

    // Сохранение одобрения аккумулятора
    async savePowerbankApproval() {
        try {
            const formData = {
                powerbank_id: $('#approvePowerbankId').val(),
                org_unit_id: $('#approvePowerbankGroup').val()
            };
            
            // Валидация
            if (!formData.org_unit_id) {
                this.showNotification('Выберите группу/подгруппу', 'error');
                return;
            }
            
            const token = localStorage.getItem('authToken');
            
            // Отправляем запрос на одобрение аккумулятора
            const response = await $.ajax({
                url: `${this.API_BASE}/api/powerbanks/${formData.powerbank_id}/approve`,
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    org_unit_id: formData.org_unit_id
                })
            });
            
            if (response.success) {
                this.showNotification('Аккумулятор успешно одобрен', 'success');
                this.closeApprovePowerbankModal();
                
                // Перезагружаем данные аккумуляторов
                await this.loadPowerbanks();
            } else {
                this.showNotification(response.message || 'Ошибка одобрения аккумулятора', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка одобрения аккумулятора:', error);
            this.showNotification('Ошибка одобрения аккумулятора', 'error');
        }
    }

    // Закрытие модального окна одобрения аккумулятора
    closeApprovePowerbankModal() {
        $('#approvePowerbankModal').hide();
        $('#approvePowerbankForm')[0].reset();
    }

    // Редактирование аккумулятора
    async editPowerbank(powerbankId) {
        try {
            // Получаем данные аккумулятора
            const powerbanks = await this.getPowerbanks();
            const powerbank = powerbanks.find(p => p.id == powerbankId);
            
            if (!powerbank) {
                this.showNotification('Аккумулятор не найден', 'error');
                return;
            }
            
            // Заполняем форму данными аккумулятора
            $('#editPowerbankId').val(powerbank.id);
            $('#editPowerbankSerial').val(powerbank.serial_number);
            $('#editPowerbankSoh').val(powerbank.soh || 0);
            $('#editPowerbankStatus').val(powerbank.status);
            $('#editPowerbankWriteOffReason').val(powerbank.write_off_reason || 'none');
            
            // Загружаем все группы и подгруппы для выбора
            await this.groupsManager.loadAllOrgUnitsForSelect('#editPowerbankGroup');
            
            // Устанавливаем текущую группу
            $('#editPowerbankGroup').val(powerbank.org_unit_id || '');
            
            // Показываем модальное окно
            $('#editPowerbankModal').show();
            
        } catch (error) {
            console.error('Ошибка загрузки данных аккумулятора:', error);
            this.showNotification('Ошибка загрузки данных аккумулятора', 'error');
        }
    }

    // Сохранение изменений аккумулятора
    async savePowerbankChanges() {
        try {
            const formData = {
                powerbank_id: $('#editPowerbankId').val(),
                org_unit_id: $('#editPowerbankGroup').val() || null,
                soh: parseInt($('#editPowerbankSoh').val()) || 0,
                status: $('#editPowerbankStatus').val(),
                write_off_reason: $('#editPowerbankWriteOffReason').val()
            };
            
            // Валидация
            if (!formData.status) {
                this.showNotification('Выберите статус аккумулятора', 'error');
                return;
            }
            
            if (formData.soh < 0 || formData.soh > 100) {
                this.showNotification('Уровень заряда должен быть от 0 до 100', 'error');
                return;
            }
            
            const token = localStorage.getItem('authToken');
            
            // Отправляем запрос на обновление аккумулятора
            const response = await $.ajax({
                url: `${this.API_BASE}/api/powerbanks/${formData.powerbank_id}`,
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    org_unit_id: formData.org_unit_id,
                    soh: formData.soh,
                    status: formData.status,
                    write_off_reason: formData.write_off_reason
                })
            });
            
            if (response.success) {
                this.showNotification('Аккумулятор успешно обновлен', 'success');
                this.closeEditPowerbankModal();
                
                // Перезагружаем данные аккумуляторов
                await this.loadPowerbanks();
            } else {
                this.showNotification(response.message || 'Ошибка обновления аккумулятора', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка обновления аккумулятора:', error);
            this.showNotification('Ошибка обновления аккумулятора', 'error');
        }
    }

    // Закрытие модального окна редактирования аккумулятора
    closeEditPowerbankModal() {
        $('#editPowerbankModal').hide();
        $('#editPowerbankForm')[0].reset();
    }

    // Просмотр станции
    async viewStation(stationId) {
        try {
            // Сохраняем ID текущей просматриваемой станции
            this.currentViewingStationId = stationId;
            
            // Получаем данные станции
            const stations = await this.getStations();
            const station = stations.find(s => s.station_id == stationId);
            
            if (!station) {
                this.showNotification('Станция не найдена', 'error');
                return;
            }
            
            // Заполняем информацию о станции
            $('#viewStationBoxId').text(station.box_id);
            $('#viewStationIccid').text(station.iccid || 'Не указан');
            $('#viewStationTotalSlots').text(station.slots_declared || 0);
            $('#viewStationStatus').text(this.getStationStatusText(station.status));
            $('#viewStationLastSeen').text(station.last_seen ? new Date(station.last_seen).toLocaleString() : 'Никогда');
            
            // Загружаем повербанки в станции
            await this.loadStationPowerbanks(stationId);
            
            // Показываем модальное окно
            $('#viewStationModal').show();
            
        } catch (error) {
            console.error('Ошибка загрузки данных станции:', error);
            this.showNotification('Ошибка загрузки данных станции', 'error');
        }
    }

    // Загрузка повербанков в станции
    async loadStationPowerbanks(stationId) {
        try {
            const token = localStorage.getItem('authToken');
            
            // Загружаем данные station_powerbank для этой станции
            const response = await $.ajax({
                url: `${this.API_BASE}/api/station-powerbanks?station_id=${stationId}`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            if (response.success) {
                await this.displayStationPowerbanks(response.data, stationId);
            } else {
                this.showNotification('Ошибка загрузки повербанков станции', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка загрузки повербанков станции:', error);
            this.showNotification('Ошибка загрузки повербанков станции', 'error');
        }
    }


    // Отображение повербанков в станции
    async displayStationPowerbanks(stationPowerbanks, stationId) {
        const grid = $('#powerbanksGrid');
        grid.empty();
        
        // Получаем данные станции для правильного количества слотов
        const stations = await this.getStations();
        const station = stations.find(s => s.station_id == stationId);
        const totalSlots = station ? (station.slots_declared || 0) : 0;
        
        // Подсчитываем статистику
        const occupiedSlots = stationPowerbanks.length;
        const freeSlots = totalSlots - occupiedSlots;
        
        // Обновляем статистику
        $('#viewStationOccupiedSlots').text(occupiedSlots);
        $('#viewStationFreeSlots').text(freeSlots);
        
        // Получаем данные повербанков для правильного статуса
        const powerbanks = await this.getPowerbanks();
        
        // Создаем слоты
        for (let slot = 1; slot <= totalSlots; slot++) {
            const powerbank = stationPowerbanks.find(sp => sp.slot_number === slot);
            
            if (powerbank) {
                // Слот занят повербанком
                const levelClass = this.getBatteryLevelClass(powerbank.level);
                
                // Получаем правильный статус из таблицы powerbank
                const powerbankData = powerbanks.find(p => p.id == powerbank.powerbank_id);
                const powerbankStatus = powerbankData ? powerbankData.status : 'unknown';
                const statusClass = this.getPowerbankStatusClass(powerbankStatus);
                const hasError = this.checkPowerbankErrors(powerbank, powerbankStatus);
                
                grid.append(`
                    <div class="powerbank-slot ${hasError ? 'error' : 'occupied'}">
                        <div class="slot-number">Слот ${slot}</div>
                        <div class="powerbank-info">
                            <div>ID: ${powerbank.powerbank_id}</div>
                            <div>Серийный: ${powerbank.powerbank_serial || 'N/A'}</div>
                        </div>
                        <div class="powerbank-status ${statusClass}">${this.getPowerbankStatusText(powerbankStatus)}</div>
                        <div class="battery-level ${levelClass}">${powerbank.level || 0}%</div>
                        <div class="powerbank-info">
                            <div>Напряжение: ${powerbank.voltage || 0}mV</div>
                            <div>Температура: ${powerbank.temperature || 0}°C</div>
                        </div>
                        ${hasError ? `<div class="error-info">Ошибки: ${this.getErrorDetails(powerbank, powerbankStatus)}</div>` : ''}
                        <button class="action-btn primary borrow-btn" onclick="adminManager.borrowPowerbank(${powerbank.powerbank_id}, ${stationId}, ${slot})">
                            Выдать
                        </button>
                    </div>
                `);
            } else {
                // Пустой слот
                grid.append(`
                    <div class="powerbank-slot empty">
                        <div class="slot-number">Слот ${slot}</div>
                        <div class="powerbank-info">Пусто</div>
                        <button class="action-btn secondary borrow-btn" disabled>
                            Пусто
                        </button>
                    </div>
                `);
            }
        }
    }

    // Получение класса уровня батареи
    getBatteryLevelClass(level) {
        if (level >= 70) return 'high';
        if (level >= 30) return 'medium';
        return 'low';
    }

    // Получение статуса повербанка из данных инвентаря
    getPowerbankStatusFromInventory(powerbank) {
        if (powerbank.status_bits) {
            // Анализируем status_bits для определения статуса
            const bits = powerbank.status_bits;
            if (bits.charging) return 'charging';
            if (bits.fully_charged) return 'fully_charged';
            if (bits.low_battery) return 'low_battery';
            if (bits.error) return 'error';
            return 'available';
        }
        return powerbank.status || 'unknown';
    }

    // Проверка ошибок повербанка из данных инвентаря
    checkPowerbankErrorsFromInventory(powerbank, status) {
        if (powerbank.status_bits) {
            const bits = powerbank.status_bits;
            return bits.error || bits.overheating || bits.overvoltage || bits.undervoltage;
        }
        return status === 'error';
    }

    // Получение деталей ошибок из данных инвентаря
    getErrorDetailsFromInventory(powerbank, status) {
        if (!powerbank.status_bits) return status === 'error' ? 'Неизвестная ошибка' : '';
        
        const bits = powerbank.status_bits;
        const errors = [];
        
        if (bits.error) errors.push('Ошибка');
        if (bits.overheating) errors.push('Перегрев');
        if (bits.overvoltage) errors.push('Перенапряжение');
        if (bits.undervoltage) errors.push('Недонапряжение');
        if (bits.communication_error) errors.push('Ошибка связи');
        
        return errors.length > 0 ? errors.join(', ') : '';
    }




    // Запрос статуса станции
    async queryStationStatus(stationId) {
        if (!stationId) {
            this.showNotification('Не выбрана станция для запроса статуса', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            this.showNotification('Запрашиваем статус станции...', 'info');
            
            // Получаем информацию о станции
            const response = await $.ajax({
                url: `${this.API_BASE}/api/stations/${stationId}`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            if (response.success) {
                const station = response.data;
                const statusInfo = `
                    Статус станции ${station.box_id}:
                    • Статус: ${this.getStationStatusText(station.status)}
                    • Последний контакт: ${station.last_seen ? new Date(station.last_seen).toLocaleString() : 'Никогда'}
                    • Слотов: ${station.slots_declared || 0}
                    • Свободно: ${station.remain_num || 0}
                    • ICCID: ${station.iccid || 'Не указан'}
                `;
                
                this.showNotification(statusInfo, 'info');
                console.log('📊 Статус станции:', station);
            } else {
                this.showNotification('Ошибка получения статуса станции', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка запроса статуса станции:', error);
            this.showNotification('Ошибка запроса статуса станции', 'error');
        }
    }

    // Перезагрузка станции
    async restartStation(stationId) {
        if (!stationId) {
            this.showNotification('Не выбрана станция для перезагрузки', 'error');
            return;
        }

        // Подтверждение действия
        const confirmed = confirm(`Вы уверены, что хотите перезагрузить станцию ${stationId}?\n\nЭто действие отправит команду перезагрузки на станцию.`);
        if (!confirmed) {
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            this.showNotification('Отправляем команду перезагрузки...', 'info');
            
            // Отправляем команду перезагрузки
            const response = await $.ajax({
                url: `${this.API_BASE}/api/restart-cabinet`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    station_id: stationId
                })
            });
            
            if (response.message) {
                this.showNotification(`✅ ${response.message}. Станция переведена в режим неактивна.`, 'success');
                console.log('🔄 Команда перезагрузки отправлена:', response);
                
                // Показываем дополнительную информацию
                if (response.packet_hex) {
                    console.log('📦 Пакет команды:', response.packet_hex);
                    this.showPacketModal('Перезагрузка кабинета', response.packet_hex, response);
                }
                
                // Обновляем список станций, чтобы показать новый статус
                setTimeout(() => {
                    this.loadStations();
                }, 1000);
            } else {
                this.showNotification('Ошибка отправки команды перезагрузки', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка перезагрузки станции:', error);
            let errorMessage = 'Ошибка перезагрузки станции';
            
            if (error.responseJSON && error.responseJSON.error) {
                errorMessage = error.responseJSON.error;
            } else if (error.status === 401) {
                errorMessage = 'Недостаточно прав для перезагрузки станции';
            } else if (error.status === 404) {
                errorMessage = 'Станция не найдена или не подключена';
            }
            
            this.showNotification(errorMessage, 'error');
        }
    }







    // Универсальное модальное окно
    showModal(title, content) {
        const modalHtml = `
            <div id="infoModal" class="modal" style="display: block;">
                <div class="modal-content" style="max-width: 600px;">
                    <div class="modal-header">
                        <h3>${title}</h3>
                        <span class="modal-close" onclick="adminManager.closeModal()">&times;</span>
                    </div>
                    <div class="modal-body">
                        ${content}
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="action-btn secondary" onclick="adminManager.closeModal()">Закрыть</button>
                    </div>
                </div>
            </div>
        `;
        
        // Удаляем предыдущее модальное окно если есть
        $('#infoModal').remove();
        
        // Добавляем новое модальное окно
        $('body').append(modalHtml);
        
        // Закрытие по клику вне модального окна
        $('#infoModal').on('click', (e) => {
            if (e.target.id === 'infoModal') {
                this.closeModal();
            }
        });
    }

    // Закрытие модального окна
    closeModal() {
        $('#infoModal').remove();
    }

    // Получение класса статуса повербанка
    getPowerbankStatusClass(status) {
        switch (status) {
            case 'active': return 'active';
            case 'unknown': return 'unknown';
            case 'user_reported_broken':
            case 'system_error':
            case 'written_off': return 'broken';
            default: return 'unknown';
        }
    }

    // Получение текста статуса повербанка
    getPowerbankStatusText(status) {
        switch (status) {
            case 'active': return 'Активен';
            case 'unknown': return 'Неизвестно';
            case 'user_reported_broken': return 'Неисправен';
            case 'system_error': return 'Ошибка';
            case 'written_off': return 'Списан';
            default: return 'Неизвестно';
        }
    }

    // Получение текста статуса станции
    getStationStatusText(status) {
        switch (status) {
            case 'active': return 'Активна';
            case 'pending': return 'Ожидает одобрения';
            case 'inactive': return 'Неактивна';
            default: return 'Неизвестно';
        }
    }

    // Проверка ошибок повербанка
    checkPowerbankErrors(powerbank, powerbankStatus) {
        const errors = [];
        
        if (powerbank.level < 10) errors.push('Низкий заряд');
        if (powerbank.voltage < 3000) errors.push('Низкое напряжение');
        if (powerbank.temperature > 60) errors.push('Высокая температура');
        if (powerbank.temperature < -10) errors.push('Низкая температура');
        if (powerbankStatus === 'system_error') errors.push('Системная ошибка');
        if (powerbankStatus === 'user_reported_broken') errors.push('Неисправен');
        
        return errors.length > 0;
    }

    // Получение деталей ошибок
    getErrorDetails(powerbank, powerbankStatus) {
        const errors = [];
        
        if (powerbank.level < 10) errors.push('Низкий заряд');
        if (powerbank.voltage < 3000) errors.push('Низкое напряжение');
        if (powerbank.temperature > 60) errors.push('Высокая температура');
        if (powerbank.temperature < -10) errors.push('Низкая температура');
        if (powerbankStatus === 'system_error') errors.push('Системная ошибка');
        if (powerbankStatus === 'user_reported_broken') errors.push('Неисправен');
        
        return errors.join(', ');
    }

    // Выдача повербанка
    async borrowPowerbank(powerbankId, stationId, slotNumber) {
        if (confirm(`Выдать повербанк ID ${powerbankId} из слота ${slotNumber}?`)) {
            try {
                const token = localStorage.getItem('authToken');
                
                // Получаем ID текущего пользователя (админа)
                const user = JSON.parse(localStorage.getItem('currentUser') || '{}');
                console.log('🔍 AdminFullManager: Данные пользователя из localStorage:', user);
                
                // Пробуем разные варианты получения ID
                const userId = user.id || user.user_id || user.userId;
                console.log('🔍 AdminFullManager: Извлеченный userId:', userId);
                
                if (!userId) {
                    console.error('❌ AdminFullManager: Не удалось найти ID пользователя в localStorage');
                    
                    // Пробуем получить данные пользователя через API
                    try {
                        console.log('🔍 AdminFullManager: Пробуем получить данные пользователя через API');
                        const profileResponse = await $.ajax({
                            url: `${this.API_BASE}/api/auth/profile`,
                            method: 'GET',
                            headers: {
                                'Authorization': `Bearer ${token}`
                            }
                        });
                        
                        if (profileResponse.success && profileResponse.data) {
                            const apiUserId = profileResponse.data.id || profileResponse.data.user_id || profileResponse.data.userId;
                            console.log('🔍 AdminFullManager: Получен userId через API:', apiUserId);
                            
                            if (apiUserId) {
                                // Используем ID из API
                                await this.performBorrowRequest(stationId, slotNumber, apiUserId, token);
                                return;
                            }
                        }
                    } catch (apiError) {
                        console.error('❌ AdminFullManager: Ошибка получения профиля через API:', apiError);
                    }
                    
                    this.showNotification('Ошибка: пользователь не найден. Попробуйте перелогиниться.', 'error');
                    return;
                }
                
                // Выполняем запрос на выдачу
                await this.performBorrowRequest(stationId, slotNumber, userId, token);
                
            } catch (error) {
                console.error('Ошибка выдачи повербанка:', error);
                this.showNotification('Ошибка выдачи повербанка', 'error');
            }
        }
    }

    // Выполнение запроса на выдачу повербанка
    async performBorrowRequest(stationId, slotNumber, userId, token) {
        try {
            console.log(`🚀 AdminFullManager: Отправляем запрос на выдачу: станция ${stationId}, слот ${slotNumber}, пользователь ${userId}`);
            
            // Отправляем запрос на выдачу повербанка
            const response = await $.ajax({
                url: `${this.API_BASE}/api/borrow/stations/${stationId}/request`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    slot_number: slotNumber,
                    user_id: userId
                })
            });
            
            console.log('📡 AdminFullManager: Ответ от API выдачи:', response);
            
            if (response.success) {
                this.showNotification('Запрос на выдачу повербанка отправлен станции', 'success');
                
                // Показываем пакет если есть
                if (response.packet_hex) {
                    console.log('📦 Пакет выдачи повербанка:', response.packet_hex);
                    this.showPacketModal('Выдача повербанка', response.packet_hex, response);
                }
                
                // Перезагружаем данные станции
                await this.loadStationPowerbanks(stationId);
            } else {
                this.showNotification(response.message || 'Ошибка выдачи повербанка', 'error');
            }
            
        } catch (error) {
            console.error('❌ AdminFullManager: Ошибка выполнения запроса выдачи:', error);
            this.showNotification('Ошибка выдачи повербанка', 'error');
        }
    }

    // Закрытие модального окна просмотра станции
    closeViewStationModal() {
        $('#viewStationModal').hide();
    }

    // Принудительное извлечение повербанка
    async forceEjectPowerbank(powerbankId) {
        if (confirm(`Принудительно извлечь повербанк ID ${powerbankId} из станции?`)) {
            try {
                const token = localStorage.getItem('authToken');
                
                // Получаем ID текущего пользователя (админа)
                const user = JSON.parse(localStorage.getItem('currentUser') || '{}');
                const userId = user.id || user.user_id || user.userId;
                
                if (!userId) {
                    this.showNotification('Ошибка: пользователь не найден', 'error');
                    return;
                }
                
                // Находим станцию и слот, где находится повербанк
                const stationPowerbankData = await this.findPowerbankInStation(powerbankId);
                
                if (!stationPowerbankData) {
                    this.showNotification('Повербанк не найден в станции', 'error');
                    return;
                }
                
                console.log('🔍 AdminFullManager: Данные повербанка в станции:', stationPowerbankData);
                
                // Отправляем запрос на принудительное извлечение
                const response = await $.ajax({
                    url: `${this.API_BASE}/api/admin/force-eject-powerbank`,
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    data: JSON.stringify({
                        station_id: stationPowerbankData.station_id,
                        slot_number: stationPowerbankData.slot_number,
                        admin_user_id: userId
                    })
                });
                
                console.log('📡 AdminFullManager: Ответ от API принудительного извлечения:', response);
                
                if (response.success) {
                    this.showNotification('Повербанк успешно извлечен из станции', 'success');
                    
                    // Показываем пакет если есть
                    if (response.packet_hex) {
                        console.log('📦 Пакет принудительного извлечения:', response.packet_hex);
                        this.showPacketModal('Принудительное извлечение', response.packet_hex, response);
                    }
                    
                    // Перезагружаем данные повербанков
                    await this.loadPowerbanks();
                } else {
                    this.showNotification(response.message || 'Ошибка извлечения повербанка', 'error');
                }
                
            } catch (error) {
                console.error('Ошибка принудительного извлечения повербанка:', error);
                this.showNotification('Ошибка принудительного извлечения повербанка', 'error');
            }
        }
    }

    // Поиск повербанка в станции
    async findPowerbankInStation(powerbankId) {
        try {
            const token = localStorage.getItem('authToken');
            
            // Загружаем данные station_powerbank для этого повербанка
            const response = await $.ajax({
                url: `${this.API_BASE}/api/station-powerbanks?powerbank_id=${powerbankId}`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            if (response.success && response.data && response.data.length > 0) {
                const stationPowerbank = response.data[0];
                return {
                    station_id: stationPowerbank.station_id,
                    slot_number: stationPowerbank.slot_number,
                    powerbank_id: stationPowerbank.powerbank_id
                };
            }
            
            return null;
            
        } catch (error) {
            console.error('Ошибка поиска повербанка в станции:', error);
            return null;
        }
    }

    // Удаление аккумулятора
    async deletePowerbank(powerbankId) {
        if (confirm('Вы уверены, что хотите удалить этот аккумулятор?')) {
            try {
                const token = localStorage.getItem('authToken');
                
                // Отправляем запрос на удаление аккумулятора
                const response = await $.ajax({
                    url: `${this.API_BASE}/api/powerbanks/${powerbankId}`,
                    method: 'DELETE',
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                });
                
                if (response.success) {
                    this.showNotification('Аккумулятор успешно удален', 'success');
                    
                    // Перезагружаем данные аккумуляторов
                    await this.loadPowerbanks();
                } else {
                    this.showNotification(response.message || 'Ошибка удаления аккумулятора', 'error');
                }
                
            } catch (error) {
                console.error('Ошибка удаления аккумулятора:', error);
                this.showNotification('Ошибка удаления аккумулятора', 'error');
            }
        }
    }


    // Поиск логов
    searchLogs() {
        alert('Функция поиска логов будет реализована');
    }

    // Показать ошибку
    showError(message) {
        $('#errorMessage').text(message).show();
        $('#successMessage').hide();
    }

    // Показать успех
    showSuccess(message) {
        $('#successMessage').text(message).show();
        $('#errorMessage').hide();
    }

    // Выход из системы
    logout() {
        localStorage.removeItem('authToken');
        localStorage.removeItem('currentUser');
        window.location.href = 'auth.html';
    }

    // Универсальное модальное окно для отображения пакетов
    showPacketModal(title, packetHex, response) {
        const modalId = 'packetModal';
        
        // Удаляем существующее модальное окно если есть
        $(`#${modalId}`).remove();
        
        const modalHtml = `
            <div id="${modalId}" class="modal fade" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">📦 ${title}</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="packet-info">
                                <h6>📋 Информация о пакете:</h6>
                                <ul class="list-unstyled">
                                    <li><strong>Команда:</strong> ${title}</li>
                                    <li><strong>Размер:</strong> ${packetHex.length / 2} байт</li>
                                    <li><strong>Статус:</strong> ${response.success ? '✅ Успешно' : '❌ Ошибка'}</li>
                                    ${response.message ? `<li><strong>Сообщение:</strong> ${response.message}</li>` : ''}
                                </ul>
                                
                                <h6>🔧 Пакет (HEX):</h6>
                                <div class="packet-display">
                                    <textarea class="form-control" rows="4" readonly style="font-family: monospace; font-size: 12px; background: #f8f9fa;">${packetHex}</textarea>
                                </div>
                                
                                <h6>📊 Детали пакета:</h6>
                                <div class="packet-details">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <strong>PacketLen:</strong> ${packetHex.substring(0, 4)} (${parseInt(packetHex.substring(0, 4), 16)} байт)
                                        </div>
                                        <div class="col-md-6">
                                            <strong>Command:</strong> ${packetHex.substring(4, 6)} (0x${packetHex.substring(4, 6).toUpperCase()})
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <strong>VSN:</strong> ${packetHex.substring(6, 8)}
                                        </div>
                                        <div class="col-md-6">
                                            <strong>CheckSum:</strong> ${packetHex.substring(8, 10)}
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <strong>Token:</strong> ${packetHex.substring(10, 18)}
                                        </div>
                                    </div>
                                    ${packetHex.length > 18 ? `
                                    <div class="row">
                                        <div class="col-md-12">
                                            <strong>Payload:</strong> ${packetHex.substring(18)}
                                        </div>
                                    </div>
                                    ` : ''}
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
                            <button type="button" class="btn btn-primary" onclick="navigator.clipboard.writeText('${packetHex}'); this.textContent='Скопировано!'; setTimeout(() => this.textContent='Копировать', 2000);">Копировать HEX</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(modalHtml);
        $(`#${modalId}`).modal('show');
    }

    // Запрос инвентаря станции
    async queryStationInventory(stationId) {
        if (!stationId) {
            this.showNotification('Не выбрана станция для запроса инвентаря', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            if (!token) {
                this.showNotification('Сессия истекла. Авторизуйтесь повторно.', 'error');
                this.logout();
                return;
            }
            this.showNotification('Запрашиваем инвентарь станции...', 'info');
            
            // Отправляем запрос инвентаря
            const response = await $.ajax({
                url: `${this.API_BASE}/api/query-inventory`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    station_id: stationId
                })
            });
            
            if (response.success) {
                this.showNotification(`✅ ${response.message}`, 'success');
                console.log('📦 Запрос инвентаря отправлен:', response);
                
                // Показываем дополнительную информацию
                if (response.packet_hex) {
                    console.log('📦 Пакет команды:', response.packet_hex);
                    this.showPacketModal('Запрос инвентаря', response.packet_hex, response);
                }
                
                // Обновляем данные станции через короткое время
                setTimeout(() => {
                    this.loadStationInventory(stationId);
                }, 2000);
            } else {
                this.showNotification('Ошибка запроса инвентаря', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка запроса инвентаря:', error);
            let errorMessage = 'Ошибка запроса инвентаря';
            
            if (error.responseJSON && error.responseJSON.error) {
                errorMessage = error.responseJSON.error;
            } else if (error.status === 401) {
                errorMessage = 'Недостаточно прав для запроса инвентаря';
            } else if (error.status === 404) {
                errorMessage = 'Станция не найдена или не подключена';
            }
            
            this.showNotification(errorMessage, 'error');
        }
    }

    // Автоматический запрос инвентаря при клике на станцию
    async onStationClick(stationId) {
        console.log(`🖱️ Клик по станции ${stationId}`);
        
        // Автоматически запрашиваем инвентарь
        await this.queryStationInventory(stationId);
    }

    // Загрузка инвентаря станции
    async loadStationInventory(stationId) {
        try {
            const token = localStorage.getItem('authToken');
            if (!token) {
                this.showNotification('Сессия истекла. Авторизуйтесь повторно.', 'error');
                this.logout();
                return;
            }
            
            const response = await $.ajax({
                url: `${this.API_BASE}/api/query-inventory/station/${stationId}`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });
            
            if (response.success) {
                this.displayStationInventory(response.station, response.inventory);
            } else {
                this.showNotification('Ошибка загрузки инвентаря', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка загрузки инвентаря:', error);
            this.showNotification('Ошибка загрузки инвентаря', 'error');
        }
    }

    // Отображение инвентаря станции
    displayStationInventory(station, inventory) {
        const inventoryHtml = `
            <div class="inventory-details">
                <h4>📊 Инвентарь станции ${station.box_id}</h4>
                <div class="station-info">
                    <p><strong>ID станции:</strong> ${station.station_id}</p>
                    <p><strong>Свободно слотов:</strong> ${station.remain_num}</p>
                    <p><strong>Всего слотов:</strong> ${station.slots_declared}</p>
                    <p><strong>Статус:</strong> <span class="status-${station.status}">${station.status}</span></p>
                    <p><strong>Последний контакт:</strong> ${station.last_seen ? new Date(station.last_seen).toLocaleString() : 'Неизвестно'}</p>
                </div>
                
                <h5>🔋 Повербанки в станции (${inventory.length})</h5>
                <div class="inventory-table">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Слот</th>
                                <th>Серийный номер</th>
                                <th>Уровень заряда</th>
                                <th>Напряжение</th>
                                <th>Температура</th>
                                <th>SOH</th>
                                <th>Статус</th>
                                <th>Обновлено</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${inventory.map(item => `
                                <tr>
                                    <td>${item.slot_number}</td>
                                    <td>${item.serial_number}</td>
                                    <td>${item.level !== null ? item.level + '%' : 'N/A'}</td>
                                    <td>${item.voltage !== null ? item.voltage + 'mV' : 'N/A'}</td>
                                    <td>${item.temperature !== null ? item.temperature + '°C' : 'N/A'}</td>
                                    <td>${item.soh !== null ? item.soh + '%' : 'N/A'}</td>
                                    <td><span class="status-${item.powerbank_status}">${item.powerbank_status}</span></td>
                                    <td>${item.last_update ? new Date(item.last_update).toLocaleString() : 'N/A'}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
        
        this.showModal('Инвентарь станции', inventoryHtml);
    }

    // Запрос уровня громкости станции
    async queryVoiceVolume(stationId) {
        if (!stationId) {
            this.showNotification('Не выбрана станция для запроса уровня громкости', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            this.showNotification('Запрашиваем уровень громкости станции...', 'info');
            
            // Отправляем запрос уровня громкости
            const response = await $.ajax({
                url: `${this.API_BASE}/api/query-voice-volume`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    station_id: stationId
                })
            });
            
            if (response.success) {
                this.showNotification(`✅ ${response.message}`, 'success');
                console.log('🔊 Запрос уровня громкости отправлен:', response);
                
                // Показываем дополнительную информацию
                if (response.packet_hex) {
                    console.log('📦 Пакет команды:', response.packet_hex);
                    this.showPacketModal('Запрос уровня громкости', response.packet_hex, response);
                }
            } else {
                this.showNotification('Ошибка запроса уровня громкости', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка запроса уровня громкости:', error);
            let errorMessage = 'Ошибка запроса уровня громкости';
            
            if (error.responseJSON && error.responseJSON.error) {
                errorMessage = error.responseJSON.error;
            } else if (error.status === 401) {
                errorMessage = 'Недостаточно прав для запроса уровня громкости';
            } else if (error.status === 404) {
                errorMessage = 'Станция не найдена или не подключена';
            }
            
            this.showNotification(errorMessage, 'error');
        }
    }

    // Запрос адреса сервера станции
    async queryServerAddress(stationId) {
        if (!stationId) {
            this.showNotification('Не выбрана станция для запроса адреса сервера', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            if (!token) {
                this.showNotification('Сессия истекла. Авторизуйтесь повторно.', 'error');
                this.logout();
                return;
            }
            this.showNotification('Запрашиваем адрес сервера станции...', 'info');
            
            // Отправляем запрос адреса сервера
            const response = await $.ajax({
                url: `${this.API_BASE}/api/query-server-address`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    station_id: stationId
                })
            });
            
            if (response.success) {
                this.showNotification(`✅ ${response.message}`, 'success');
                console.log('🌐 Запрос адреса сервера отправлен:', response);
                
                // Показываем дополнительную информацию
                if (response.packet_hex) {
                    console.log('🌐 Пакет команды:', response.packet_hex);
                    this.showServerAddressPacketModal('Запрос адреса сервера', response.packet_hex, response);
                }
            } else {
                this.showNotification('Ошибка запроса адреса сервера', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка запроса адреса сервера:', error);
            this.showNotification('Ошибка запроса адреса сервера', 'error');
        }
    }

    // Получение кэшированного адреса сервера станции
    async getStationServerAddress(stationId) {
        if (!stationId) {
            this.showNotification('Не выбрана станция для получения адреса сервера', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            if (!token) {
                this.showNotification('Сессия истекла. Авторизуйтесь повторно.', 'error');
                this.logout();
                return;
            }
            
            const response = await $.ajax({
                url: `${this.API_BASE}/api/query-server-address/station/${stationId}`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });
            
            if (response.success) {
                this.showServerAddressResultModal(response.server_address, stationId);
            } else {
                this.showNotification(response.error || 'Ошибка получения адреса сервера', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка получения адреса сервера:', error);
            this.showNotification('Ошибка получения адреса сервера', 'error');
        }
    }

    // Отображение модального окна с результатом запроса адреса сервера
    showServerAddressResultModal(serverAddressData, stationId) {
        const modalHtml = `
            <div class="server-address-result">
                <h4>🌐 Адрес сервера станции</h4>
                <div class="request-info">
                    <p><strong>Станция ID:</strong> ${stationId}</p>
                    <p><strong>Адрес сервера:</strong> ${serverAddressData.address}</p>
                    <p><strong>Порты:</strong> ${serverAddressData.ports}</p>
                    <p><strong>Интервал heartbeat:</strong> ${serverAddressData.heartbeat} секунд</p>
                    <p><strong>Обновлено:</strong> ${new Date(serverAddressData.last_update).toLocaleString()}</p>
                </div>
                
                <div class="info-note">
                    <p><strong>ℹ️ Примечание:</strong> Данные получены от станции в ответ на команду 0x6A (Query Server Address).</p>
                </div>
            </div>
        `;
        
        this.showModal('Адрес сервера станции', modalHtml);
    }

    // Отображение модального окна с информацией о запросе адреса сервера
    showServerAddressPacketModal(title, packetHex, response) {
        const modalHtml = `
            <div class="server-address-details">
                <h4>🌐 Запрос адреса сервера станции</h4>
                <div class="request-info">
                    <p><strong>Статус:</strong> <span class="status-success">Запрос отправлен</span></p>
                    <p><strong>Время:</strong> ${new Date().toLocaleString()}</p>
                </div>
                
                <h5>📦 Информация о пакете</h5>
                <div class="packet-info">
                    <p><strong>Команда:</strong> 0x6A (Query Server Address)</p>
                    <p><strong>Пакет (HEX):</strong></p>
                    <div class="packet-display">
                        <code style="background: #f5f5f5; padding: 8px; border-radius: 4px; font-family: monospace; word-break: break-all;">
                            ${packetHex}
                        </code>
                    </div>
                    <p><strong>Размер:</strong> ${packetHex.length / 2} байт</p>
                </div>
                
                <div class="info-note">
                    <p><strong>ℹ️ Примечание:</strong> Ожидайте ответ от станции с текущим адресом сервера, портами и интервалом heartbeat.</p>
                    <p><strong>📋 Данные ответа:</strong> Адрес сервера, порты и интервал heartbeat будут отображены в консоли сервера.</p>
                </div>
            </div>
        `;
        
        this.showModal(title, modalHtml);
    }

    // Отображение модального окна с информацией о запросе громкости
    showVoiceVolumeResultModal(response) {
        const modalHtml = `
            <div class="voice-volume-details">
                <h4>🔊 Запрос уровня громкости голосового вещания</h4>
                <div class="request-info">
                    <p><strong>Станция:</strong> ${response.station_box_id}</p>
                    <p><strong>Статус:</strong> <span class="status-success">Запрос отправлен</span></p>
                    <p><strong>Время:</strong> ${new Date().toLocaleString()}</p>
                </div>
                
                <h5>📦 Информация о пакете</h5>
                <div class="packet-info">
                    <p><strong>Команда:</strong> 0x77 (Query Voice Volume)</p>
                    <p><strong>Пакет (HEX):</strong></p>
                    <div class="packet-display">
                        <code style="background: #f5f5f5; padding: 8px; border-radius: 4px; font-family: monospace; word-break: break-all;">
                            ${response.packet_hex}
                        </code>
                    </div>
                    <p><strong>Размер:</strong> ${response.packet_hex.length / 2} байт</p>
                </div>
                
                <div class="info-note">
                    <p><strong>ℹ️ Примечание:</strong> Ожидайте ответ от станции с текущим уровнем громкости (0-15).</p>
                </div>
            </div>
        `;
        
        this.showModal('Запрос уровня громкости', modalHtml);
    }

    // Установка уровня громкости станции
    async setVoiceVolume(stationId, volumeLevel) {
        if (!stationId) {
            this.showNotification('Не выбрана станция для установки уровня громкости', 'error');
            return;
        }

        if (volumeLevel === undefined || volumeLevel === null) {
            this.showNotification('Не указан уровень громкости', 'error');
            return;
        }

        if (!(0 <= volumeLevel <= 15)) {
            this.showNotification('Уровень громкости должен быть от 0 до 15', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            this.showNotification(`Устанавливаем уровень громкости ${volumeLevel} на станцию...`, 'info');
            
            // Отправляем запрос установки уровня громкости
            const response = await $.ajax({
                url: `${this.API_BASE}/api/set-voice-volume`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    station_id: stationId,
                    volume_level: volumeLevel
                })
            });
            
            if (response.success) {
                this.showNotification(`✅ ${response.message}`, 'success');
                console.log('🔊 Установка уровня громкости отправлена:', response);
                
                // Показываем дополнительную информацию
                if (response.packet_hex) {
                    console.log('📦 Пакет команды:', response.packet_hex);
                    this.showPacketModal('Установка уровня громкости', response.packet_hex, response);
                }
            } else {
                this.showNotification('Ошибка установки уровня громкости', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка установки уровня громкости:', error);
            let errorMessage = 'Ошибка установки уровня громкости';
            
            if (error.responseJSON && error.responseJSON.error) {
                errorMessage = error.responseJSON.error;
            } else if (error.status === 401) {
                errorMessage = 'Недостаточно прав для установки уровня громкости';
            } else if (error.status === 404) {
                errorMessage = 'Станция не найдена или не подключена';
            }
            
            this.showNotification(errorMessage, 'error');
        }
    }

    // Показ модального окна для выбора уровня громкости
    showSetVoiceVolumeModal(stationId) {
        if (!stationId) {
            this.showNotification('Не выбрана станция для установки уровня громкости', 'error');
            return;
        }
        const modalHtml = `
            <div class="set-voice-volume-details">
                <h4>🔊 Установка уровня громкости голосового вещания</h4>
                <div class="volume-selector">
                    <p><strong>Выберите уровень громкости (0-15):</strong></p>
                    <div class="volume-slider-container">
                        <input type="range" id="volumeSlider" min="0" max="15" value="8" 
                               style="width: 100%; margin: 10px 0;">
                        <div class="volume-display">
                            <span id="volumeValue">8</span>
                        </div>
                    </div>
                    <div class="volume-buttons">
                        <button class="action-btn small" onclick="adminManager.setVolumeTo(0)">0 (Тишина)</button>
                        <button class="action-btn small" onclick="adminManager.setVolumeTo(5)">5 (Тихо)</button>
                        <button class="action-btn small" onclick="adminManager.setVolumeTo(10)">10 (Средне)</button>
                        <button class="action-btn small" onclick="adminManager.setVolumeTo(15)">15 (Громко)</button>
                    </div>
                </div>
                <div class="modal-actions">
                    <button class="action-btn primary" onclick="adminManager.confirmSetVoiceVolume(${stationId})">
                        Установить громкость
                    </button>
                    <button class="action-btn secondary" onclick="adminManager.closeModal()">
                        Отмена
                    </button>
                </div>
            </div>
        `;
        
        this.showModal('Установка уровня громкости', modalHtml);
        
        // Добавляем обработчик для слайдера
        $('#volumeSlider').on('input', function() {
            $('#volumeValue').text($(this).val());
        });
    }

    // Установка конкретного уровня громкости
    setVolumeTo(level) {
        $('#volumeSlider').val(level);
        $('#volumeValue').text(level);
    }

    // Подтверждение установки уровня громкости
    async confirmSetVoiceVolume(stationId) {
        const volumeLevel = parseInt($('#volumeSlider').val());
        await this.setVoiceVolume(stationId, volumeLevel);
        this.closeModal();
    }

    // Отображение модального окна с результатом установки громкости
    showSetVoiceVolumeResultModal(response) {
        const modalHtml = `
            <div class="set-voice-volume-result">
                <h4>🔊 Установка уровня громкости голосового вещания</h4>
                <div class="request-info">
                    <p><strong>Станция:</strong> ${response.station_box_id}</p>
                    <p><strong>Уровень громкости:</strong> ${response.volume_level}</p>
                    <p><strong>Статус:</strong> <span class="status-success">Команда отправлена</span></p>
                    <p><strong>Время:</strong> ${new Date().toLocaleString()}</p>
                </div>
                
                <h5>📦 Информация о пакете</h5>
                <div class="packet-info">
                    <p><strong>Команда:</strong> 0x70 (Set Voice Volume)</p>
                    <p><strong>Пакет (HEX):</strong></p>
                    <div class="packet-display">
                        <code style="background: #f5f5f5; padding: 8px; border-radius: 4px; font-family: monospace; word-break: break-all;">
                            ${response.packet_hex}
                        </code>
                    </div>
                    <p><strong>Размер:</strong> ${response.packet_hex.length / 2} байт</p>
                </div>
                
                <div class="info-note">
                    <p><strong>ℹ️ Примечание:</strong> Ожидайте подтверждение от станции об успешной установке уровня громкости.</p>
                </div>
            </div>
        `;
        
        this.showModal('Установка уровня громкости', modalHtml);
    }

    // Установка адреса сервера станции
    async setServerAddress(stationId, serverAddress, serverPort, heartbeatInterval) {
        if (!stationId) {
            this.showNotification('Не выбрана станция для установки адреса сервера', 'error');
            return;
        }

        if (!serverAddress || !serverPort) {
            this.showNotification('Адрес сервера и порт не могут быть пустыми', 'error');
            return;
        }

        if (!(1 <= heartbeatInterval <= 255)) {
            this.showNotification('Интервал heartbeat должен быть от 1 до 255', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            this.showNotification(`Устанавливаем адрес сервера ${serverAddress}:${serverPort} на станцию...`, 'info');
            
            // Отправляем запрос установки адреса сервера
            const response = await $.ajax({
                url: `${this.API_BASE}/api/set-server-address`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    station_id: stationId,
                    server_address: serverAddress,
                    server_port: serverPort,
                    heartbeat_interval: heartbeatInterval
                })
            });
            
            if (response.success) {
                this.showNotification(`✅ ${response.message}`, 'success');
                console.log('🌐 Установка адреса сервера отправлена:', response);
                
                // Показываем дополнительную информацию
                if (response.packet_hex) {
                    console.log('📦 Пакет команды:', response.packet_hex);
                    this.showPacketModal('Установка адреса сервера', response.packet_hex, response);
                }
            } else {
                this.showNotification('Ошибка установки адреса сервера', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка установки адреса сервера:', error);
            let errorMessage = 'Ошибка установки адреса сервера';
            
            if (error.responseJSON && error.responseJSON.error) {
                errorMessage = error.responseJSON.error;
            } else if (error.status === 401) {
                errorMessage = 'Недостаточно прав для установки адреса сервера';
            } else if (error.status === 404) {
                errorMessage = 'Станция не найдена или не подключена';
            }
            
            this.showNotification(errorMessage, 'error');
        }
    }

    // Показ модального окна для установки адреса сервера
    showSetServerAddressModal(stationId) {
        const modalHtml = `
            <div class="set-server-address-details">
                <h4>🌐 Установка адреса сервера</h4>
                <div class="server-address-form">
                    <div class="form-group">
                        <label for="serverAddress">Адрес сервера:</label>
                        <input type="text" id="serverAddress" placeholder="192.168.1.100" 
                               style="width: 100%; padding: 8px; margin: 5px 0; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div class="form-group">
                        <label for="serverPort">Порт сервера:</label>
                        <input type="text" id="serverPort" placeholder="8000" 
                               style="width: 100%; padding: 8px; margin: 5px 0; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div class="form-group">
                        <label for="heartbeatInterval">Интервал heartbeat (1-255 сек):</label>
                        <input type="number" id="heartbeatInterval" value="30" min="1" max="255" 
                               style="width: 100%; padding: 8px; margin: 5px 0; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                </div>
                <div class="warning-note">
                    <p><strong>⚠️ ВНИМАНИЕ:</strong> После установки нового адреса сервера станция перезагрузится!</p>
                </div>
                <div class="modal-actions">
                    <button class="action-btn primary" onclick="adminManager.confirmSetServerAddress(${stationId})">
                        Установить адрес
                    </button>
                    <button class="action-btn secondary" onclick="adminManager.closeModal()">
                        Отмена
                    </button>
                </div>
            </div>
        `;
        
        this.showModal('Установка адреса сервера', modalHtml);
    }

    // Подтверждение установки адреса сервера
    async confirmSetServerAddress(stationId) {
        const serverAddress = $('#serverAddress').val().trim();
        const serverPort = $('#serverPort').val().trim();
        const heartbeatInterval = parseInt($('#heartbeatInterval').val());
        
        if (!serverAddress || !serverPort) {
            this.showNotification('Заполните все поля', 'error');
            return;
        }
        
        await this.setServerAddress(stationId, serverAddress, serverPort, heartbeatInterval);
        this.closeModal();
    }

    // Отображение модального окна с результатом установки адреса сервера
    showSetServerAddressResultModal(response) {
        const modalHtml = `
            <div class="set-server-address-result">
                <h4>🌐 Установка адреса сервера</h4>
                <div class="request-info">
                    <p><strong>Станция:</strong> ${response.station_box_id}</p>
                    <p><strong>Адрес сервера:</strong> ${response.server_address}:${response.server_port}</p>
                    <p><strong>Интервал heartbeat:</strong> ${response.heartbeat_interval} секунд</p>
                    <p><strong>Статус:</strong> <span class="status-success">Команда отправлена</span></p>
                    <p><strong>Время:</strong> ${new Date().toLocaleString()}</p>
                </div>
                
                <h5>📦 Информация о пакете</h5>
                <div class="packet-info">
                    <p><strong>Команда:</strong> 0x63 (Set Server Address)</p>
                    <p><strong>Пакет (HEX):</strong></p>
                    <div class="packet-display">
                        <code style="background: #f5f5f5; padding: 8px; border-radius: 4px; font-family: monospace; word-break: break-all;">
                            ${response.packet_hex}
                        </code>
                    </div>
                    <p><strong>Размер:</strong> ${response.packet_hex.length / 2} байт</p>
                </div>
                
                <div class="warning-note">
                    <p><strong>⚠️ ВНИМАНИЕ:</strong> Станция перезагрузится после применения конфигурации!</p>
                </div>
            </div>
        `;
        
        this.showModal('Установка адреса сервера', modalHtml);
    }
}

    // Инициализация при загрузке страницы
    $(document).ready(function() {
        // Проверяем авторизацию
        const token = localStorage.getItem('authToken');
        if (!token) {
            window.location.href = 'auth.html';
            return;
        }

        // Инициализируем админ панель
        window.adminManager = new AdminFullManager();
        window.adminManager.init();
        
        
        // Сразу загружаем панель управления
        window.adminManager.loadDashboard();
    });
