/**
 * Расширенный модуль админ панели ПО "Заряд"
 */
class AdminFullManager {
    constructor() {
        this.API_BASE = 'http://localhost:8000';
        this.currentUser = null;
        this.currentStationId = null;
        this.currentSection = 'dashboard';
        this.usersManager = new UsersManager(this.API_BASE, this.showNotification.bind(this));
        this.stationsManager = new StationsManager(this.API_BASE, this.showNotification.bind(this));
        this.groupsManager = new GroupsManager(this.API_BASE, this.showNotification.bind(this));
    }

    init() {
        this.bindEvents();
        this.checkAuth();
        this.startRealTimeUpdates();
        
        // Инициализируем модальные окна групп
        this.groupsManager.initModals();
        
        // Панель управления загрузится автоматически в $(document).ready
    }
    
    // Запуск обновлений в реальном времени
    startRealTimeUpdates() {
        console.log('⏰ AdminFullManager: Запускаем обновления в реальном времени');
        
        // Обновляем данные каждые 30 секунд
        setInterval(() => {
            console.log('⏰ AdminFullManager: setInterval сработал, текущий раздел:', this.currentSection);
            if (this.currentSection === 'dashboard') {
                console.log('📊 AdminFullManager: Обновляем dashboard');
                this.loadDashboard();
            } else if (this.currentSection === 'users') {
                console.log('👥 AdminFullManager: Обновляем users');
                this.loadUsers();
            }
        }, 30000);
        
        // Обновляем данные при переключении вкладок
        $(document).on('visibilitychange', () => {
            console.log('👁️ AdminFullManager: visibilitychange сработал, документ скрыт:', document.hidden);
            if (!document.hidden) {
                console.log('👁️ AdminFullManager: Документ стал видимым, текущий раздел:', this.currentSection);
                if (this.currentSection === 'dashboard') {
                    console.log('📊 AdminFullManager: Обновляем dashboard при переключении вкладки');
                    this.loadDashboard();
                } else if (this.currentSection === 'users') {
                    console.log('👥 AdminFullManager: Обновляем users при переключении вкладки');
                    this.loadUsers();
                }
            }
        });
    }

    bindEvents() {
        // Навигация по разделам
        $('.nav-tab').on('click', (e) => {
            const section = $(e.currentTarget).data('section');
            this.switchSection(section);
        });

        // Выход из системы
        $('#logoutBtn').on('click', () => {
            this.logout();
        });



        // Кнопки действий
        $('#addUserBtn').on('click', () => this.showAddUserModal());
        $('#addStationBtn').on('click', () => this.showAddStationModal());
        $('#searchLogsBtn').on('click', () => this.searchLogs());
        
        // Кнопки групп
        $('#addGroupBtn').on('click', () => this.showAddGroupModal());
        $('#addSubgroupBtn').on('click', () => this.showAddSubgroupModal());

        // Фильтры
        $('#userSearch, #userRoleFilter, #userStatusFilter').on('input change', () => this.filterUsers());
        $('#stationSearch, #stationGroupFilter, #stationStatusFilter').on('input change', () => this.filterStations());
        $('#resetStationFilters').on('click', () => this.resetStationFilters());
        $('#powerbankSearch, #powerbankStatusFilter').on('input change', () => this.filterPowerbanks());
        $('#groupSearch, #groupTypeFilter').on('input change', () => this.filterGroups());
        
        // Модальное окно редактирования пользователя
        $('#cancelEditUser').on('click', () => this.closeEditUserModal());
        $('#editUserModal .modal-close').on('click', () => this.closeEditUserModal());
        $('#saveEditUser').on('click', () => this.saveUserChanges());
        
        // Модальное окно одобрения станции
        $('#cancelApproveStation').on('click', () => this.closeApproveStationModal());
        $('#approveStationModal .modal-close').on('click', () => this.closeApproveStationModal());
        $('#saveApproveStation').on('click', () => this.saveStationApproval());
        
        
        
        // Модальные окна групп
        $('#cancelAddGroup, #cancelAddSubgroup, #cancelEditGroup').on('click', () => this.closeGroupModals());
        $('#addGroupModal .modal-close, #addSubgroupModal .modal-close, #editGroupModal .modal-close').on('click', () => this.closeGroupModals());
        $('#saveAddGroup').on('click', () => this.saveAddGroup());
        $('#saveAddSubgroup').on('click', () => this.saveAddSubgroup());
        $('#saveEditGroup').on('click', () => this.saveEditGroup());
        
        // Закрытие модальных окон по клику вне области
        $('#addGroupModal, #addSubgroupModal, #editGroupModal').on('click', (e) => {
            if (e.target.id === 'addGroupModal' || e.target.id === 'addSubgroupModal' || e.target.id === 'editGroupModal') {
                this.closeGroupModals();
            }
        });
        
        
        
        // Модальное окно просмотра станции
        $('#closeViewStation').on('click', () => this.closeViewStationModal());
        $('#viewStationModal .modal-close').on('click', () => this.closeViewStationModal());
        $('#refreshInventoryBtn').on('click', () => this.refreshStationInventory());
        $('#queryVoiceVolumeBtn').on('click', () => this.showVoiceVolumeModal());
        $('#queryServerAddressBtn').on('click', () => this.showServerAddressModal());
        $('#restartStationBtn').on('click', () => this.restartStation());
        
        // Модальное окно управления громкостью
        $('#closeVoiceVolumeModal').on('click', () => this.closeVoiceVolumeModal());
        $('#voiceVolumeModal .modal-close').on('click', () => this.closeVoiceVolumeModal());
        
        // Модальное окно управления адресом сервера
        $('#closeServerAddressModal').on('click', () => this.closeServerAddressModal());
        $('#serverAddressModal .modal-close').on('click', () => this.closeServerAddressModal());
        $('#queryCurrentAddressBtn').on('click', () => this.queryCurrentServerAddress());
        $('#setServerAddressBtn').on('click', () => this.setServerAddress());
        
        $('#setVoiceVolumeBtn').on('click', () => this.setVoiceVolume());
        $('#volumeSlider').on('input', (e) => this.updateVolumeDisplay(e.target.value));
        
        // Модальное окно редактирования станции
        $('#cancelEditStation').on('click', () => this.closeEditStationModal());
        $('#editStationModal .modal-close').on('click', () => this.closeEditStationModal());
        $('#saveEditStation').on('click', () => this.saveStationChanges());
        
        // Модальное окно одобрения аккумулятора
        $('#cancelApprovePowerbank').on('click', () => this.closeApprovePowerbankModal());
        $('#approvePowerbankModal .modal-close').on('click', () => this.closeApprovePowerbankModal());
        $('#saveApprovePowerbank').on('click', () => this.savePowerbankApproval());
        
        // Модальное окно редактирования аккумулятора
        $('#cancelEditPowerbank').on('click', () => this.closeEditPowerbankModal());
        $('#editPowerbankModal .modal-close').on('click', () => this.closeEditPowerbankModal());
        $('#saveEditPowerbank').on('click', () => this.savePowerbankChanges());
        
        // Закрытие модальных окон по клику вне их
        $('#editUserModal').on('click', (e) => {
            if (e.target.id === 'editUserModal') {
                this.closeEditUserModal();
            }
        });
        
        $('#approveStationModal').on('click', (e) => {
            if (e.target.id === 'approveStationModal') {
                this.closeApproveStationModal();
            }
        });
        
        $('#viewStationModal').on('click', (e) => {
            if (e.target.id === 'viewStationModal') {
                this.closeViewStationModal();
            }
        });
        
        $('#editStationModal').on('click', (e) => {
            if (e.target.id === 'editStationModal') {
                this.closeEditStationModal();
            }
        });
        
        $('#approvePowerbankModal').on('click', (e) => {
            if (e.target.id === 'approvePowerbankModal') {
                this.closeApprovePowerbankModal();
            }
        });
        
        $('#editPowerbankModal').on('click', (e) => {
            if (e.target.id === 'editPowerbankModal') {
                this.closeEditPowerbankModal();
            }
        });
    }

    // Проверка авторизации
    async checkAuth() {
        const token = localStorage.getItem('authToken');
        if (!token) {
            window.location.href = 'auth.html';
            return;
        }

        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/api/auth/profile`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.data && response.data.user) {
                this.currentUser = response.data.user;
                
                // Получаем роль пользователя из отдельного API
                try {
                    const roleResponse = await $.ajax({
                        url: `${this.API_BASE}/api/user-roles`,
                        method: 'GET',
                        headers: { 'Authorization': `Bearer ${token}` }
                    });
                    
                    // Находим роль текущего пользователя
                    const userRole = roleResponse.data?.find(role => role.user_id === response.data.user.user_id);
                    if (userRole) {
                        this.currentUser.role = userRole.role;
                    }
                } catch (roleError) {
                    console.warn('Не удалось загрузить роль пользователя:', roleError);
                    // Используем роль по умолчанию
                    this.currentUser.role = this.currentUser.role || 'user';
                }
                
                this.displayUserInfo(this.currentUser);
                
                // Проверяем права доступа
                if (!this.isAdmin(this.currentUser)) {
                    this.showNotification('У вас нет прав доступа к админ панели', 'error');
                    setTimeout(() => {
                        window.location.href = 'auth.html';
                    }, 2000);
                    return;
                }
                
                // Панель управления загрузится автоматически в $(document).ready
            }
        } catch (error) {
            console.error('Ошибка проверки авторизации:', error);
            localStorage.removeItem('authToken');
            localStorage.removeItem('currentUser');
            window.location.href = 'auth.html';
        }
    }

    // Проверка роли администратора
    isAdmin(user) {
        return user && ['service_admin'].includes(user.role);
    }

    // Отображение информации о пользователе
    displayUserInfo(user) {
        const userName = user.fio || user.phone_e164 || 'Пользователь';
        const userRole = this.getRoleName(user.role);
        $('#userName').text(`${userName} (${userRole})`);
        
        // Убираем индикатор загрузки
        $('#userName').removeClass('loading');
    }
    
    // Получение названия роли
    getRoleName(role) {
        const roleNames = {
            'service_admin': 'Админ сервиса',
            'user': 'Пользователь'
        };
        return roleNames[role] || role || 'Пользователь';
    }

    // Переключение разделов
    switchSection(section) {
        console.log('🔄 AdminFullManager: Переключаемся на раздел:', section);
        
        $('.nav-tab').removeClass('active');
        $(`.nav-tab[data-section="${section}"]`).addClass('active');
        
        $('.admin-section').removeClass('active');
        $(`#${section}-section`).addClass('active');
        
        this.currentSection = section;
        
        // Загружаем данные для раздела асинхронно
        console.log('📡 AdminFullManager: Загружаем данные для раздела:', section);
        this.loadSectionData(section);
    }
    
    // Асинхронная загрузка данных раздела
    async loadSectionData(section) {
        console.log('📡 AdminFullManager: loadSectionData вызвана для раздела:', section);
        try {
            switch(section) {
                case 'dashboard':
                    console.log('📊 AdminFullManager: Загружаем dashboard');
                    await this.loadDashboard();
                    break;
                case 'users':
                    console.log('👥 AdminFullManager: Загружаем users');
                    await this.loadUsers();
                    break;
                case 'stations':
                    console.log('🏭 AdminFullManager: Загружаем stations');
                    await this.loadStations();
                    break;
                case 'powerbanks':
                    console.log('🔋 AdminFullManager: Загружаем powerbanks');
                    await this.loadPowerbanks();
                    break;
                case 'groups':
                    console.log('🏢 AdminFullManager: Загружаем groups');
                    await this.loadGroups();
                    break;
                case 'logs':
                    console.log('📝 AdminFullManager: Загружаем logs');
                    this.loadLogs();
                    break;
            }
            console.log('✅ AdminFullManager: loadSectionData завершена для раздела:', section);
        } catch (error) {
            console.error('❌ AdminFullManager: Ошибка загрузки раздела:', section, error);
            this.showNotification('Ошибка загрузки раздела', 'error');
        }
    }



    // Загрузка панели управления
    async loadDashboard() {
        try {
            // Показываем индикатор загрузки
            $('#totalUsers, #pendingUsers, #activeUsers, #totalStations, #inactiveStations, #pendingStations, #totalPowerbanks, #brokenPowerbanks, #pendingPowerbanks').text('...');
            
            // Загружаем статистику асинхронно
            const stats = await this.getDashboardStats();
            this.displayDashboardStats(stats);
            
            // Убираем индикатор загрузки только после успешной загрузки
            // Не показываем уведомление для автоматической загрузки
        } catch (error) {
            console.error('Ошибка загрузки статистики:', error);
            this.showNotification('Ошибка загрузки статистики', 'error');
        }
    }

    // Получение статистики - асинхронная загрузка всех данных
    async getDashboardStats() {
        const token = localStorage.getItem('authToken');
        
        try {
            // Загружаем все данные параллельно
            const [pendingUsersResponse, allUsersResponse, stationsResponse, powerbanksResponse] = await Promise.allSettled([
                // Пользователи на подтверждение
                $.ajax({
                    url: `${this.API_BASE}/api/admin/pending-users`,
                    method: 'GET',
                    headers: { 'Authorization': `Bearer ${token}` }
                }),
                // Все пользователи
                $.ajax({
                    url: `${this.API_BASE}/api/users`,
                    method: 'GET',
                    headers: { 'Authorization': `Bearer ${token}` }
                }),
                // Станции
                $.ajax({
                    url: `${this.API_BASE}/api/stations`,
                    method: 'GET',
                    headers: { 'Authorization': `Bearer ${token}` }
                }),
                // Аккумуляторы
                $.ajax({
                    url: `${this.API_BASE}/api/powerbanks`,
                    method: 'GET',
                    headers: { 'Authorization': `Bearer ${token}` }
                }),
            ]);

            // Обрабатываем результаты
            const pendingUsers = pendingUsersResponse.status === 'fulfilled' && pendingUsersResponse.value.users ? 
                pendingUsersResponse.value.users.length : 0;
            
            const allUsers = allUsersResponse.status === 'fulfilled' && allUsersResponse.value.data ? 
                allUsersResponse.value.data : [];
            
            const totalUsers = allUsers.length;
            const activeUsers = allUsers.filter(u => u.status === 'active').length;
            const blockedUsers = allUsers.filter(u => u.status === 'blocked').length;
            
            const totalStations = stationsResponse.status === 'fulfilled' && stationsResponse.value.data ? 
                stationsResponse.value.data.length : 0;
            
            const inactiveStations = stationsResponse.status === 'fulfilled' && stationsResponse.value.data ? 
                stationsResponse.value.data.filter(s => s.status === 'inactive').length : 0;
            
            const pendingStations = stationsResponse.status === 'fulfilled' && stationsResponse.value.data ? 
                stationsResponse.value.data.filter(s => s.status === 'pending').length : 0;
            
            const totalPowerbanks = powerbanksResponse.status === 'fulfilled' && powerbanksResponse.value.data ? 
                powerbanksResponse.value.data.length : 0;
            
            const brokenPowerbanks = powerbanksResponse.status === 'fulfilled' && powerbanksResponse.value.data ? 
                powerbanksResponse.value.data.filter(p => p.status === 'user_reported_broken' || p.status === 'system_error').length : 0;
            
            const pendingPowerbanks = powerbanksResponse.status === 'fulfilled' && powerbanksResponse.value.data ? 
                powerbanksResponse.value.data.filter(p => p.status === 'pending').length : 0;
            


            return {
                totalUsers: totalUsers,
                pendingUsers: pendingUsers,
                activeUsers: activeUsers,
                totalStations: totalStations,
                inactiveStations: inactiveStations,
                pendingStations: pendingStations,
                totalPowerbanks: totalPowerbanks,
                brokenPowerbanks: brokenPowerbanks,
                pendingPowerbanks: pendingPowerbanks,
            };
        } catch (error) {
            console.error('Ошибка загрузки статистики:', error);
            this.showNotification('Ошибка загрузки статистики', 'error');
            return {
                totalUsers: 0,
                pendingUsers: 0,
                activeUsers: 0,
                totalStations: 0,
                inactiveStations: 0,
                pendingStations: 0,
                totalPowerbanks: 0,
                brokenPowerbanks: 0,
                pendingPowerbanks: 0,
            };
        }
    }

    // Отображение статистики
    displayDashboardStats(stats) {
        $('#totalUsers').text(stats.totalUsers || 0);
        $('#pendingUsers').text(stats.pendingUsers || 0);
        $('#activeUsers').text(stats.activeUsers || 0);
        $('#totalStations').text(stats.totalStations || 0);
        $('#inactiveStations').text(stats.inactiveStations || 0);
        $('#pendingStations').text(stats.pendingStations || 0);
        $('#totalPowerbanks').text(stats.totalPowerbanks || 0);
        $('#brokenPowerbanks').text(stats.brokenPowerbanks || 0);
        $('#pendingPowerbanks').text(stats.pendingPowerbanks || 0);
        
        // Загружаем последние действия
        this.loadRecentActions();
    }
    
    // Загрузка последних действий
    async loadRecentActions() {
        try {
            const token = localStorage.getItem('authToken');
            
            // Загружаем последние действия из заказов
            const ordersResponse = await $.ajax({
                url: `${this.API_BASE}/api/orders`,
                method: 'GET',
                headers: { 'Authorization': `Bearer ${token}` },
                data: { limit: 5 }
            });
            
            if (ordersResponse.data && ordersResponse.data.length > 0) {
                let actionsHtml = '';
                ordersResponse.data.forEach(order => {
                    const time = new Date(order.timestamp).toLocaleString('ru-RU');
                    const action = order.status === 'borrow' ? 'Выдача' : 'Возврат';
                    actionsHtml += `
                        <div class="action-item">
                            <div>${action} повербанка #${order.powerbank_id}</div>
                            <div class="action-time">${time}</div>
                        </div>
                    `;
                });
                $('#recentActions').html(actionsHtml);
            } else {
                $('#recentActions').html('<div class="action-item">Нет недавних действий</div>');
            }
        } catch (error) {
            console.error('Ошибка загрузки последних действий:', error);
            $('#recentActions').html('<div class="action-item">Ошибка загрузки</div>');
        }
    }

    // Система уведомлений
    showNotification(message, type = 'info') {
        const notification = $(`
            <div class="notification notification-${type}">
                <span class="notification-message">${message}</span>
                <button class="notification-close">&times;</button>
            </div>
        `);
        
        // Добавляем в контейнер уведомлений
        if ($('#notifications').length === 0) {
            $('body').append('<div id="notifications"></div>');
        }
        
        $('#notifications').append(notification);
        
        // Автоматическое скрытие через 5 секунд
        setTimeout(() => {
            notification.fadeOut(300, function() {
                $(this).remove();
            });
        }, 5000);
        
        // Закрытие по клику
        notification.find('.notification-close').click(function() {
            notification.fadeOut(300, function() {
                $(this).remove();
            });
        });
    }

    // Загрузка пользователей
    async loadUsers() {
        await this.usersManager.loadUsers();
    }

    // Загрузка групп
    async loadGroups() {
        console.log('🏢 AdminFullManager: Загружаем группы');
        await this.groupsManager.loadGroups();
    }


    // Получение пользователей с кэшированием
    async getUsers() {
        return await this.usersManager.getUsers();
    }

    // Очистка кэша пользователей
    clearUsersCache() {
        this.usersManager.clearUsersCache();
    }

    // Отображение пользователей
    displayUsers(users) {
        this.usersManager.displayUsers(users);
    }

    // Создание таблицы пользователей
    createUsersTable(users) {
        return this.usersManager.createUsersTable(users);
    }

    // Загрузка станций
    async loadStations() {
        console.log('🔄 AdminFullManager: Делегируем загрузку станций в StationsManager');
        console.trace('AdminFullManager: loadStations вызвана из:');
        await this.stationsManager.loadStations();
        console.log('🏁 AdminFullManager: loadStations завершена');
    }

    // Получение станций
    async getStations() {
        console.log('🔄 AdminFullManager: Делегируем получение станций в StationsManager');
        return await this.stationsManager.getStations();
    }

    // Отображение станций
    displayStations(stations) {
        console.log('🖥️ AdminFullManager: Делегируем отображение станций в StationsManager');
        this.stationsManager.displayStations(stations);
    }

    // Загрузка аккумуляторов
    async loadPowerbanks() {
        $('#powerbanksLoading').show();
        $('.powerbanks-table').hide();
        $('#noPowerbanks').hide();
        $('.powerbanks-table').empty();

        try {
            const powerbanks = await this.getPowerbanks();
            this.displayPowerbanks(powerbanks);
            this.showNotification(`Загружено ${powerbanks.length} аккумуляторов`, 'success');
        } catch (error) {
            $('#powerbanksLoading').hide();
            console.error('Ошибка загрузки аккумуляторов:', error);
            this.showNotification('Ошибка загрузки аккумуляторов', 'error');
        }
    }

    // Получение аккумуляторов
    async getPowerbanks() {
        const token = localStorage.getItem('authToken');
        
        try {
            // Пытаемся получить аккумуляторы через API
            const response = await $.ajax({
                url: `${this.API_BASE}/api/powerbanks`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            return response.data || [];
        } catch (error) {
            console.error('Ошибка загрузки аккумуляторов:', error);
            // Возвращаем заглушку если API недоступен
            return [
                {
                    id: 1,
                    model: 'PowerBank Pro 10000',
                    status: 'available',
                    location: 'Станция №1',
                    battery: 85
                },
                {
                    id: 2,
                    model: 'PowerBank Pro 10000',
                    status: 'borrowed',
                    location: 'У пользователя',
                    battery: 45
                }
            ];
        }
    }

    // Отображение аккумуляторов
    displayPowerbanks(powerbanks) {
        $('#powerbanksLoading').hide();
        
        if (powerbanks.length === 0) {
            $('#noPowerbanks').show();
            $('.powerbanks-table').hide();
            return;
        }

        let table = `
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Серийный номер</th>
                        <th>Статус</th>
                        <th>Группа</th>
                        <th>Заряд (SOH)</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
        `;

        powerbanks.forEach(powerbank => {
            const statusText = powerbank.status === 'active' ? 'Активен' :
                              powerbank.status === 'user_reported_broken' ? 'Неисправен' :
                              powerbank.status === 'system_error' ? 'Ошибка системы' :
                              powerbank.status === 'written_off' ? 'Списан' :
                              powerbank.status === 'unknown' ? 'Неизвестно' :
                              powerbank.status === 'pending' ? 'Ожидает' : powerbank.status;
            
            const batteryColor = powerbank.soh > 50 ? 'green' : 
                                 powerbank.soh > 20 ? 'orange' : 'red';
            
            table += `
                <tr>
                    <td>${powerbank.id}</td>
                    <td>${powerbank.serial_number}</td>
                    <td><span class="status-badge status-${powerbank.status}">${statusText}</span></td>
                    <td>${powerbank.org_unit_id ? `Группа ${powerbank.org_unit_id}` : 'Не назначен'}</td>
                    <td><span style="color: ${batteryColor}">${powerbank.soh || 0}%</span></td>
                    <td>
                        ${powerbank.status === 'unknown' ? 
                            `<button class="action-btn success" onclick="adminManager.approvePowerbank(${powerbank.id})">Одобрить</button>` : 
                            `<button class="action-btn primary" onclick="adminManager.editPowerbank(${powerbank.id})">Редактировать</button>`
                        }
                        <button class="action-btn warning" onclick="adminManager.forceEjectPowerbank(${powerbank.id})">Принудительно извлечь</button>
                        <button class="action-btn danger" onclick="adminManager.deletePowerbank(${powerbank.id})">Удалить</button>
                    </td>
                </tr>
            `;
        });

        table += `
                </tbody>
            </table>
        `;

        $('.powerbanks-table').html(table).show();
        $('#noPowerbanks').hide();
    }



    // Загрузка логов
    loadLogs() {
        $('#logsContent').html(`
            <div class="empty-state">
                <div class="empty-state-icon">📋</div>
                <p>Выберите параметры для просмотра логов</p>
            </div>
        `);
    }

    // Фильтрация пользователей
    async filterUsers() {
        await this.usersManager.filterUsers();
    }

    // Фильтрация станций
    async filterStations() {
        console.log('🔍 AdminFullManager: Делегируем фильтрацию станций в StationsManager');
        await this.stationsManager.filterStations();
    }

    // Фильтрация групп
    async filterGroups() {
        console.log('🔍 AdminFullManager: Делегируем фильтрацию групп в GroupsManager');
        await this.groupsManager.filterGroups();
    }


    // Сброс фильтров станций
    async resetStationFilters() {
        console.log('🔄 AdminFullManager: Делегируем сброс фильтров станций в StationsManager');
        await this.stationsManager.resetStationFilters();
    }


    // Удаление станции
    async deleteStation(stationId) {
        console.log('🗑️ AdminFullManager: Делегируем удаление станции в StationsManager');
        await this.stationsManager.deleteStation(stationId);
    }

    // Фильтрация аккумуляторов
    async filterPowerbanks() {
        const searchTerm = $('#powerbankSearch').val().toLowerCase();
        const statusFilter = $('#powerbankStatusFilter').val();
        
        // Показываем индикатор загрузки
        $('#powerbanksLoading').show();
        $('.powerbanks-table').hide();
        $('#noPowerbanks').hide();
        
        try {
            // Загружаем повербанки с сервера
            const powerbanks = await this.getPowerbanks();
            
            // Если все фильтры пустые, показываем все повербанки
            if (!searchTerm && !statusFilter) {
                this.displayPowerbanks(powerbanks);
                $('#powerbanksLoading').hide();
                return;
            }
            
            // Фильтруем данные на клиенте
            let filteredPowerbanks = powerbanks;
            
            // Фильтр по поиску
            if (searchTerm) {
                filteredPowerbanks = filteredPowerbanks.filter(powerbank => 
                    powerbank.serial_number.toLowerCase().includes(searchTerm)
                );
            }
            
            // Фильтр по статусу
            if (statusFilter) {
                const statusMap = {
                    'Активен': 'active',
                    'Неисправен': 'user_reported_broken',
                    'Ошибка системы': 'system_error',
                    'Списан': 'written_off',
                    'Неизвестно': 'unknown',
                    'Ожидает': 'pending'
                };
                const expectedStatus = statusMap[statusFilter];
                filteredPowerbanks = filteredPowerbanks.filter(powerbank => 
                    powerbank.status === expectedStatus
                );
            }
            
            // Отображаем отфильтрованные данные
            this.displayPowerbanks(filteredPowerbanks);
            $('#powerbanksLoading').hide();
            
        } catch (error) {
            $('#powerbanksLoading').hide();
            console.error('Ошибка фильтрации повербанков:', error);
            this.showNotification('Ошибка фильтрации повербанков', 'error');
        }
    }

    // Подтверждение пользователя
    async approveUser(userId) {
        const token = localStorage.getItem('authToken');
        
        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/api/admin/approve-user`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({ user_id: userId })
            });
            
            // Проверяем успешность операции
            if (response && (response.success === true || response.status === 'success' || response.message)) {
                this.showNotification('Пользователь подтвержден', 'success');
                this.clearUsersCache();
                this.loadUsers();
            } else {
                // Если нет явного success, но и нет ошибки - считаем успешным
                this.showNotification('Пользователь подтвержден', 'success');
                this.clearUsersCache();
                this.loadUsers();
            }
        } catch (error) {
            console.error('Ошибка подтверждения пользователя:', error);
            
            // Проверяем, не подтвердился ли пользователь несмотря на ошибку
            if (error.status === 200 || error.responseText) {
                this.showNotification('Пользователь подтвержден', 'success');
                this.loadUsers();
            } else {
                this.showNotification('Ошибка подтверждения пользователя', 'error');
            }
        }
    }

    // Отклонение пользователя
    async rejectUser(userId) {
        const token = localStorage.getItem('authToken');
        
        try {
            const response = await $.ajax({
                url: `${this.API_BASE}/api/admin/reject-user`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({ user_id: userId })
            });
            
            // Проверяем успешность операции
            if (response && (response.success === true || response.status === 'success' || response.message)) {
                this.showNotification('Пользователь отклонен', 'success');
                this.clearUsersCache();
                this.loadUsers();
            } else {
                // Если нет явного success, но и нет ошибки - считаем успешным
                this.showNotification('Пользователь отклонен', 'success');
                this.clearUsersCache();
                this.loadUsers();
            }
        } catch (error) {
            console.error('Ошибка отклонения пользователя:', error);
            
            // Проверяем, не отклонился ли пользователь несмотря на ошибку
            if (error.status === 200 || error.responseText) {
                this.showNotification('Пользователь отклонен', 'success');
                this.loadUsers();
            } else {
                this.showNotification('Ошибка отклонения пользователя', 'error');
            }
        }
    }

    // Удаление пользователя
    async deleteUser(userId) {
        // Делегируем вызов в usersManager
        await this.usersManager.deleteUser(userId);
    }

    // Редактирование группы
    async editGroup(groupId) {
        console.log('🏢 AdminFullManager: Редактирование группы', groupId);
        
        try {
            // Получаем данные группы
            const group = await this.groupsManager.getGroupById(groupId);
            
            if (!group) {
                this.showNotification('Группа не найдена', 'error');
                return;
            }
            
            // Заполняем форму данными группы
            $('#editGroupId').val(group.org_unit_id);
            $('#editGroupName').val(group.name || '');
            $('#editGroupType').val(group.unit_type || 'group');
            $('#editGroupAddress').val(group.adress || '');
            $('#editGroupLogo').val(group.logo_url || '');
            
            // Загружаем группы для выбора родительской
            await this.groupsManager.loadGroupsForSelect('#editParentGroup', groupId);
            
            // Устанавливаем текущую родительскую группу
            $('#editParentGroup').val(group.parent_org_unit_id || '');
            
            // Показываем/скрываем поле родительской группы в зависимости от типа
            if (group.unit_type === 'subgroup') {
                $('#editParentGroupField').show();
            } else {
                $('#editParentGroupField').hide();
            }
            
            // Добавляем обработчик изменения типа
            $('#editGroupType').off('change.editType').on('change.editType', function() {
                const type = $(this).val();
                if (type === 'subgroup') {
                    $('#editParentGroupField').show();
                } else {
                    $('#editParentGroupField').hide();
                    $('#editParentGroup').val('');
                }
            });
            
            // Показываем предварительный просмотр логотипа
            if (group.logo_url) {
                $('#editPreviewImage').attr('src', group.logo_url);
                $('#editLogoPreview').show();
            } else {
                $('#editLogoPreview').hide();
            }
            
            // Показываем модальное окно
            this.showModal('editGroupModal');
            
        } catch (error) {
            console.error('Ошибка загрузки данных группы:', error);
            this.showNotification('Ошибка загрузки данных группы', 'error');
        }
    }

    // Удаление группы
    async deleteGroup(groupId) {
        console.log('🏢 AdminFullManager: Удаление группы', groupId);
        await this.groupsManager.deleteGroup(groupId);
    }

    // Показать модальное окно создания группы
    async showAddGroupModal() {
        console.log('🏢 AdminFullManager: Показываем модальное окно создания группы');
        
        // Очищаем форму
        $('#addGroupForm')[0].reset();
        $('#logoPreview').hide();
        
        // Устанавливаем тип "группа"
        $('#groupType').val('group');
        
        // Скрываем поле родительской группы для обычных групп
        $('#parentGroupField').hide();
        
        // Добавляем обработчик изменения типа
        $('#groupType').off('change.groupType').on('change.groupType', function() {
            const type = $(this).val();
            if (type === 'subgroup') {
                $('#parentGroupField').show();
            } else {
                $('#parentGroupField').hide();
                $('#parentGroup').val('');
            }
        });
        
        // Показываем модальное окно
        this.showModal('addGroupModal');
    }

    // Показать модальное окно создания подгруппы
    async showAddSubgroupModal() {
        console.log('🏢 AdminFullManager: Показываем модальное окно создания подгруппы');
        
        // Очищаем форму
        $('#addSubgroupForm')[0].reset();
        $('#subgroupLogoPreview').hide();
        
        // Загружаем группы для выбора родительской
        await this.groupsManager.loadGroupsForSelect('#subgroupParentGroup');
        
        // Показываем модальное окно
        this.showModal('addSubgroupModal');
    }

    // Закрытие модальных окон групп
    closeGroupModals() {
        this.hideModal('addGroupModal');
        this.hideModal('addSubgroupModal');
        this.hideModal('editGroupModal');
        $('#addGroupForm, #addSubgroupForm, #editGroupForm')[0].reset();
        $('#logoPreview, #subgroupLogoPreview, #editLogoPreview').hide();
    }

    // Сохранение новой группы
    async saveAddGroup() {
        try {
            const formData = {
                name: $('#groupName').val(),
                unit_type: $('#groupType').val(),
                parent_org_unit_id: $('#parentGroup').val() || null,
                adress: $('#groupAddress').val() || null,
                logo_url: $('#groupLogo').val() || null
            };
            
            // Валидация
            if (!formData.name) {
                this.showNotification('Введите название группы', 'error');
                return;
            }
            
            const result = await this.groupsManager.createGroup(formData);
            
            if (result) {
                this.closeGroupModals();
                await this.loadGroups();
            }
        } catch (error) {
            console.error('Ошибка создания группы:', error);
            this.showNotification('Ошибка создания группы: ' + error.message, 'error');
        }
    }

    // Сохранение новой подгруппы
    async saveAddSubgroup() {
        try {
            const formData = {
                name: $('#subgroupName').val(),
                unit_type: 'subgroup',
                parent_org_unit_id: $('#subgroupParentGroup').val() || null,
                adress: $('#subgroupAddress').val() || null,
                logo_url: $('#subgroupLogo').val() || null
            };
            
            // Валидация
            if (!formData.name) {
                this.showNotification('Введите название подгруппы', 'error');
                return;
            }
            
            if (!formData.parent_org_unit_id) {
                this.showNotification('Выберите родительскую группу', 'error');
                return;
            }
            
            const result = await this.groupsManager.createGroup(formData);
            
            if (result) {
                this.closeGroupModals();
                await this.loadGroups();
            }
        } catch (error) {
            console.error('Ошибка создания подгруппы:', error);
            this.showNotification('Ошибка создания подгруппы: ' + error.message, 'error');
        }
    }

    // Сохранение изменений группы
    async saveEditGroup() {
        try {
            const groupId = $('#editGroupId').val();
            const formData = {
                name: $('#editGroupName').val(),
                unit_type: $('#editGroupType').val(),
                parent_org_unit_id: $('#editParentGroup').val() || null,
                adress: $('#editGroupAddress').val() || null,
                logo_url: $('#editGroupLogo').val() || null
            };
            
            // Валидация
            if (!formData.name) {
                this.showNotification('Введите название группы', 'error');
                return;
            }
            
            const result = await this.groupsManager.updateGroup(groupId, formData);
            
            if (result) {
                this.closeGroupModals();
                await this.loadGroups();
            }
        } catch (error) {
            console.error('Ошибка обновления группы:', error);
            this.showNotification('Ошибка обновления группы: ' + error.message, 'error');
        }
    }


    // Редактирование пользователя
    async editUser(userId) {
        try {
            // Получаем данные пользователя
            const users = await this.getUsers();
            const user = users.find(u => u.user_id == userId);
            
            if (!user) {
                this.showNotification('Пользователь не найден', 'error');
                return;
            }
            
            // Заполняем форму данными пользователя
            $('#editUserId').val(user.user_id);
            $('#editUserFio').val(user.fio || '');
            $('#editUserPhone').val(user.phone_e164 || '');
            $('#editUserEmail').val(user.email || '');
            $('#editUserRole').val(user.role || 'user');
            $('#editUserStatus').val(user.статус || 'pending');
            
            // Загружаем все группы и подгруппы для выбора
            await this.groupsManager.loadAllOrgUnitsForSelect('#editUserGroup');
            
            // Устанавливаем текущую группу
            $('#editUserGroup').val(user.parent_org_unit_id || '');
            
            // Показываем модальное окно
            this.showModal('editUserModal');
            
        } catch (error) {
            console.error('Ошибка загрузки данных пользователя:', error);
            this.showNotification('Ошибка загрузки данных пользователя', 'error');
        }
    }




    // Сохранение изменений пользователя
    async saveUserChanges() {
        try {
            const formData = {
                fio: $('#editUserFio').val(),
                phone_e164: $('#editUserPhone').val(),
                email: $('#editUserEmail').val(),
                role: $('#editUserRole').val(),
                parent_org_unit_id: $('#editUserGroup').val() || '',
                статус: $('#editUserStatus').val()
            };
            
            // Валидация обязательных полей
            if (!formData.fio) {
                this.showNotification('Введите ФИО пользователя', 'error');
                return;
            }
            if (!formData.phone_e164) {
                this.showNotification('Введите телефон пользователя', 'error');
                return;
            }
            if (!formData.email) {
                this.showNotification('Введите email пользователя', 'error');
                return;
            }
            if (!formData.role) {
                this.showNotification('Выберите роль пользователя', 'error');
                return;
            }
            if (!formData.статус) {
                this.showNotification('Выберите статус пользователя', 'error');
                return;
            }
            
            const token = localStorage.getItem('authToken');
            
            console.log('🔍 AdminFullManager: Сохраняем пользователя с данными:', formData);
            
            // Обновляем данные пользователя одним запросом
            const response = await $.ajax({
                url: `${this.API_BASE}/api/users/${$('#editUserId').val()}`,
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify(formData)
            });
            
            console.log('📡 AdminFullManager: Ответ от API обновления пользователя:', response);
            
            if (response.success) {
                this.showNotification('Пользователь успешно обновлен', 'success');
                this.closeEditUserModal();
                
                // Очищаем кэш и перезагружаем данные
                this.clearUsersCache();
                this.loadUsers();
            } else {
                this.showNotification(response.error || 'Ошибка обновления пользователя', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка сохранения пользователя:', error);
            this.showNotification('Ошибка сохранения пользователя', 'error');
        }
    }
    
    // Обновление роли пользователя
    async updateUserRole(userId, role) {
        try {
            const token = localStorage.getItem('authToken');
            
            // Сначала удаляем старую роль
            await $.ajax({
                url: `${this.API_BASE}/api/user-roles`,
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` },
                data: { user_id: userId }
            });
            
            // Добавляем новую роль
            await $.ajax({
                url: `${this.API_BASE}/api/user-roles`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    user_id: userId,
                    role: role
                })
            });
            
        } catch (error) {
            console.error('Ошибка обновления роли:', error);
            throw error;
        }
    }
    
    // Закрытие модального окна редактирования
    closeEditUserModal() {
        const modal = bootstrap.Modal.getInstance(document.getElementById('editUserModal'));
        if (modal) {
            modal.hide();
        }
        $('#editUserForm')[0].reset();
    }

    // Одобрение станции
    async approveStation(stationId) {
        try {
            // Получаем данные станции
            const stations = await this.getStations();
            const station = stations.find(s => s.station_id == stationId);
            
            if (!station) {
                this.showNotification('Станция не найдена', 'error');
                return;
            }
            
            
            // Заполняем форму данными станции
            $('#approveStationId').val(station.station_id);
            
            
            // Показываем модальное окно
            this.showModal('approveStationModal');
            
        } catch (error) {
            console.error('Ошибка загрузки данных станции:', error);
            this.showNotification('Ошибка загрузки данных станции', 'error');
        }
    }

    // Редактирование станции
    async editStation(stationId) {
        try {
            // Получаем данные станции
            const stations = await this.getStations();
            const station = stations.find(s => s.station_id == stationId);
            
            if (!station) {
                this.showNotification('Станция не найдена', 'error');
                return;
            }
            
            // Заполняем форму данными станции
            $('#editStationId').val(station.station_id);
            $('#editStationBoxId').val(station.box_id);
            $('#editStationIccid').val(station.iccid || '');
            
            // Загружаем все группы и подгруппы для выбора
            await this.groupsManager.loadAllOrgUnitsForSelect('#editStationGroup');
            
            // Устанавливаем текущую группу
            $('#editStationGroup').val(station.org_unit_id || '');
            
            // Показываем модальное окно
            this.showModal('editStationModal');
            
        } catch (error) {
            console.error('Ошибка загрузки данных станции:', error);
            this.showNotification('Ошибка загрузки данных станции', 'error');
        }
    }


    // Сохранение одобрения станции
    async saveStationApproval() {
        try {
            const stationId = $('#approveStationId').val();
            const secretKey = $('#approveStationKey').val();
            const orgUnitId = $('#approveStationGroup').val();
            
            
            // Валидация
            if (!secretKey || !orgUnitId) {
                let errorMessage = 'Заполните все обязательные поля:';
                if (!secretKey) errorMessage += ' Секретный ключ';
                if (!orgUnitId) errorMessage += ' Группа/Подгруппа';
                
                this.showNotification(errorMessage, 'error');
                return;
            }
            
            const token = localStorage.getItem('authToken');
            
            // 1. Обновляем станцию (статус и группу)
            const stationData = {
                org_unit_id: orgUnitId,
                status: 'active' // Меняем статус на активный
            };
            
            await $.ajax({
                url: `${this.API_BASE}/api/stations/${stationId}`,
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify(stationData)
            });
            
            // 2. Создаем секретный ключ для станции
            const secretKeyData = {
                station_id: parseInt(stationId),
                key_value: secretKey
            };
            
            await $.ajax({
                url: `${this.API_BASE}/api/station-secret-keys`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify(secretKeyData)
            });
            
            this.showNotification('Станция успешно одобрена', 'success');
            this.closeApproveStationModal();
            
            // Перезагружаем данные станций
            console.log('🔄 AdminFullManager: Перезагружаем станции после одобрения');
            await this.stationsManager.loadStations();
            
        } catch (error) {
            console.error('Ошибка одобрения станции:', error);
            this.showNotification('Ошибка одобрения станции', 'error');
        }
    }

    // Сохранение изменений станции
    async saveStationChanges() {
        try {
            const formData = {
                station_id: $('#editStationId').val(),
                org_unit_id: $('#editStationGroup').val()
            };
            
            // Валидация
            if (!formData.org_unit_id) {
                this.showNotification('Выберите группу/подгруппу', 'error');
                return;
            }
            
            const token = localStorage.getItem('authToken');
            
            // Обновляем станцию
            const response = await $.ajax({
                url: `${this.API_BASE}/api/stations/${formData.station_id}`,
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify(formData)
            });
            
            this.showNotification('Станция успешно обновлена', 'success');
            this.closeEditStationModal();
            
            // Перезагружаем данные станций
            console.log('🔄 AdminFullManager: Перезагружаем станции после редактирования');
            await this.stationsManager.loadStations();
            
        } catch (error) {
            console.error('Ошибка сохранения станции:', error);
            this.showNotification('Ошибка сохранения станции', 'error');
        }
    }

    // Закрытие модального окна одобрения станции
    closeApproveStationModal() {
        this.hideModal('approveStationModal');
        $('#approveStationForm')[0].reset();
    }

    // Закрытие модального окна редактирования станции
    closeEditStationModal() {
        this.hideModal('editStationModal');
        $('#editStationForm')[0].reset();
        $('#editStationCurrentGroup').val('');
    }

    // Модальные окна
    showAddUserModal() {
        alert('Функция добавления пользователя будет реализована');
    }

    showAddStationModal() {
        alert('Функция добавления станции будет реализована');
    }


    // Одобрение аккумулятора
    async approvePowerbank(powerbankId) {
        try {
            // Получаем данные аккумулятора
            const powerbanks = await this.getPowerbanks();
            const powerbank = powerbanks.find(p => p.id == powerbankId);
            
            if (!powerbank) {
                this.showNotification('Аккумулятор не найден', 'error');
                return;
            }
            
            // Заполняем форму данными аккумулятора
            $('#approvePowerbankId').val(powerbank.id);
            $('#approvePowerbankSerial').val(powerbank.serial_number);
            
            // Загружаем все группы и подгруппы для выбора
            await this.groupsManager.loadAllOrgUnitsForSelect('#approvePowerbankGroup');
            
            // Показываем модальное окно
            this.showModal('approvePowerbankModal');
            
        } catch (error) {
            console.error('Ошибка загрузки данных аккумулятора:', error);
            this.showNotification('Ошибка загрузки данных аккумулятора', 'error');
        }
    }

    // Сохранение одобрения аккумулятора
    async savePowerbankApproval() {
        try {
            const formData = {
                powerbank_id: $('#approvePowerbankId').val(),
                org_unit_id: $('#approvePowerbankGroup').val()
            };
            
            // Валидация
            if (!formData.org_unit_id) {
                this.showNotification('Выберите группу/подгруппу', 'error');
                return;
            }
            
            const token = localStorage.getItem('authToken');
            
            // Отправляем запрос на одобрение аккумулятора
            const response = await $.ajax({
                url: `${this.API_BASE}/api/powerbanks/${formData.powerbank_id}/approve`,
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    org_unit_id: formData.org_unit_id
                })
            });
            
            if (response.success) {
                this.showNotification('Аккумулятор успешно одобрен', 'success');
                this.closeApprovePowerbankModal();
                
                // Перезагружаем данные аккумуляторов
                await this.loadPowerbanks();
            } else {
                this.showNotification(response.message || 'Ошибка одобрения аккумулятора', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка одобрения аккумулятора:', error);
            this.showNotification('Ошибка одобрения аккумулятора', 'error');
        }
    }

    // Закрытие модального окна одобрения аккумулятора
    closeApprovePowerbankModal() {
        this.hideModal('approvePowerbankModal');
        $('#approvePowerbankForm')[0].reset();
    }

    // Редактирование аккумулятора
    async editPowerbank(powerbankId) {
        try {
            // Получаем данные аккумулятора
            const powerbanks = await this.getPowerbanks();
            const powerbank = powerbanks.find(p => p.id == powerbankId);
            
            if (!powerbank) {
                this.showNotification('Аккумулятор не найден', 'error');
                return;
            }
            
            // Заполняем форму данными аккумулятора
            $('#editPowerbankId').val(powerbank.id);
            $('#editPowerbankSerial').val(powerbank.serial_number);
            $('#editPowerbankSoh').val(powerbank.soh || 0);
            $('#editPowerbankStatus').val(powerbank.status);
            $('#editPowerbankWriteOffReason').val(powerbank.write_off_reason || 'none');
            
            // Загружаем все группы и подгруппы для выбора
            await this.groupsManager.loadAllOrgUnitsForSelect('#editPowerbankGroup');
            
            // Устанавливаем текущую группу
            $('#editPowerbankGroup').val(powerbank.org_unit_id || '');
            
            // Показываем модальное окно
            this.showModal('editPowerbankModal');
            
        } catch (error) {
            console.error('Ошибка загрузки данных аккумулятора:', error);
            this.showNotification('Ошибка загрузки данных аккумулятора', 'error');
        }
    }

    // Сохранение изменений аккумулятора
    async savePowerbankChanges() {
        try {
            const formData = {
                powerbank_id: $('#editPowerbankId').val(),
                org_unit_id: $('#editPowerbankGroup').val() || null,
                soh: parseInt($('#editPowerbankSoh').val()) || 0,
                status: $('#editPowerbankStatus').val(),
                write_off_reason: $('#editPowerbankWriteOffReason').val()
            };
            
            // Валидация
            if (!formData.status) {
                this.showNotification('Выберите статус аккумулятора', 'error');
                return;
            }
            
            if (formData.soh < 0 || formData.soh > 100) {
                this.showNotification('Уровень заряда должен быть от 0 до 100', 'error');
                return;
            }
            
            const token = localStorage.getItem('authToken');
            
            // Отправляем запрос на обновление аккумулятора
            const response = await $.ajax({
                url: `${this.API_BASE}/api/powerbanks/${formData.powerbank_id}`,
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    org_unit_id: formData.org_unit_id,
                    soh: formData.soh,
                    status: formData.status,
                    write_off_reason: formData.write_off_reason
                })
            });
            
            if (response.success) {
                this.showNotification('Аккумулятор успешно обновлен', 'success');
                this.closeEditPowerbankModal();
                
                // Перезагружаем данные аккумуляторов
                await this.loadPowerbanks();
            } else {
                this.showNotification(response.message || 'Ошибка обновления аккумулятора', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка обновления аккумулятора:', error);
            this.showNotification('Ошибка обновления аккумулятора', 'error');
        }
    }

    // Закрытие модального окна редактирования аккумулятора
    closeEditPowerbankModal() {
        this.hideModal('editPowerbankModal');
        $('#editPowerbankForm')[0].reset();
    }

    // Просмотр станции
    async viewStation(stationId) {
        try {
            // Сохраняем ID текущей просматриваемой станции
            this.currentStationId = stationId;
            
            // Получаем данные станции
            const stations = await this.getStations();
            const station = stations.find(s => s.station_id == stationId);
            
            if (!station) {
                this.showNotification('Станция не найдена', 'error');
                return;
            }
            
            // Заполняем информацию о станции
            $('#viewStationBoxId').text(station.box_id);
            $('#viewStationIccid').text(station.iccid || 'Не указан');
            $('#viewStationTotalSlots').text(station.slots_declared || 0);
            $('#viewStationStatus').text(this.getStationStatusText(station.status));
            $('#viewStationLastSeen').text(station.last_seen ? new Date(station.last_seen).toLocaleString() : 'Никогда');
            
            // Загружаем повербанки в станции
            await this.loadStationPowerbanks(stationId);
            
            // Показываем модальное окно
            document.getElementById('viewStationModal').classList.add('show');
            
        } catch (error) {
            console.error('Ошибка загрузки данных станции:', error);
            this.showNotification('Ошибка загрузки данных станции', 'error');
        }
    }

    // Загрузка повербанков в станции
    async loadStationPowerbanks(stationId) {
        try {
            const token = localStorage.getItem('authToken');
            
            // Загружаем данные station_powerbank для этой станции
            const response = await $.ajax({
                url: `${this.API_BASE}/api/station-powerbanks?station_id=${stationId}`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            if (response.success) {
                await this.displayStationPowerbanks(response.data, stationId);
            } else {
                this.showNotification('Ошибка загрузки повербанков станции', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка загрузки повербанков станции:', error);
            this.showNotification('Ошибка загрузки повербанков станции', 'error');
        }
    }


    // Отображение повербанков в станции
    async displayStationPowerbanks(stationPowerbanks, stationId) {
        const grid = $('#powerbanksGrid');
        grid.empty();
        
        // Получаем данные станции для правильного количества слотов
        const stations = await this.getStations();
        const station = stations.find(s => s.station_id == stationId);
        const totalSlots = station ? (station.slots_declared || 0) : 0;
        
        // Подсчитываем статистику
        const occupiedSlots = stationPowerbanks.length;
        const freeSlots = totalSlots - occupiedSlots;
        
        // Обновляем статистику
        $('#viewStationOccupiedSlots').text(occupiedSlots);
        $('#viewStationFreeSlots').text(freeSlots);
        
        // Получаем данные повербанков для правильного статуса
        const powerbanks = await this.getPowerbanks();
        
        // Создаем слоты
        for (let slot = 1; slot <= totalSlots; slot++) {
            const powerbank = stationPowerbanks.find(sp => sp.slot_number === slot);
            
            if (powerbank) {
                // Слот занят повербанком
                const levelClass = this.getBatteryLevelClass(powerbank.level);
                
                // Получаем правильный статус из таблицы powerbank
                const powerbankData = powerbanks.find(p => p.id == powerbank.powerbank_id);
                const powerbankStatus = powerbankData ? powerbankData.status : 'unknown';
                const statusClass = this.getPowerbankStatusClass(powerbankStatus);
                const hasError = this.checkPowerbankErrors(powerbank, powerbankStatus);
                
                grid.append(`
                    <div class="powerbank-slot ${hasError ? 'error' : 'occupied'}">
                        <div class="slot-number">Слот ${slot}</div>
                        <div class="powerbank-info">
                            <div>ID: ${powerbank.powerbank_id}</div>
                            <div>Серийный: ${powerbank.powerbank_serial || 'N/A'}</div>
                        </div>
                        <div class="powerbank-status ${statusClass}">${this.getPowerbankStatusText(powerbankStatus)}</div>
                        <div class="battery-level ${levelClass}">${powerbank.level || 0}%</div>
                        <div class="powerbank-info">
                            <div>Напряжение: ${powerbank.voltage || 0}mV</div>
                            <div>Температура: ${powerbank.temperature || 0}°C</div>
                        </div>
                        ${hasError ? `<div class="error-info">Ошибки: ${this.getErrorDetails(powerbank, powerbankStatus)}</div>` : ''}
                        <div style="display: flex; gap: 5px; margin-top: 8px;">
                            <button class="action-btn primary small" onclick="adminManager.borrowPowerbank(${powerbank.powerbank_id}, ${stationId}, ${slot})">
                                Выдать
                            </button>
                            <button class="action-btn warning small" onclick="adminManager.forceEjectPowerbank(${powerbank.powerbank_id})">
                                Извлечь
                            </button>
                        </div>
                    </div>
                `);
            } else {
                // Пустой слот
                grid.append(`
                    <div class="powerbank-slot empty">
                        <div class="slot-number">Слот ${slot}</div>
                        <div class="powerbank-info">Пусто</div>
                        <button class="action-btn secondary borrow-btn" disabled>
                            Пусто
                        </button>
                    </div>
                `);
            }
        }
    }

    // Получение класса уровня батареи
    getBatteryLevelClass(level) {
        if (level >= 70) return 'high';
        if (level >= 30) return 'medium';
        return 'low';
    }

    // Получение статуса повербанка из данных инвентаря
    getPowerbankStatusFromInventory(powerbank) {
        if (powerbank.status_bits) {
            // Анализируем status_bits для определения статуса
            const bits = powerbank.status_bits;
            if (bits.charging) return 'charging';
            if (bits.fully_charged) return 'fully_charged';
            if (bits.low_battery) return 'low_battery';
            if (bits.error) return 'error';
            return 'available';
        }
        return powerbank.status || 'unknown';
    }

    // Проверка ошибок повербанка из данных инвентаря
    checkPowerbankErrorsFromInventory(powerbank, status) {
        if (powerbank.status_bits) {
            const bits = powerbank.status_bits;
            return bits.error || bits.overheating || bits.overvoltage || bits.undervoltage;
        }
        return status === 'error';
    }

    // Получение деталей ошибок из данных инвентаря
    getErrorDetailsFromInventory(powerbank, status) {
        if (!powerbank.status_bits) return status === 'error' ? 'Неизвестная ошибка' : '';
        
        const bits = powerbank.status_bits;
        const errors = [];
        
        if (bits.error) errors.push('Ошибка');
        if (bits.overheating) errors.push('Перегрев');
        if (bits.overvoltage) errors.push('Перенапряжение');
        if (bits.undervoltage) errors.push('Недонапряжение');
        if (bits.communication_error) errors.push('Ошибка связи');
        
        return errors.length > 0 ? errors.join(', ') : '';
    }




    // Запрос статуса станции
    async queryStationStatus(stationId) {
        if (!stationId) {
            this.showNotification('Не выбрана станция для запроса статуса', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            this.showNotification('Запрашиваем статус станции...', 'info');
            
            // Получаем информацию о станции
            const response = await $.ajax({
                url: `${this.API_BASE}/api/stations/${stationId}`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            if (response.success) {
                const station = response.data;
                const statusInfo = `
                    Статус станции ${station.box_id}:
                    • Статус: ${this.getStationStatusText(station.status)}
                    • Последний контакт: ${station.last_seen ? new Date(station.last_seen).toLocaleString() : 'Никогда'}
                    • Слотов: ${station.slots_declared || 0}
                    • Свободно: ${station.remain_num || 0}
                    • ICCID: ${station.iccid || 'Не указан'}
                `;
                
                this.showNotification(statusInfo, 'info');
                console.log('📊 Статус станции:', station);
            } else {
                this.showNotification('Ошибка получения статуса станции', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка запроса статуса станции:', error);
            this.showNotification('Ошибка запроса статуса станции', 'error');
        }
    }

    // Перезагрузка станции
    async restartStation(stationId) {
        if (!stationId) {
            this.showNotification('Не выбрана станция для перезагрузки', 'error');
            return;
        }

        // Подтверждение действия
        const confirmed = confirm(`Вы уверены, что хотите перезагрузить станцию ${stationId}?\n\nЭто действие отправит команду перезагрузки на станцию.`);
        if (!confirmed) {
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            this.showNotification('Отправляем команду перезагрузки...', 'info');
            
            // Отправляем команду перезагрузки
            const response = await $.ajax({
                url: `${this.API_BASE}/api/restart-cabinet`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    station_id: stationId
                })
            });
            
            if (response.message) {
                this.showNotification(`✅ ${response.message}. Станция переведена в режим неактивна.`, 'success');
                console.log('🔄 Команда перезагрузки отправлена:', response);
                
                // Показываем дополнительную информацию
                if (response.packet_hex) {
                    console.log('📦 Пакет команды:', response.packet_hex);
                    this.showPacketModal('Перезагрузка кабинета', response.packet_hex, response);
                }
                
                // Обновляем список станций, чтобы показать новый статус
                setTimeout(() => {
                    this.loadStations();
                }, 1000);
            } else {
                this.showNotification('Ошибка отправки команды перезагрузки', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка перезагрузки станции:', error);
            let errorMessage = 'Ошибка перезагрузки станции';
            
            if (error.responseJSON && error.responseJSON.error) {
                errorMessage = error.responseJSON.error;
            } else if (error.status === 401) {
                errorMessage = 'Недостаточно прав для перезагрузки станции';
            } else if (error.status === 404) {
                errorMessage = 'Станция не найдена или не подключена';
            }
            
            this.showNotification(errorMessage, 'error');
        }
    }







    // Универсальное модальное окно
    showModal(title, content) {
        console.log('📱 showModal вызвана с заголовком:', title);
        console.log('📱 showModal контент:', content);
        
        const modalHtml = `
            <div id="infoModal" class="modal fade" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">${title}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            ${content}
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Удаляем предыдущее модальное окно если есть
        $('#infoModal').remove();
        
        // Добавляем новое модальное окно
        $('body').append(modalHtml);
        
        // Показываем модальное окно используя Bootstrap 5 API
        const modalElement = document.getElementById('infoModal');
        const modal = new bootstrap.Modal(modalElement);
        modal.show();
        
        console.log('📱 Модальное окно должно быть показано');
    }

    // Закрытие модального окна
    closeModal() {
        const modalElement = document.getElementById('infoModal');
        if (modalElement) {
            const modal = bootstrap.Modal.getInstance(modalElement);
            if (modal) {
                modal.hide();
            } else {
                modalElement.remove();
            }
        }
    }

    // Получение класса статуса повербанка
    getPowerbankStatusClass(status) {
        switch (status) {
            case 'active': return 'active';
            case 'unknown': return 'unknown';
            case 'user_reported_broken':
            case 'system_error':
            case 'written_off': return 'broken';
            default: return 'unknown';
        }
    }

    // Получение текста статуса повербанка
    getPowerbankStatusText(status) {
        switch (status) {
            case 'active': return 'Активен';
            case 'unknown': return 'Неизвестно';
            case 'user_reported_broken': return 'Неисправен';
            case 'system_error': return 'Ошибка';
            case 'written_off': return 'Списан';
            default: return 'Неизвестно';
        }
    }

    // Получение текста статуса станции
    getStationStatusText(status) {
        switch (status) {
            case 'active': return 'Активна';
            case 'pending': return 'Ожидает одобрения';
            case 'inactive': return 'Неактивна';
            default: return 'Неизвестно';
        }
    }

    // Проверка ошибок повербанка
    checkPowerbankErrors(powerbank, powerbankStatus) {
        const errors = [];
        
        if (powerbank.level < 10) errors.push('Низкий заряд');
        if (powerbank.voltage < 3000) errors.push('Низкое напряжение');
        if (powerbank.temperature > 60) errors.push('Высокая температура');
        if (powerbank.temperature < -10) errors.push('Низкая температура');
        if (powerbankStatus === 'system_error') errors.push('Системная ошибка');
        if (powerbankStatus === 'user_reported_broken') errors.push('Неисправен');
        
        return errors.length > 0;
    }

    // Получение деталей ошибок
    getErrorDetails(powerbank, powerbankStatus) {
        const errors = [];
        
        if (powerbank.level < 10) errors.push('Низкий заряд');
        if (powerbank.voltage < 3000) errors.push('Низкое напряжение');
        if (powerbank.temperature > 60) errors.push('Высокая температура');
        if (powerbank.temperature < -10) errors.push('Низкая температура');
        if (powerbankStatus === 'system_error') errors.push('Системная ошибка');
        if (powerbankStatus === 'user_reported_broken') errors.push('Неисправен');
        
        return errors.join(', ');
    }

    // Выдача повербанка
    async borrowPowerbank(powerbankId, stationId, slotNumber) {
        if (confirm(`Выдать повербанк ID ${powerbankId} из слота ${slotNumber}?`)) {
            try {
                const token = localStorage.getItem('authToken');
                
                // Получаем ID текущего пользователя (админа)
                const user = JSON.parse(localStorage.getItem('currentUser') || '{}');
                console.log('🔍 AdminFullManager: Данные пользователя из localStorage:', user);
                
                // Пробуем разные варианты получения ID
                const userId = user.id || user.user_id || user.userId;
                console.log('🔍 AdminFullManager: Извлеченный userId:', userId);
                
                if (!userId) {
                    console.error('❌ AdminFullManager: Не удалось найти ID пользователя в localStorage');
                    
                    // Пробуем получить данные пользователя через API
                    try {
                        console.log('🔍 AdminFullManager: Пробуем получить данные пользователя через API');
                        const profileResponse = await $.ajax({
                            url: `${this.API_BASE}/api/auth/profile`,
                            method: 'GET',
                            headers: {
                                'Authorization': `Bearer ${token}`
                            }
                        });
                        
                        if (profileResponse.success && profileResponse.data) {
                            const apiUserId = profileResponse.data.id || profileResponse.data.user_id || profileResponse.data.userId;
                            console.log('🔍 AdminFullManager: Получен userId через API:', apiUserId);
                            
                            if (apiUserId) {
                                // Используем ID из API
                                await this.performBorrowRequest(stationId, slotNumber, apiUserId, token);
                                return;
                            }
                        }
                    } catch (apiError) {
                        console.error('❌ AdminFullManager: Ошибка получения профиля через API:', apiError);
                    }
                    
                    this.showNotification('Ошибка: пользователь не найден. Попробуйте перелогиниться.', 'error');
                    return;
                }
                
                // Выполняем запрос на выдачу
                await this.performBorrowRequest(stationId, slotNumber, userId, token);
                
            } catch (error) {
                console.error('Ошибка выдачи повербанка:', error);
                this.showNotification('Ошибка выдачи повербанка', 'error');
            }
        }
    }

    // Выполнение запроса на выдачу повербанка
    async performBorrowRequest(stationId, slotNumber, userId, token) {
        try {
            console.log(`🚀 AdminFullManager: Отправляем запрос на выдачу: станция ${stationId}, слот ${slotNumber}, пользователь ${userId}`);
            
            // Отправляем запрос на выдачу повербанка
            const response = await $.ajax({
                url: `${this.API_BASE}/api/borrow/stations/${stationId}/request`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    slot_number: slotNumber,
                    user_id: userId
                })
            });
            
            console.log('📡 AdminFullManager: Ответ от API выдачи:', response);
            
            if (response.success) {
                this.showNotification('Запрос на выдачу повербанка отправлен станции', 'success');
                
                // Показываем пакет если есть
                if (response.packet_hex) {
                    console.log('📦 Пакет выдачи повербанка:', response.packet_hex);
                    this.showPacketModal('Выдача повербанка', response.packet_hex, response);
                }
                
                // Перезагружаем данные станции
                await this.loadStationPowerbanks(stationId);
            } else {
                this.showNotification(response.message || 'Ошибка выдачи повербанка', 'error');
            }
            
        } catch (error) {
            console.error('❌ AdminFullManager: Ошибка выполнения запроса выдачи:', error);
            this.showNotification('Ошибка выдачи повербанка', 'error');
        }
    }

    // Закрытие модального окна просмотра станции
    closeViewStationModal() {
        document.getElementById('viewStationModal').classList.remove('show');
    }

    // Показать модальное окно управления громкостью
    async showVoiceVolumeModal() {
        const stationId = this.currentStationId;
        if (!stationId) {
            this.showNotification('Не выбрана станция для управления громкостью', 'error');
            return;
        }

        try {
            // Получаем данные станции
            const stations = await this.getStations();
            const station = stations.find(s => s.station_id == stationId);
            
            if (!station) {
                this.showNotification('Станция не найдена', 'error');
                return;
            }

            // Заполняем информацию о станции
            $('#volumeStationBoxId').text(station.box_id);
            $('#currentVolumeLevel').text('Загрузка...');
            $('#volumeResult').hide();

            // Запрашиваем текущий уровень громкости
            await this.queryVoiceVolume(stationId);

            // Показываем модальное окно
            document.getElementById('voiceVolumeModal').classList.add('show');

        } catch (error) {
            console.error('Ошибка открытия модального окна громкости:', error);
            this.showNotification('Ошибка открытия модального окна громкости', 'error');
        }
    }

    // Закрытие модального окна управления громкостью
    closeVoiceVolumeModal() {
        document.getElementById('voiceVolumeModal').classList.remove('show');
    }

    // Показать модальное окно управления адресом сервера
    showServerAddressModal() {
        const stationId = this.currentStationId;
        if (!stationId) {
            this.showNotification('Не выбрана станция для управления адресом сервера', 'error');
            return;
        }

        try {
            // Получаем данные станции из текущего модального окна
            const boxId = $('#viewStationBoxId').text();
            if (!boxId) {
                this.showNotification('Ошибка: данные станции не найдены', 'error');
                return;
            }

            // Заполняем информацию о станции
            $('#addressStationBoxId').text(boxId);
            $('#currentServerAddress').text('Загрузка...');
            
            // Очищаем поля ввода
            $('#serverAddressInput').val('');
            $('#serverPortInput').val('');
            $('#heartbeatIntervalInput').val('30');
            $('#addressResult').hide();

            // Показываем модальное окно
            document.getElementById('serverAddressModal').classList.add('show');

            // Автоматически запрашиваем текущий адрес сервера
            this.queryCurrentServerAddress();
        } catch (error) {
            console.error('Ошибка открытия модального окна адреса сервера:', error);
            this.showNotification('Ошибка открытия модального окна адреса сервера', 'error');
        }
    }

    // Закрытие модального окна управления адресом сервера
    closeServerAddressModal() {
        document.getElementById('serverAddressModal').classList.remove('show');
    }

    // Запрос текущего адреса сервера
    async queryCurrentServerAddress() {
        const stationId = this.currentStationId;
        if (!stationId) {
            this.showNotification('Ошибка: не выбрана станция', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            
            // Сначала отправляем запрос на станцию
            const queryResponse = await $.ajax({
                url: `${this.API_BASE}/api/query-server-address`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    station_id: stationId
                })
            });

            if (queryResponse.success) {
                // Показываем, что запрос отправлен
                $('#currentServerAddress').text('Ожидание ответа...');
                $('#addressResult').html(`
                    <div class="success-message">
                        ✅ Запрос адреса сервера отправлен на станцию. Ожидание ответа...
                    </div>
                `).show();
                
                // Ждем немного и запрашиваем данные
                setTimeout(async () => {
                    await this.getServerAddressData(stationId);
                }, 2000);
            } else {
                $('#currentServerAddress').text('Ошибка отправки');
                $('#addressResult').html(`
                    <div class="error-message">
                        ❌ Ошибка отправки запроса: ${queryResponse.error || 'Не удалось отправить запрос'}
                    </div>
                `).show();
            }

        } catch (error) {
            console.error('Ошибка запроса адреса сервера:', error);
            $('#currentServerAddress').text('Ошибка загрузки');
            $('#addressResult').html(`
                <div class="error-message">
                    ❌ Ошибка запроса адреса сервера: ${error.responseJSON?.error || error.statusText || 'Неизвестная ошибка'}
                </div>
            `).show();
        }
    }

    // Получение данных о адресе сервера с сервера
    async getServerAddressData(stationId) {
        try {
            const token = localStorage.getItem('authToken');
            
            const response = await $.ajax({
                url: `${this.API_BASE}/api/query-server-address/station/${stationId}`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.success) {
                const serverAddress = response.server_address;
                const address = serverAddress.address || 'N/A';
                const port = serverAddress.port || 'N/A';
                const heartbeat = serverAddress.heartbeat_interval || 'N/A';
                
                $('#currentServerAddress').text(`${address}:${port} (heartbeat: ${heartbeat}s)`);
                
                // Заполняем поля ввода текущими значениями
                if (address !== 'N/A') {
                    $('#serverAddressInput').val(address);
                }
                if (port !== 'N/A') {
                    $('#serverPortInput').val(port);
                }
                if (heartbeat !== 'N/A') {
                    $('#heartbeatIntervalInput').val(heartbeat);
                }
                
                // Показываем результат с дополнительной информацией
                $('#addressResult').html(`
                    <div class="success-message">
                        ✅ Текущий адрес сервера: ${address}:${port}
                        <br><small>Интервал heartbeat: ${heartbeat} секунд</small>
                        <br><small>Последнее обновление: ${new Date(serverAddress.last_update).toLocaleString()}</small>
                        <br><small>Пакет: ${serverAddress.packet_hex}</small>
                    </div>
                `).show();
            } else {
                $('#currentServerAddress').text('Данные не найдены');
                $('#addressResult').html(`
                    <div class="error-message">
                        ❌ Ошибка: ${response.error || 'Данные о адресе сервера не найдены'}
                    </div>
                `).show();
            }

        } catch (error) {
            console.error('Ошибка получения данных адреса сервера:', error);
            $('#currentServerAddress').text('Ошибка загрузки');
            $('#addressResult').html(`
                <div class="error-message">
                    ❌ Ошибка получения данных: ${error.responseJSON?.error || error.statusText || 'Неизвестная ошибка'}
                </div>
            `).show();
        }
    }

    // Установка адреса сервера
    async setServerAddress() {
        const stationId = this.currentStationId;
        if (!stationId) {
            this.showNotification('Ошибка: не выбрана станция', 'error');
            return;
        }

        const serverAddress = $('#serverAddressInput').val().trim();
        const serverPort = $('#serverPortInput').val().trim();
        const heartbeatInterval = parseInt($('#heartbeatIntervalInput').val());

        // Валидация
        if (!serverAddress) {
            $('#addressResult').html(`
                <div class="error-message">
                    ❌ Введите адрес сервера
                </div>
            `).show();
            return;
        }

        if (!serverPort) {
            $('#addressResult').html(`
                <div class="error-message">
                    ❌ Введите порт сервера
                </div>
            `).show();
            return;
        }

        if (isNaN(heartbeatInterval) || heartbeatInterval < 1 || heartbeatInterval > 255) {
            $('#addressResult').html(`
                <div class="error-message">
                    ❌ Интервал heartbeat должен быть от 1 до 255 секунд
                </div>
            `).show();
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            
            const response = await $.ajax({
                url: `${this.API_BASE}/api/set-server-address`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    station_id: stationId,
                    server_address: serverAddress,
                    server_port: serverPort,
                    heartbeat_interval: heartbeatInterval
                })
            });

            if (response.success) {
                $('#addressResult').html(`
                    <div class="success-message">
                        ✅ Адрес сервера ${serverAddress}:${serverPort} установлен для станции
                        <br><small>Интервал heartbeat: ${heartbeatInterval} секунд</small>
                        <br><small>Станция будет перезагружена для применения изменений</small>
                    </div>
                `).show();
            } else {
                $('#addressResult').html(`
                    <div class="error-message">
                        ❌ Ошибка установки адреса: ${response.error || 'Не удалось установить адрес сервера'}
                    </div>
                `).show();
            }

        } catch (error) {
            console.error('Ошибка установки адреса сервера:', error);
            $('#addressResult').html(`
                <div class="error-message">
                    ❌ Ошибка установки адреса: ${error.responseJSON?.error || error.statusText || 'Неизвестная ошибка'}
                </div>
            `).show();
        }
    }

    // Запрос текущего уровня громкости
    async queryVoiceVolume(stationId) {
        try {
            const token = localStorage.getItem('authToken');
            
            // Сначала отправляем запрос на станцию
            const queryResponse = await $.ajax({
                url: `${this.API_BASE}/api/query-voice-volume`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    station_id: stationId
                })
            });

            if (queryResponse.success) {
                // Показываем, что запрос отправлен
                $('#currentVolumeLevel').text('Ожидание ответа...');
                $('#volumeResult').html(`
                    <div class="success-message">
                        ✅ Запрос громкости отправлен на станцию. Ожидание ответа...
                    </div>
                `).show();
                
                // Ждем немного и запрашиваем данные
                setTimeout(async () => {
                    await this.getVoiceVolumeData(stationId);
                }, 2000);
            } else {
                $('#currentVolumeLevel').text('Ошибка отправки');
                $('#volumeResult').html(`
                    <div class="error-message">
                        ❌ Ошибка отправки запроса: ${queryResponse.error || 'Не удалось отправить запрос'}
                    </div>
                `).show();
            }

        } catch (error) {
            console.error('Ошибка запроса громкости:', error);
            $('#currentVolumeLevel').text('Ошибка загрузки');
            $('#volumeResult').html(`
                <div class="error-message">
                    ❌ Ошибка запроса громкости: ${error.responseJSON?.error || error.statusText || 'Неизвестная ошибка'}
                </div>
            `).show();
        }
    }

    // Получение данных о громкости с сервера
    async getVoiceVolumeData(stationId) {
        try {
            const token = localStorage.getItem('authToken');
            
            const response = await $.ajax({
                url: `${this.API_BASE}/api/query-voice-volume/station/${stationId}`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.success) {
                const voiceVolume = response.voice_volume;
                const volumeLevel = voiceVolume.volume_level || 0;
                const volumePercentage = voiceVolume.volume_percentage || 0;
                
                $('#currentVolumeLevel').text(`${volumeLevel} (${volumePercentage}%)`);
                $('#volumeSlider').val(volumeLevel);
                this.updateVolumeDisplay(volumeLevel);
                
                // Показываем результат с дополнительной информацией
                $('#volumeResult').html(`
                    <div class="success-message">
                        ✅ Текущий уровень громкости: ${volumeLevel} (${volumePercentage}%)
                        <br><small>Последнее обновление: ${new Date(voiceVolume.last_update).toLocaleString()}</small>
                        <br><small>Пакет: ${voiceVolume.packet_hex}</small>
                    </div>
                `).show();
            } else {
                $('#currentVolumeLevel').text('Данные не найдены');
                $('#volumeResult').html(`
                    <div class="error-message">
                        ❌ Ошибка: ${response.error || 'Данные о громкости не найдены'}
                    </div>
                `).show();
            }

        } catch (error) {
            console.error('Ошибка получения данных громкости:', error);
            $('#currentVolumeLevel').text('Ошибка загрузки');
            $('#volumeResult').html(`
                <div class="error-message">
                    ❌ Ошибка получения данных: ${error.responseJSON?.error || error.statusText || 'Неизвестная ошибка'}
                </div>
            `).show();
        }
    }

    // Установка уровня громкости
    async setVoiceVolume() {
        const stationId = this.currentStationId;
        const volumeLevel = parseInt($('#volumeSlider').val());

        if (!stationId) {
            this.showNotification('Не выбрана станция', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            
            const response = await $.ajax({
                url: `${this.API_BASE}/api/set-voice-volume`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    station_id: stationId,
                    volume_level: volumeLevel
                })
            });

            if (response.success) {
                $('#volumeResult').html(`
                    <div class="success-message">
                        ✅ Громкость успешно установлена: ${volumeLevel} (${volumeLevel * 10}%)
                    </div>
                `).show();
                
                // Обновляем отображение текущего уровня
                $('#currentVolumeLevel').text(`${volumeLevel} (${volumeLevel * 10}%)`);
                
                this.showNotification(`Громкость установлена: ${volumeLevel}`, 'success');
            } else {
                $('#volumeResult').html(`
                    <div class="error-message">
                        ❌ Ошибка: ${response.message || 'Не удалось установить громкость'}
                    </div>
                `).show();
            }

        } catch (error) {
            console.error('Ошибка установки громкости:', error);
            $('#volumeResult').html(`
                <div class="error-message">
                    ❌ Ошибка установки громкости: ${error.responseJSON?.error || error.statusText || 'Неизвестная ошибка'}
                </div>
            `).show();
        }
    }

    // Обновление отображения уровня громкости
    updateVolumeDisplay(value) {
        const volume = parseInt(value);
        const percentage = volume * 10;
        $('#volumeValue').text(volume);
        $('#volumePercentage').text(`${percentage}%`);
    }

    // Обновление инвентаря станции
    async refreshStationInventory() {
        const stationId = this.currentStationId;
        if (!stationId) {
            this.showNotification('Не выбрана станция для обновления инвентаря', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            this.showNotification('Обновляем инвентарь станции...', 'info');
            
            const response = await $.ajax({
                url: `${this.API_BASE}/api/query-inventory`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    station_id: stationId
                })
            });

            if (response.success) {
                this.showNotification('Запрос на обновление инвентаря отправлен', 'success');
                // Перезагружаем данные станции
                await this.loadStationPowerbanks(stationId);
            } else {
                this.showNotification(response.message || 'Ошибка обновления инвентаря', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка обновления инвентаря:', error);
            this.showNotification('Ошибка обновления инвентаря', 'error');
        }
    }

    // Перезагрузка станции
    async restartStation() {
        const stationId = this.currentStationId;
        if (!stationId) {
            this.showNotification('Не выбрана станция для перезагрузки', 'error');
            return;
        }

        if (!confirm('Вы уверены, что хотите перезагрузить станцию?')) {
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            this.showNotification('Перезагружаем станцию...', 'info');
            
            const response = await $.ajax({
                url: `${this.API_BASE}/api/admin/restart-station`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    station_id: stationId
                })
            });

            if (response.success) {
                this.showNotification('Запрос на перезагрузку станции отправлен', 'success');
            } else {
                this.showNotification(response.message || 'Ошибка перезагрузки станции', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка перезагрузки станции:', error);
            this.showNotification('Ошибка перезагрузки станции', 'error');
        }
    }

    // Принудительное извлечение повербанка
    async forceEjectPowerbank(powerbankId) {
        if (confirm(`Принудительно извлечь повербанк ID ${powerbankId} из станции?`)) {
            try {
                const token = localStorage.getItem('authToken');
                
                // Получаем ID текущего пользователя (админа)
                const user = JSON.parse(localStorage.getItem('currentUser') || '{}');
                const userId = user.id || user.user_id || user.userId;
                
                if (!userId) {
                    this.showNotification('Ошибка: пользователь не найден', 'error');
                    return;
                }
                
                // Находим станцию и слот, где находится повербанк
                const stationPowerbankData = await this.findPowerbankInStation(powerbankId);
                
                if (!stationPowerbankData) {
                    this.showNotification('Повербанк не найден в станции', 'error');
                    return;
                }
                
                console.log('🔍 AdminFullManager: Данные повербанка в станции:', stationPowerbankData);
                
                // Отправляем запрос на принудительное извлечение
                const response = await $.ajax({
                    url: `${this.API_BASE}/api/admin/force-eject-powerbank`,
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    data: JSON.stringify({
                        station_id: stationPowerbankData.station_id,
                        slot_number: stationPowerbankData.slot_number,
                        admin_user_id: userId
                    })
                });
                
                console.log('📡 AdminFullManager: Ответ от API принудительного извлечения:', response);
                
                if (response.success) {
                    this.showNotification('Повербанк успешно извлечен из станции', 'success');
                    
                    // Показываем пакет если есть
                    if (response.packet_hex) {
                        console.log('📦 Пакет принудительного извлечения:', response.packet_hex);
                        this.showPacketModal('Принудительное извлечение', response.packet_hex, response);
                    }
                    
                    // Перезагружаем данные повербанков
                    await this.loadPowerbanks();
                } else {
                    this.showNotification(response.message || 'Ошибка извлечения повербанка', 'error');
                }
                
            } catch (error) {
                console.error('Ошибка принудительного извлечения повербанка:', error);
                this.showNotification('Ошибка принудительного извлечения повербанка', 'error');
            }
        }
    }

    // Поиск повербанка в станции
    async findPowerbankInStation(powerbankId) {
        try {
            const token = localStorage.getItem('authToken');
            
            // Загружаем данные station_powerbank для этого повербанка
            const response = await $.ajax({
                url: `${this.API_BASE}/api/station-powerbanks?powerbank_id=${powerbankId}`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            if (response.success && response.data && response.data.length > 0) {
                const stationPowerbank = response.data[0];
                return {
                    station_id: stationPowerbank.station_id,
                    slot_number: stationPowerbank.slot_number,
                    powerbank_id: stationPowerbank.powerbank_id
                };
            }
            
            return null;
            
        } catch (error) {
            console.error('Ошибка поиска повербанка в станции:', error);
            return null;
        }
    }

    // Удаление аккумулятора
    async deletePowerbank(powerbankId) {
        if (confirm('Вы уверены, что хотите удалить этот аккумулятор?')) {
            try {
                const token = localStorage.getItem('authToken');
                
                // Отправляем запрос на удаление аккумулятора
                const response = await $.ajax({
                    url: `${this.API_BASE}/api/powerbanks/${powerbankId}`,
                    method: 'DELETE',
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                });
                
                if (response.success) {
                    this.showNotification('Аккумулятор успешно удален', 'success');
                    
                    // Перезагружаем данные аккумуляторов
                    await this.loadPowerbanks();
                } else {
                    this.showNotification(response.message || 'Ошибка удаления аккумулятора', 'error');
                }
                
            } catch (error) {
                console.error('Ошибка удаления аккумулятора:', error);
                this.showNotification('Ошибка удаления аккумулятора', 'error');
            }
        }
    }


    // Поиск логов
    searchLogs() {
        alert('Функция поиска логов будет реализована');
    }

    // Показать ошибку
    showError(message) {
        $('#errorMessage').text(message).show();
        $('#successMessage').hide();
    }

    // Показать успех
    showSuccess(message) {
        $('#successMessage').text(message).show();
        $('#errorMessage').hide();
    }

    // Вспомогательная функция для показа модального окна
    showModal(modalId) {
        const modalElement = document.getElementById(modalId);
        if (modalElement) {
            modalElement.classList.add('show');
        }
    }

    // Вспомогательная функция для скрытия модального окна
    hideModal(modalId) {
        const modalElement = document.getElementById(modalId);
        if (modalElement) {
            modalElement.classList.remove('show');
        }
    }

    // Выход из системы
    logout() {
        localStorage.removeItem('authToken');
        localStorage.removeItem('currentUser');
        window.location.href = 'auth.html';
    }

    // Универсальное модальное окно для отображения пакетов
    showPacketModal(title, packetHex, response) {
        const modalId = 'packetModal';
        
        // Удаляем существующее модальное окно если есть
        $(`#${modalId}`).remove();
        
        const modalHtml = `
            <div id="${modalId}" class="modal fade" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">📦 ${title}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="packet-info">
                                <h6>📋 Информация о пакете:</h6>
                                <ul class="list-unstyled">
                                    <li><strong>Команда:</strong> ${title}</li>
                                    <li><strong>Размер:</strong> ${packetHex.length / 2} байт</li>
                                    <li><strong>Статус:</strong> ${response.success ? '✅ Успешно' : '❌ Ошибка'}</li>
                                    ${response.message ? `<li><strong>Сообщение:</strong> ${response.message}</li>` : ''}
                                </ul>
                                
                                <h6>🔧 Пакет (HEX):</h6>
                                <div class="packet-display">
                                    <textarea class="form-control" rows="4" readonly style="font-family: monospace; font-size: 12px; background: #f8f9fa;">${packetHex}</textarea>
                                </div>
                                
                                <h6>📊 Детали пакета:</h6>
                                <div class="packet-details">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <strong>PacketLen:</strong> ${packetHex.substring(0, 4)} (${parseInt(packetHex.substring(0, 4), 16)} байт)
                                        </div>
                                        <div class="col-md-6">
                                            <strong>Command:</strong> ${packetHex.substring(4, 6)} (0x${packetHex.substring(4, 6).toUpperCase()})
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <strong>VSN:</strong> ${packetHex.substring(6, 8)}
                                        </div>
                                        <div class="col-md-6">
                                            <strong>CheckSum:</strong> ${packetHex.substring(8, 10)}
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <strong>Token:</strong> ${packetHex.substring(10, 18)}
                                        </div>
                                    </div>
                                    ${packetHex.length > 18 ? `
                                    <div class="row">
                                        <div class="col-md-12">
                                            <strong>Payload:</strong> ${packetHex.substring(18)}
                                        </div>
                                    </div>
                                    ` : ''}
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                            <button type="button" class="btn btn-primary" onclick="navigator.clipboard.writeText('${packetHex}'); this.textContent='Скопировано!'; setTimeout(() => this.textContent='Копировать', 2000);">Копировать HEX</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(modalHtml);
        
        // Используем Bootstrap 5 API
        const modalElement = document.getElementById(modalId);
        const modal = new bootstrap.Modal(modalElement);
        modal.show();
    }

    // Запрос инвентаря станции
    async queryStationInventory(stationId) {
        if (!stationId) {
            this.showNotification('Не выбрана станция для запроса инвентаря', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('authToken');
            if (!token) {
                this.showNotification('Сессия истекла. Авторизуйтесь повторно.', 'error');
                this.logout();
                return;
            }
            this.showNotification('Запрашиваем инвентарь станции...', 'info');
            
            // Отправляем запрос инвентаря
            const response = await $.ajax({
                url: `${this.API_BASE}/api/query-inventory`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    station_id: stationId
                })
            });
            
            if (response.success) {
                this.showNotification(`✅ ${response.message}`, 'success');
                console.log('📦 Запрос инвентаря отправлен:', response);
                
                // Показываем дополнительную информацию
                if (response.packet_hex) {
                    console.log('📦 Пакет команды:', response.packet_hex);
                    this.showPacketModal('Запрос инвентаря', response.packet_hex, response);
                }
                
                // Обновляем данные станции через короткое время
                setTimeout(() => {
                    this.loadStationInventory(stationId);
                }, 2000);
            } else {
                this.showNotification('Ошибка запроса инвентаря', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка запроса инвентаря:', error);
            let errorMessage = 'Ошибка запроса инвентаря';
            
            if (error.responseJSON && error.responseJSON.error) {
                errorMessage = error.responseJSON.error;
            } else if (error.status === 401) {
                errorMessage = 'Недостаточно прав для запроса инвентаря';
            } else if (error.status === 404) {
                errorMessage = 'Станция не найдена или не подключена';
            }
            
            this.showNotification(errorMessage, 'error');
        }
    }

    // Открытие модального окна станции при клике
    async onStationClick(stationId) {
        console.log(`🖱️ Клик по станции ${stationId}`);
        
        // Открываем модальное окно с повербанками станции
        await this.viewStation(stationId);
    }

    // Загрузка инвентаря станции
    async loadStationInventory(stationId) {
        try {
            const token = localStorage.getItem('authToken');
            if (!token) {
                this.showNotification('Сессия истекла. Авторизуйтесь повторно.', 'error');
                this.logout();
                return;
            }
            
            const response = await $.ajax({
                url: `${this.API_BASE}/api/query-inventory/station/${stationId}`,
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });
            
            if (response.success) {
                this.displayStationInventory(response.station, response.inventory);
            } else {
                this.showNotification('Ошибка загрузки инвентаря', 'error');
            }
            
        } catch (error) {
            console.error('Ошибка загрузки инвентаря:', error);
            this.showNotification('Ошибка загрузки инвентаря', 'error');
        }
    }

    // Отображение инвентаря станции
    displayStationInventory(station, inventory) {
        const inventoryHtml = `
            <div class="inventory-details">
                <h4>📊 Инвентарь станции ${station.box_id}</h4>
                <div class="station-info">
                    <p><strong>ID станции:</strong> ${station.station_id}</p>
                    <p><strong>Свободно слотов:</strong> ${station.remain_num}</p>
                    <p><strong>Всего слотов:</strong> ${station.slots_declared}</p>
                    <p><strong>Статус:</strong> <span class="status-${station.status}">${station.status}</span></p>
                    <p><strong>Последний контакт:</strong> ${station.last_seen ? new Date(station.last_seen).toLocaleString() : 'Неизвестно'}</p>
                </div>
                
                <h5>🔋 Повербанки в станции (${inventory.length})</h5>
                <div class="inventory-table">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Слот</th>
                                <th>Серийный номер</th>
                                <th>Уровень заряда</th>
                                <th>Напряжение</th>
                                <th>Температура</th>
                                <th>SOH</th>
                                <th>Статус</th>
                                <th>Обновлено</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${inventory.map(item => `
                                <tr>
                                    <td>${item.slot_number}</td>
                                    <td>${item.serial_number}</td>
                                    <td>${item.level !== null ? item.level + '%' : 'N/A'}</td>
                                    <td>${item.voltage !== null ? item.voltage + 'mV' : 'N/A'}</td>
                                    <td>${item.temperature !== null ? item.temperature + '°C' : 'N/A'}</td>
                                    <td>${item.soh !== null ? item.soh + '%' : 'N/A'}</td>
                                    <td><span class="status-${item.powerbank_status}">${item.powerbank_status}</span></td>
                                    <td>${item.last_update ? new Date(item.last_update).toLocaleString() : 'N/A'}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
        
        this.showModal('Инвентарь станции', inventoryHtml);
    }

}

    // Инициализация при загрузке страницы
    $(document).ready(function() {
        // Проверяем авторизацию
        const token = localStorage.getItem('authToken');
        if (!token) {
            window.location.href = 'auth.html';
            return;
        }

        // Инициализируем админ панель
        window.adminManager = new AdminFullManager();
        window.adminManager.init();
        
        
        // Сразу загружаем панель управления
        window.adminManager.loadDashboard();
    });
