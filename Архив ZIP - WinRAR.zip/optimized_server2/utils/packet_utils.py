"""
Утилиты для работы с пакетами
"""
import struct
import hashlib
import random
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, Tuple, Optional
from config.settings import MAX_PACKET_SIZE


from utils.time_utils import get_moscow_time, get_moscow_now

def log_packet(data: bytes, direction: str, station_box_id: str = "unknown", command_name: str = "Unknown"):
    """Логирование TCP пакета через логгер с точным временем"""
    try:
        from utils.tcp_packet_logger import log_tcp_packet
        import time
        
        hex_data = data.hex().upper()
        size = len(data)
        
        # Определяем команду
        command_hex = "Unknown"
        if size >= 3:
            command_hex = f"0x{data[2]:02X}"
        
        # Добавляем микросекундную точность времени
        timestamp = time.time()
        microseconds = int((timestamp - int(timestamp)) * 1000000)
        time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(timestamp))
        precise_time = f"{time_str}.{microseconds:06d}"
        
        # Логируем через TCP логгер с точным временем
        log_tcp_packet(
            direction=direction,
            packet_type=command_name,
            station_id=station_box_id,
            packet_size=size,
            command=command_hex,
            packet_data=hex_data,
            additional_info=f"TIME:{precise_time}"
        )
            
    except Exception as e:
        print(f"Ошибка логирования пакета: {e}")

def log_packet_with_station(data: bytes, direction: str, station_box_id: str, command_name: str):
    """Логирование пакета с информацией о станции"""
    log_packet(data, direction, station_box_id, command_name)


def compute_checksum(payload_bytes: bytes) -> int:
    """Вычисляет контрольную сумму"""
    checksum = 0
    for b in payload_bytes:
        checksum ^= b
    return checksum

def generate_session_token(payload: bytes, secret_key: str) -> int:
    """Генерирует session token из payload и secret_key (строка из БД)"""
    # Преобразуем secret_key в bytes
    secret_key_bytes = secret_key.encode('utf-8')
    

    md5 = hashlib.md5(payload + secret_key_bytes).digest()
    session_token = md5[3] + md5[7]*256 + md5[11]*65536 + md5[15]*16777216
    
    return session_token


def parse_terminal_id(bytes8: bytes) -> str:
    """Парсит terminal ID из 8 байт"""
    try:
        # Пытаемся декодировать первые 4 байта как ASCII
        ascii_part = bytes8[:4].decode('ascii')
        hex_part = ''.join(f"{b:02X}" for b in bytes8[4:])
        return ascii_part + hex_part
    except UnicodeDecodeError:
        # Если не удается декодировать как ASCII, используем только hex
        return ''.join(f"{b:02X}" for b in bytes8)


def parse_login_packet(data: bytes) -> Dict[str, Any]:
    """Парсит пакет логина станции"""
    try:
        packet_format = ">H B B B I I H H"
        header_size = struct.calcsize(packet_format)
        packet_len, command, vsn, checksum, token, nonce, magic, boxid_len = struct.unpack(
            packet_format, data[:header_size]
        )

        if magic != 0xA0A0:
            raise ValueError(f"Magic неверный: {hex(magic)}")

        # Payload начинается с header_size - 8 
        payload = data[header_size - 8:]
        
      

        boxid_start = header_size
        boxid_end = boxid_start + boxid_len
        if boxid_end > len(data):
            raise ValueError("BoxID выходит за границы пакета")
        boxid = data[boxid_start:boxid_end].rstrip(b'\x00').decode('ascii')

        timestamp, slots_num, remain_num = struct.unpack(">I B B", data[boxid_end:boxid_end + 6])
        timestamp_str = datetime.fromtimestamp(timestamp, timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

        slot_data_start = boxid_end + 6
        slot_format = ">B 8s B H H b B B"
        slot_size = struct.calcsize(slot_format)
        slots = []
        offset = slot_data_start
        
        while offset + slot_size <= len(data):
            slot_bytes = data[offset:offset + slot_size]
            slot_number, terminal_id_bytes, level, voltage, current, temp, status, soh = struct.unpack(
                slot_format, slot_bytes
            )
            terminal_id = parse_terminal_id(terminal_id_bytes)
            status_bits = {
                "InsertionSwitch": (status >> 7) & 1,
                "LockStatus": (status >> 6) & 1,
                "PowerBankError": (status >> 5) & 1,
                "ChargingSwitch": (status >> 4) & 1,
                "ChargingStatus": (status >> 3) & 1,
                "TypeCError": (status >> 2) & 1,
                "LightningError": (status >> 1) & 1,
                "MicroUSBError": status & 1
            }
            slots.append({
                "Slot": slot_number,
                "TerminalID": terminal_id,
                "Level": level,
                "Voltage": voltage,
                "Current": current,
                "Temp": temp,
                "Status": status_bits,
                "SOH": soh
            })
            offset += slot_size

        parsed = {
            "Type": "Login",
            "CheckSumValid": True,
            "Token": f"0x{token:08X}",
            "Nonce": nonce,
            "Magic": hex(magic),
            "BoxID": boxid,
            "Timestamp": timestamp_str,
            "SlotsNumDeclared": slots_num,
            "RemainNum": remain_num,
            "SlotsParsed": len(slots),
            "Slots": slots,
            "PacketLen": packet_len,
            "Command": hex(command),
            "VSN": vsn,
            "CheckSum": hex(checksum),
            "RawPacket": data.hex()
        }
        return parsed
    except Exception as e:
        return {
            "Type": "Login",
            "Error": f"Ошибка парсинга: {str(e)}",
            "RawPacket": data.hex(),
            "Size": len(data)
        }


def build_login_response(vsn: int, nonce: int, secret_key: str) -> Tuple[bytes, int]:
    """Создает ответ на логин"""
    command = 0x60
    result = 1
    timestamp = int(get_moscow_time().timestamp())
    new_nonce = random.randint(0, 0xffffffff)
    payload = struct.pack(">BII", result, new_nonce, timestamp)
    checksum = compute_checksum(payload)
    session_token = generate_session_token(payload, secret_key)
    packet_len = 7 + len(payload)
    header = struct.pack(">HBBBI", packet_len, command, vsn, checksum, session_token)
    return header + payload, session_token


def build_heartbeat_response(secret_key: str, vsn: int = 1, station_id: str = "unknown") -> bytes:
    """Создает ответ на heartbeat"""
    try:
        command = 0x61
        packet_len = 7
        checksum = 0
        payload = b''  
        token = generate_session_token(payload, secret_key)
        
        packet = struct.pack(">HBBBI", packet_len, command, vsn, checksum, token)
        
        # Логируем пакет
        log_packet(packet, "OUTGOING", station_id, "HeartbeatResponse")
        
        return packet
    except Exception as e:
        print(f"Ошибка создания heartbeat response: {e}")
        return b''
def build_borrow_power_bank(secret_key: str, slot: int = 1, vsn: int = 1):
    command = 0x65
    packet_len = 8
    payload = struct.pack(">B", slot)
    checksum = compute_checksum(payload)
    token = generate_session_token(payload, secret_key)
    header = struct.pack(">HBBBI", packet_len, command, vsn, checksum, token)
    packet = header + payload
    
    
    
    return packet

def build_return_power_bank(secret_key: str, slot: int = 1, vsn: int = 1):
    """Создает команду на возврат повербанка (команда 0x66)"""
    command = 0x66
    packet_len = 8
    payload = struct.pack(">B", slot)
    checksum = compute_checksum(payload)
    token = generate_session_token(payload, secret_key)
    header = struct.pack(">HBBBI", packet_len, command, vsn, checksum, token)
    packet = header + payload
    
    
    
    return packet

def build_return_power_bank_response(slot: int, result: int, terminal_id: bytes, level: int, voltage: int, current: int, temperature: int, status: int, soh: int, vsn: int, token: int):
    """
    Строит ответ сервера на возврат повербанка (0x66)
    
    """
    command = 0x66
    
    payload = struct.pack(">BB8sBHHbBB", slot, result, terminal_id, level, voltage, current, temperature, status, soh)
    
    # Checksum - XOR payload
    checksum = compute_checksum(payload)
   
    packet_len = len(payload) + 7  
    header = struct.pack(">HBBBI", packet_len, command, vsn, checksum, token)
    
    packet = header + payload
    
    return packet


def parse_borrow_request(data: bytes) -> Dict[str, Any]:
    """Парсит запрос на выдачу повербанка (команда 0x65)"""
    packet_format = ">H B B B I"
    packet_len, command, vsn, checksum, token = struct.unpack(packet_format, data[:9])
    
    
    payload_len = max(0, packet_len - 7)
    payload = data[9:9 + payload_len]
    
    # Слот — первый байт payload
    slot = payload[0] if len(payload) >= 1 else 0
    
    # Проверяем checksum по фактическому payload
    if compute_checksum(payload) != checksum:
        raise ValueError("Неверный checksum")
    
    return {
        "Type": "BorrowRequest",
        "PacketLen": packet_len,
        "Command": hex(command),
        "VSN": vsn,
        "CheckSum": hex(checksum),
        "Token": f"0x{token:08X}",
        "Slot": slot,
        "CheckSumValid": True
    }


def parse_borrow_response(data: bytes) -> Dict[str, Any]:
    """Парсит ответ на выдачу повербанка (команда 0x65)"""
    try:
       
        packet_format = ">H B B B I"
        packet_len, command, vsn, checksum, token = struct.unpack(packet_format, data[:9])

        
        payload_len = max(0, packet_len - 7)
        payload = data[9:9 + payload_len]

        
        # Некоторые ревизии присылают 12 байт (доп. 2 байта статусов)
        slot = payload[0] if len(payload) >= 1 else 0
        result_code = payload[1] if len(payload) >= 2 else 0
        terminal_id_bytes = payload[2:10] if len(payload) >= 10 else b"\x00" * 8
        terminal_id = parse_terminal_id(terminal_id_bytes)
        current_slot_lock_status = payload[10] if len(payload) >= 12 else 0
        adjacent_slot_lock_status = payload[11] if len(payload) >= 12 else 0

        if compute_checksum(payload) != checksum:
            checksum_valid = False
            checksum_error = "Неверный checksum"
        else:
            checksum_valid = True
            checksum_error = None

        result = {
            "Type": "BorrowResponse",
            "PacketLen": packet_len,
            "Command": hex(command),
            "VSN": vsn,
            "CheckSum": hex(checksum),
            "CheckSumValid": checksum_valid,
            "Token": f"0x{token:08X}",
            "Slot": slot,
            "ResultCode": result_code,
            "TerminalID": terminal_id,
            "CurrentSlotLockStatus": current_slot_lock_status,
            "AdjacentSlotLockStatus": adjacent_slot_lock_status,
            "Success": result_code == 1,
            "ReceivedAt": get_moscow_time().isoformat(),
            "RawPacket": data.hex()
        }
        if not checksum_valid:
            result["CheckSumError"] = checksum_error

        return result

    except Exception as e:
        return {
            "Type": "BorrowResponse",
            "Error": str(e),
            "RawPacket": data.hex(),
            "Size": len(data)
        }



def parse_return_response(data: bytes) -> Dict[str, Any]:
    """Парсит ответ на возврат повербанка (команда 0x66)"""
    try:
       

        packet_format = ">H B B B I"
        packet_len, command, vsn, checksum, token = struct.unpack(packet_format, data[:9])

      

        payload = data[9:]
       

        # Разбор payload
        slot = payload[0]
        result_code = payload[1]
        terminal_id_bytes = payload[2:10]
        terminal_id = parse_terminal_id(terminal_id_bytes)
        current_slot_lock_status = payload[10]
        adjacent_slot_lock_status = payload[11]

        # Проверка checksum
        if compute_checksum(payload) != checksum:
            checksum_valid = False
            checksum_error = "Неверный checksum"
        else:
            checksum_valid = True
            checksum_error = None

        result = {
            "Type": "ReturnResponse",
            "PacketLen": packet_len,
            "Command": hex(command),
            "VSN": vsn,
            "CheckSum": hex(checksum),
            "CheckSumValid": checksum_valid,
            "Token": f"0x{token:08X}",
            "Slot": slot,
            "ResultCode": result_code,
            "TerminalID": terminal_id,
            "CurrentSlotLockStatus": current_slot_lock_status,
            "AdjacentSlotLockStatus": adjacent_slot_lock_status,
            "Success": result_code == 1,
            "ReceivedAt": get_moscow_time().isoformat(),
            "RawPacket": data.hex()
        }
        if not checksum_valid:
            result["CheckSumError"] = checksum_error

        return result

    except Exception as e:
        return {
            "Type": "ReturnResponse",
            "Error": str(e),
            "RawPacket": data.hex(),
            "Size": len(data)
        }


def parse_return_power_bank_request(data: bytes) -> Dict[str, Any]:
    """
    Парсит запрос на возврат повербанка (команда 0x66)
    """
    try:
        # Header
        packet_format = ">HBBBI"
        packet_len, command, vsn, checksum, token = struct.unpack(packet_format, data[:9])
        
        # Payload - данные о повербанке
        payload = data[9:]
        
        
        
        # Парсим payload
        slot = payload[0]
        terminal_id_bytes = payload[1:9]
        terminal_id = parse_terminal_id(terminal_id_bytes)
        level = payload[9]
        voltage = struct.unpack(">H", payload[10:12])[0]
        current = struct.unpack(">H", payload[12:14])[0]
        temperature = struct.unpack("b", payload[14:15])[0]  # signed byte
        status = payload[15]
        soh = payload[16]
        
        # Проверяем checksum
        checksum_valid = compute_checksum(payload) == checksum
        
        return {
            "Type": "ReturnRequest",
            "PacketLen": packet_len,
            "Command": f"0x{command:02X}",
            "VSN": vsn,
            "CheckSum": f"0x{checksum:02X}",
            "CheckSumValid": checksum_valid,
            "Token": f"0x{token:08X}",
            "Slot": slot,
            "TerminalID": terminal_id,
            "Level": level,
            "Voltage": voltage,
            "Current": current,
            "Temperature": temperature,
            "Status": status,
            "SOH": soh,
            "ReceivedAt": get_moscow_time().isoformat(),
            "RawPacket": data.hex().upper()
        }
        
    except Exception as e:
        return {"error": f"Ошибка парсинга запроса на возврат: {str(e)}", "raw": data.hex().upper()}



def build_force_eject_request(secret_key: str, slot: int, vsn: int = 1):
    command = 0x80
    packet_len = 8
    payload = struct.pack(">B", slot)
    checksum = compute_checksum(payload)
    token = generate_session_token(payload, secret_key)
    header = struct.pack(">HBBBI", packet_len, command, vsn, checksum, token)
    packet = header + payload
    
    
    return packet






def build_query_iccid_request(secret_key: str, vsn: int = 1) -> bytes:
    """Создает запрос на получение ICCID SIM карты (команда 0x69)"""
    command = 0x69
    packet_len = 7  
    payload = b''  
    checksum = compute_checksum(payload)
    token = generate_session_token(payload, secret_key)
    header = struct.pack(">HBBBI", packet_len, command, vsn, checksum, token)
    packet = header + payload
    
    
    
    return packet


def parse_query_iccid_response(data: bytes) -> Dict[str, Any]:
    """Парсит ответ на запрос ICCID SIM карты (команда 0x69)"""
    try:
        packet_format = ">H B B B I H"
        packet_len, command, vsn, checksum, token, iccid_len = struct.unpack(packet_format, data[:11])
        
        
        
        # Извлекаем ICCID
        iccid_bytes = data[11:11 + iccid_len]
        iccid = iccid_bytes.rstrip(b'\x00').decode('ascii', errors='ignore')
        
        # Проверяем checksum (payload = ICCIDLen + ICCID)
        payload = struct.pack(">H", iccid_len) + iccid_bytes
        if compute_checksum(payload) != checksum:
            raise ValueError("Неверный checksum")
        
        return {
            "Type": "QueryICCIDResponse",
            "PacketLen": packet_len,
            "Command": hex(command),
            "VSN": vsn,
            "CheckSum": hex(checksum),
            "Token": f"0x{token:08X}",
            "ICCIDLen": iccid_len,
            "ICCID": iccid,
            "CheckSumValid": True,
            "ReceivedAt": get_moscow_time().isoformat()
        }
        
    except Exception as e:
        return {
            "Type": "QueryICCIDResponse",
            "Error": f"Ошибка парсинга: {str(e)}",
            "RawPacket": data.hex(),
            "Size": len(data)
        }






def parse_slot_abnormal_report_request(data: bytes) -> Dict[str, Any]:
    """Парсит запрос отчета об аномалии слота (команда 0x83)"""

    packet_format = ">H B B B I"
    packet_len, command, vsn, checksum, token = struct.unpack(packet_format, data[:9])

    
    payload_len = max(0, packet_len - 7)
    payload = data[9:9 + payload_len]

    # Минимальная длина payload: 1 (Event) + 1 (SlotNo) + 8 (TerminalID) = 10
    if len(payload) < 10:
        return {
            "Type": "SlotAbnormalReportRequest",
            "Error": f"Payload too short: {len(payload)}",
            "PacketLen": packet_len,
            "Command": hex(command),
            "VSN": vsn,
            "RawPacket": data.hex()
        }

    event = payload[0]
    slot_no = payload[1]
    terminal_id_bytes = payload[2:10]

    # Проверка checksum по фактическому payload
    if compute_checksum(payload) != checksum:
        raise ValueError("Неверный checksum")

    # Определяем тип события
    event_types = {
        1: "No unlock command",
        2: "Return detected but no power bank"
    }

    event_text = event_types.get(event, f"Unknown event type {event}")

    return {
        "Type": "SlotAbnormalReportRequest",
        "PacketLen": packet_len,
        "Command": hex(command),
        "VSN": vsn,
        "CheckSum": hex(checksum),
        "Token": f"0x{token:08X}",
        "Event": event,
        "EventText": event_text,
        "SlotNo": slot_no,
        "TerminalID": terminal_id_bytes.hex().upper(),
        "CheckSumValid": True,
        "ReceivedAt": get_moscow_time().isoformat()
    }


def build_slot_abnormal_report_response(secret_key: str, vsn: int = 1) -> bytes:
    """Создает ответ на отчет об аномалии слота (команда 0x83)"""
    command = 0x83
    packet_len = 7 
    payload = b''  
    checksum = compute_checksum(payload)
    token = generate_session_token(payload, secret_key)
    header = struct.pack(">HBBBI", packet_len, command, vsn, checksum, token)
    return header + payload


def parse_packet(data: bytes) -> Dict[str, Any]:
    """Универсальный парсер пакетов"""
    
    command = data[2]
    
    # Логируем входящий пакет
    command_names = {
        0x60: "Login", 0x61: "Heartbeat", 0x63: "SetServerAddress",
        0x64: "QueryInventory", 0x65: "BorrowPowerBank", 0x66: "ReturnPowerBank",
        0x67: "RestartCabinet", 0x69: "QueryICCID", 0x6A: "QueryServerAddress",
        0x70: "SetVoiceVolume", 0x77: "QueryVoiceVolume", 0x80: "ForceEject",
        0x83: "SlotAbnormalReport"
    }
    command_name = command_names.get(command, f"Unknown(0x{command:02X})")
    
    
    try:
        if command == 0x60:  # Login
            return parse_login_packet(data)
        elif command == 0x61:  # Heartbeat
            return parse_heartbeat_packet(data)
        elif command == 0x65:  # Borrow Power Bank
            if len(data) >= 12:
                return parse_borrow_response(data)
            else:
                return parse_borrow_request(data)
        elif command == 0x66:  # Return Power Bank
            if len(data) >= 21:
                return parse_return_response(data)
            else:
                return parse_return_power_bank_request(data)
        elif command == 0x69:  # Query ICCID
            return parse_query_iccid_response(data)
        elif command == 0x80:  # Force Eject
            return parse_force_eject_response(data)
        elif command == 0x83:  # Slot Abnormal Report
            return parse_slot_abnormal_report_request(data)
        elif command == 0x67:  # Restart Cabinet
            return parse_restart_cabinet_response(data)
        elif command == 0x64:  # Query Inventory
            return parse_query_inventory_response(data)
        elif command == 0x77:  # Query Voice Volume
            return parse_query_voice_volume_response(data)
        elif command == 0x70:  # Set Voice Volume
            return parse_set_voice_volume_response(data)
        elif command == 0x63:  # Set Server Address
            return parse_set_server_address_response(data)
        elif command == 0x6A:  # Query Server Address
            return parse_query_server_address_response(data)
        else:
            return {
                "Type": "Unknown",
                "Command": f"0x{command:02X}",
                "Size": len(data),
                "RawPacket": data.hex()
            }
    except Exception as e:
        return {
            "Type": "ParseError",
            "Command": f"0x{command:02X}",
            "Error": str(e),
            "Size": len(data),
            "RawPacket": data.hex()
        }


def parse_heartbeat_packet(data: bytes) -> Dict[str, Any]:
    """Парсит пакет heartbeat"""
    try:
        packet_format = ">H B B B I"
        packet_len, command, vsn, checksum, token = struct.unpack(packet_format, data[:9])  
        
        
        return {
            "Type": "Heartbeat",
            "PacketLen": packet_len,
            "Command": hex(command),
            "VSN": vsn,
            "CheckSum": hex(checksum),
            "Token": f"0x{token:08X}",
            "CheckSumValid": True,
            "ReceivedAt": get_moscow_time().isoformat()
        }
    except Exception as e:
        return {
            "Type": "Heartbeat",
            "Error": f"Ошибка парсинга: {str(e)}",
            "RawPacket": data.hex(),
            "Size": len(data)
        }


def parse_force_eject_response(data: bytes) -> Dict[str, Any]:
    """Парсит ответ на принудительное извлечение (команда 0x80)"""
    try:
        
        packet_format = ">H B B B I"
        packet_len, command, vsn, checksum, token = struct.unpack(packet_format, data[:9])#2+1+1+1+4=9
        
        
        
        result = {
            "Type": "ForceEjectResponse",
            "PacketLen": packet_len,
            "Command": hex(command),
            "VSN": vsn,
            "CheckSum": hex(checksum),
            "Token": f"0x{token:08X}",
            "CheckSumValid": True,
            "Success": True,
            "ReceivedAt": get_moscow_time().isoformat()
        }
        
        
        if len(data) > 9:
            try:
                
                slot = data[9]
                result_code = data[10]
                terminal_id_bytes = data[11:19]
                terminal_id = parse_terminal_id(terminal_id_bytes)
                
                result.update({
                    "Slot": slot,
                    "TerminalID": terminal_id
                })
                
                
                payload = struct.pack("BB8s", slot, result_code, terminal_id_bytes)
                if compute_checksum(payload) != checksum:
                    result["CheckSumValid"] = False
                   
            except Exception as parse_error:
                result["ParseWarning"] = f"Ошибка парсинга дополнительных данных: {parse_error}"
        else:
            # Проверяем checksum
            payload = b''
            if compute_checksum(payload) != checksum:
                result["CheckSumValid"] = False
                result["CheckSumError"] = "Неверный checksum"
        
        return result
        
    except Exception as e:
        return {
            "Type": "ForceEjectResponse",
            "Error": f"Ошибка парсинга: {str(e)}",
            "RawPacket": data.hex(),
            "Size": len(data)
        }


def build_restart_cabinet_request(secret_key: str, vsn: int = 1) -> bytes:
    """Создает запрос на перезагрузку кабинета (команда 0x67)"""
    command = 0x67
    packet_len = 7 
    payload = b''  
    checksum = compute_checksum(payload)
    token = generate_session_token(payload, secret_key)
    header = struct.pack(">HBBBI", packet_len, command, vsn, checksum, token)
    packet = header + payload
    
    
    
    return packet


def parse_restart_cabinet_response(data: bytes) -> Dict[str, Any]:
    """Парсит ответ на запрос перезагрузки кабинета (команда 0x67)"""
    try:
       
        packet_format = ">H B B B I"
        packet_len, command, vsn, checksum, token = struct.unpack(packet_format, data[:9])
        
        
        payload = b''
        if compute_checksum(payload) != checksum:
            raise ValueError("Неверный checksum")
        
        return {
            "Type": "RestartCabinetResponse",
            "PacketLen": packet_len,
            "Command": hex(command),
            "VSN": vsn,
            "CheckSum": hex(checksum),
            "Token": f"0x{token:08X}",
            "CheckSumValid": True,
            "Success": True,
            "ReceivedAt": get_moscow_time().isoformat(),
            "RawPacket": data.hex()
        }
        
    except Exception as e:
        return {
            "Type": "RestartCabinetResponse",
            "Error": f"Ошибка парсинга: {str(e)}",
            "RawPacket": data.hex(),
            "Size": len(data)
        }


def build_query_inventory_request(secret_key: str, vsn: int = 1, station_box_id: str = "unknown") -> bytes:
    """Создает запрос на получение инвентаря кабинета (команда 0x64)"""
    command = 0x64
    packet_len = 7 
    payload = b''  
    checksum = compute_checksum(payload)
    token = generate_session_token(payload, secret_key)
    header = struct.pack(">HBBBI", packet_len, command, vsn, checksum, token)
    packet = header + payload
    
    
    
    return packet


def parse_query_inventory_response(data: bytes) -> Dict[str, Any]:
    """Парсит ответ на запрос инвентаря кабинета (команда 0x64)"""
    try:
       
        packet_format = ">H B B B I"
        packet_len, command, vsn, checksum, token = struct.unpack(packet_format, data[:9])
        
       
        slots_num = data[9]
        remain_num = data[10]
        
       
        slots = []
        offset = 11
        
        
        slot_format = ">B 8s B H H b B B"
        slot_size = struct.calcsize(slot_format)
        
        while offset + slot_size <= len(data):
            slot_bytes = data[offset:offset + slot_size]
            slot_number, terminal_id_bytes, level, voltage, current, temperature, status, soh = struct.unpack(
                slot_format, slot_bytes
            )
            
            terminal_id = parse_terminal_id(terminal_id_bytes)
            
            
            status_bits = {
                "InsertionSwitch": (status >> 7) & 1,
                "LockStatus": (status >> 6) & 1,
                "PowerBankError": (status >> 5) & 1,
                "ChargingSwitch": (status >> 4) & 1,
                "ChargingStatus": (status >> 3) & 1,
                "TypeCError": (status >> 2) & 1,
                "LightningError": (status >> 1) & 1,
                "MicroUSBError": status & 1
            }
            
            slots.append({
                "Slot": slot_number,
                "TerminalID": terminal_id,
                "Level": level,
                "Voltage": voltage,
                "Current": current,
                "Temperature": temperature,
                "Status": status_bits,
                "SOH": soh
            })
            
            offset += slot_size
        
       
        payload = data[9:offset]  
        if compute_checksum(payload) != checksum:
            raise ValueError("Неверный checksum")
        
        return {
            "Type": "QueryInventoryResponse",
            "PacketLen": packet_len,
            "Command": hex(command),
            "VSN": vsn,
            "CheckSum": hex(checksum),
            "Token": f"0x{token:08X}",
            "SlotsNum": slots_num,
            "RemainNum": remain_num,
            "Slots": slots,
            "CheckSumValid": True,
            "ReceivedAt": get_moscow_time().isoformat(),
            "RawPacket": data.hex()
        }
        
    except Exception as e:
        return {
            "Type": "QueryInventoryResponse",
            "Error": f"Ошибка парсинга: {str(e)}",
            "RawPacket": data.hex(),
            "Size": len(data)
        }


def build_query_voice_volume_request(secret_key: str, vsn: int = 1) -> bytes:
    """Создает запрос на получение уровня громкости голосового вещания (команда 0x77)"""
    command = 0x77
    packet_len = 7 
    payload = b''  
    checksum = compute_checksum(payload)
    token = generate_session_token(payload, secret_key)
    header = struct.pack(">HBBBI", packet_len, command, vsn, checksum, token)
    packet = header + payload
    
    
    
    return packet


def parse_query_voice_volume_response(data: bytes) -> Dict[str, Any]:
    """Парсит ответ на запрос уровня громкости голосового вещания (команда 0x77)"""
    try:
        
        packet_format = ">H B B B I"
        packet_len, command, vsn, checksum, token = struct.unpack(packet_format, data[:9])
        
        # Парсим уровень громкости
        volume_level = data[9]
        
       
        payload = data[9:10]  
        if compute_checksum(payload) != checksum:
            raise ValueError("Неверный checksum")
        
        return {
            "Type": "QueryVoiceVolumeResponse",
            "PacketLen": packet_len,
            "Command": hex(command),
            "VSN": vsn,
            "CheckSum": hex(checksum),
            "Token": f"0x{token:08X}",
            "VolumeLevel": volume_level,
            "CheckSumValid": True,
            "ReceivedAt": get_moscow_time().isoformat(),
            "RawPacket": data.hex()
        }
        
    except Exception as e:
        return {
            "Type": "QueryVoiceVolumeResponse",
            "Error": f"Ошибка парсинга: {str(e)}",
            "RawPacket": data.hex(),
            "Size": len(data)
        }


def build_set_voice_volume_request(secret_key: str, volume_level: int, vsn: int = 1) -> bytes:
    """Создает запрос на установку уровня громкости голосового вещания (команда 0x70)"""
    command = 0x70
    packet_len = 8 
    payload = struct.pack(">B", volume_level)  
    checksum = compute_checksum(payload)
    token = generate_session_token(payload, secret_key)
    header = struct.pack(">HBBBI", packet_len, command, vsn, checksum, token)
    packet = header + payload
    
    
    
    return packet


def parse_set_voice_volume_response(data: bytes) -> Dict[str, Any]:
    """Парсит ответ на установку уровня громкости голосового вещания (команда 0x70)"""
    try:
       
        packet_format = ">H B B B I"
        packet_len, command, vsn, checksum, token = struct.unpack(packet_format, data[:9])
        
       
        payload = b''
        if compute_checksum(payload) != checksum:
            raise ValueError("Неверный checksum")
        
        return {
            "Type": "SetVoiceVolumeResponse",
            "PacketLen": packet_len,
            "Command": hex(command),
            "VSN": vsn,
            "CheckSum": hex(checksum),
            "Token": f"0x{token:08X}",
            "CheckSumValid": True,
            "Success": True,
            "ReceivedAt": get_moscow_time().isoformat(),
            "RawPacket": data.hex()
        }
        
    except Exception as e:
        return {
            "Type": "SetVoiceVolumeResponse",
            "Error": f"Ошибка парсинга: {str(e)}",
            "RawPacket": data.hex(),
            "Size": len(data)
        }


def build_set_server_address_request(secret_key: str, server_address: str, server_port: str, heartbeat_interval: int = 30, vsn: int = 1) -> bytes:
    """Создает запрос на установку адреса сервера (команда 0x63)"""
    command = 0x63
    
    
    address_bytes = server_address.encode('utf-8') + b'\x00'
    port_bytes = server_port.encode('utf-8') + b'\x00'  

    
    payload = struct.pack(">H", len(address_bytes))  # AddressLen 
    payload += address_bytes  
    payload += struct.pack(">H", len(port_bytes))  # PortLen 
    payload += port_bytes  
    payload += struct.pack(">B", heartbeat_interval)  # Heartbeat
    
 
    packet_len = 8 + len(payload)  
    
    checksum = compute_checksum(payload)
    token = generate_session_token(payload, secret_key)
    
   
    header = struct.pack(">HBBBI", packet_len, command, vsn, checksum, token)
    packet = header + payload
    
    
    
    return packet


def parse_set_server_address_response(data: bytes) -> Dict[str, Any]:
    """Парсит ответ на установку адреса сервера (команда 0x63)"""
    try:
        
        packet_format = ">H B B B I"
        packet_len, command, vsn, checksum, token = struct.unpack(packet_format, data[:9])
        
       
        payload = b''
        if compute_checksum(payload) != checksum:
            raise ValueError("Неверный checksum")
        
        return {
            "Type": "SetServerAddressResponse",
            "PacketLen": packet_len,
            "Command": hex(command),
            "VSN": vsn,
            "CheckSum": hex(checksum),
            "Token": f"0x{token:08X}",
            "CheckSumValid": True,
            "Success": True,
            "ReceivedAt": get_moscow_time().isoformat(),
            "RawPacket": data.hex()
        }
        
    except Exception as e:
        return {
            "Type": "SetServerAddressResponse",
            "Error": f"Ошибка парсинга: {str(e)}",
            "RawPacket": data.hex(),
            "Size": len(data)
        }


def build_query_server_address_request(secret_key: str, vsn: int = 1) -> bytes:
    """Создает запрос на получение адреса сервера (команда 0x6A)"""
    command = 0x6A
    packet_len = 7 
    payload = b''  
    checksum = compute_checksum(payload)
    token = generate_session_token(payload, secret_key)
    header = struct.pack(">HBBBI", packet_len, command, vsn, checksum, token)
    packet = header + payload
    
    
    
    return packet


def parse_query_server_address_response(data: bytes) -> Dict[str, Any]:
    """
    Парсит ответ станции на запрос адреса сервера (команда 0x6A).
    """
    try:

        
        packet_format = ">H B B B I"
        packet_len, command, vsn, checksum, token = struct.unpack(packet_format, data[:9])

        payload = data[9:]

       
        if compute_checksum(payload) != checksum:
            raise ValueError("Неверный checksum")

       
        address_len = struct.unpack(">H", payload[:2])[0]

        address_bytes = payload[2:2 + address_len]
        address = address_bytes.rstrip(b'\x00').decode("ascii", errors="ignore")

       
        port_offset = 2 + address_len
        port_len = struct.unpack(">H", payload[port_offset:port_offset + 2])[0]

        ports_bytes = payload[port_offset + 2:port_offset + 2 + port_len]
        ports = ports_bytes.rstrip(b'\x00').decode("ascii", errors="ignore")

       
        heartbeat_offset = port_offset + 2 + port_len
        heartbeat = payload[heartbeat_offset]

        return {
            "Type": "QueryServerAddressResponse",
            "PacketLen": packet_len,
            "Command": hex(command),
            "VSN": vsn,
            "CheckSum": hex(checksum),
            "CheckSumValid": True,
            "Token": f"0x{token:08X}",
            "AddressLen": address_len,
            "Address": address,
            "PortLen": port_len,
            "Ports": ports,
            "Heartbeat": heartbeat,
            "ReceivedAt": get_moscow_time().isoformat(),
            "RawPacket": data.hex()
        }

    except Exception as e:
        return {
            "Type": "QueryServerAddressResponse",
            "Error": str(e),
            "RawPacket": data.hex(),
            "Size": len(data)
        }

