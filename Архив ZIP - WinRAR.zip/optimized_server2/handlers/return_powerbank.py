from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import asyncio

from models.station_powerbank import StationPowerbank
from models.powerbank import Powerbank
from models.order import Order
from models.action_log import ActionLog
from utils.centralized_logger import get_logger
from utils.packet_utils import (
    build_return_power_bank, 
    parse_return_response, 
    parse_return_power_bank_request,
    build_return_power_bank_response,
    get_moscow_time
)


class ReturnPowerbankHandler:
    """Обработчик для возврата повербанков"""
    
    def __init__(self, db_pool, connection_manager):
        self.db_pool = db_pool
        self.connection_manager = connection_manager
    
    async def _process_automatic_return(self, station_id: int, terminal_id: str, slot_number: int) -> bool:
        """
        Общий метод для автоматической обработки возврата повербанка.
        """
        logger = get_logger('return_powerbank')
        
        try:
            logger.info(f"Автоматический возврат: повербанк {terminal_id} вставлен в станцию {station_id}, слот {slot_number}")
            
            # 1. Находим повербанк по серийному номеру
            try:
                powerbank = await Powerbank.get_by_serial(self.db_pool, terminal_id)
            except Exception as e:
                logger.warning(f"Не удалось получить повербанк по серийному номеру {terminal_id}: {e}")
                return False
            
            if not powerbank:
                logger.warning(f"Повербанк с серийным номером {terminal_id} не найден в БД")
                return False
            
            # 2. Находим активный заказ со статусом 'borrow'
            try:
                active_order = await Order.get_active_borrow_order(self.db_pool, powerbank.powerbank_id)
                
                if active_order:
                    # 3. Автоматически закрываем заказ (borrow -> return)
                    await Order.update_order_status(self.db_pool, active_order.order_id, 'return')
                    logger.info(f" Заказ {active_order.order_id} автоматически закрыт при возврате повербанка {terminal_id} (powerbank_id={powerbank.powerbank_id})")
                else:
                    logger.info(f"Активный заказ для повербанка {terminal_id} не найден (возможно уже закрыт)")
                    
            except Exception as e:
                logger.error(f"Ошибка при закрытии заказа для повербанка {terminal_id}: {e}")
            
            # 4. Обновляем данные станции
            from models.station import Station
            station = await Station.get_by_id(self.db_pool, station_id)
            if station:
                await station.update_last_seen(self.db_pool)
                # Увеличиваем количество доступных повербанков
                await station.update_remain_num(self.db_pool, int(station.remain_num) + 1)
            
            # 5. Запрашиваем актуальный инвентарь
            await self._request_inventory_after_operation(station_id)
            
            logger.info(f" Автоматический возврат повербанка {terminal_id} успешно обработан")
            return True
            
        except Exception as e:
            logger.error(f"Ошибка автоматической обработки возврата: {e}")
            return False
    
    async def handle_return_request(self, data: bytes, connection) -> Optional[bytes]:
        """
        Обрабатывает ЗАПРОС от станции на возврат повербанка (0x66).
        Станция отправляет полные данные о вставленном повербанке.
        
        Процесс:
        1. Парсим данные о повербанке (TerminalID, Level, Voltage и т.д.)
        2. Проверяем наличие активного заказа со статусом 'borrow'
        3. Если заказ есть - закрываем его (borrow -> return)
        4. Записываем/обновляем данные в station_powerbank
        5. Отправляем ответ станции с результатом
        """
        logger = get_logger('return_powerbank')
        
        try:
            # Парсим запрос от станции
            return_request = parse_return_power_bank_request(data)
            
            if 'error' in return_request:
                logger.error(f"Ошибка парсинга запроса возврата: {return_request.get('error')}")
                return None
            
            logger.info(f"📥 Получен запрос на возврат от станции: {return_request}")
            
            station_id = connection.station_id
            if not station_id:
                logger.warning("Запрос возврата от неавторизованной станции")
                return None
            
            # Извлекаем данные из запроса
            slot_number = return_request.get('Slot', 0)
            terminal_id = return_request.get('TerminalID', '')
            level = return_request.get('Level', 0)
            voltage = return_request.get('Voltage', 0)
            current = return_request.get('Current', 0)
            temperature = return_request.get('Temperature', 0)
            status = return_request.get('Status', 0)
            soh = return_request.get('SOH', 100)
            vsn = return_request.get('VSN', 1)
            
            if not terminal_id:
                logger.error(f"Отсутствует TerminalID в запросе возврата от станции {station_id}")
                # Отправляем ответ с ошибкой: Invalid Power Bank ID (4)
                response = self._build_return_response(
                    connection.secret_key, slot_number, 4, 
                    b'\x00' * 8, 0, 0, 0, 0, 0, 0, vsn
                )
                return response
            
            logger.info(f"🔄 Станция {station_id}: возврат повербанка {terminal_id} в слот {slot_number}")
            
            # 1. Находим повербанк в БД
            try:
                powerbank = await Powerbank.get_by_serial(self.db_pool, terminal_id)
            except Exception as e:
                logger.error(f"Ошибка получения повербанка по serial {terminal_id}: {e}")
                powerbank = None
            
            if not powerbank:
                logger.warning(f"⚠️ Повербанк {terminal_id} не найден в БД")
                # Отправляем ответ с ошибкой: Invalid Power Bank ID (4)
                response = self._build_return_response(
                    connection.secret_key, slot_number, 4,
                    terminal_id.encode('utf-8')[:8].ljust(8, b'\x00'),
                    level, voltage, current, temperature, status, soh, vsn
                )
                return response
            
            # 2. Проверяем, не занят ли уже слот
            from models.station import Station
            existing_in_slot = await StationPowerbank.get_by_station_and_slot(
                self.db_pool, station_id, slot_number
            )
            
            if existing_in_slot:
                logger.warning(f"⚠️ Слот {slot_number} уже занят повербанком {existing_in_slot.powerbank_id}")
                # Отправляем ответ: Slot not empty (5)
                response = self._build_return_response(
                    connection.secret_key, slot_number, 5,
                    terminal_id.encode('utf-8')[:8].ljust(8, b'\x00'),
                    level, voltage, current, temperature, status, soh, vsn
                )
                return response
            
            # 3. Проверяем наличие активного заказа
            active_order = None
            try:
                active_order = await Order.get_active_borrow_order(
                    self.db_pool, powerbank.powerbank_id
                )
            except Exception as e:
                logger.error(f"Ошибка проверки активного заказа: {e}")
            
            # 4. Если есть активный заказ - закрываем его
            if active_order:
                try:
                    await Order.update_order_status(
                        self.db_pool, active_order.order_id, 'return'
                    )
                    logger.info(f"✅ Заказ {active_order.order_id} автоматически закрыт при возврате повербанка {terminal_id}")
                except Exception as e:
                    logger.error(f"Ошибка закрытия заказа {active_order.order_id}: {e}")
            else:
                logger.info(f"ℹ️ Активный заказ для повербанка {terminal_id} не найден")
            
            # 5. Записываем данные в station_powerbank
            try:
                await StationPowerbank.add_powerbank(
                    self.db_pool,
                    station_id,
                    powerbank.powerbank_id,
                    slot_number,
                    level=level,
                    voltage=voltage,
                    temperature=temperature
                )
                logger.info(f"✅ Данные повербанка {terminal_id} записаны в station_powerbank (слот {slot_number})")
            except Exception as e:
                logger.error(f"Ошибка записи в station_powerbank: {e}")
            
            # 6. Обновляем данные станции
            from models.station import Station
            station = await Station.get_by_id(self.db_pool, station_id)
            if station:
                await station.update_last_seen(self.db_pool)
                await station.update_remain_num(self.db_pool, int(station.remain_num) + 1)
                logger.info(f"✅ Станция {station_id}: remain_num увеличен до {int(station.remain_num) + 1}")
            
            # 7. Запрашиваем инвентарь для синхронизации
            await self._request_inventory_after_operation(station_id)
            
            # 8. Формируем успешный ответ станции (Success = 1)
            response = self._build_return_response(
                connection.secret_key, slot_number, 1,  # 1 = Success
                terminal_id.encode('utf-8')[:8].ljust(8, b'\x00'),
                level, voltage, current, temperature, status, soh, vsn
            )
            
            logger.info(f"✅ Возврат повербанка {terminal_id} успешно обработан")
            return response
            
        except Exception as e:
            logger.error(f"Ошибка обработки запроса возврата: {e}", exc_info=True)
            return None
    
    def _build_return_response(self, secret_key: str, slot: int, result: int,
                               terminal_id: bytes, level: int, voltage: int,
                               current: int, temperature: int, status: int,
                               soh: int, vsn: int) -> bytes:
        """
        Строит ответ на возврат повербанка
        
        Args:
            secret_key: Секретный ключ станции
            slot: Номер слота
            result: Результат (0-5)
            terminal_id: ID повербанка (8 байт)
            level: Уровень заряда
            voltage: Напряжение (mV)
            current: Ток (mA)
            temperature: Температура
            status: Статус
            soh: Здоровье батареи
            vsn: Версия протокола
        """
        from utils.packet_utils import build_return_power_bank_response, generate_session_token
        import struct
        
        # Формируем payload для вычисления токена
        payload = struct.pack(
            ">BB8sBHHBBB",
            slot, result, terminal_id, level, voltage, current, temperature, status, soh
        )
        
        # Генерируем токен
        token = generate_session_token(payload, secret_key)
        
        # Строим ответ
        response = build_return_power_bank_response(
            slot, result, terminal_id, level, voltage, current, 
            temperature, status, soh, vsn, token
        )
        
        return response
    
    async def handle_return_response(self, data: bytes, connection) -> None:
        """
        Обрабатывает ОТВЕТ от станции на команду возврата повербанка.
       
        """
        logger = get_logger('return_powerbank')
        
        try:
            # Парсим ответ от станции
            return_response = parse_return_response(data)
            logger.info(f"Обработан ответ на возврат: {return_response}")
            
            station_id = connection.station_id
            if not station_id:
                return
            
            # Получаем информацию из ответа
            slot_number = return_response.get('Slot', 0)
            terminal_id = return_response.get('TerminalID', '')
            success = return_response.get('Success', False)
            result_code = return_response.get('ResultCode', 0)
            
            # Если есть TerminalID, значит повербанк успешно вставлен
            if terminal_id:
                # Используем общий метод автоматической обработки
                await self._process_automatic_return(station_id, terminal_id, slot_number)
            else:
                # Нет TerminalID - ошибка возврата
                error_messages = {
                    68: "Повербанк не найден в слоте",
                    1: "Слот заблокирован",
                    2: "Повербанк уже в слоте", 
                    3: "Ошибка связи со станцией",
                    4: "Неверный слот",
                    5: "Повербанк поврежден"
                }
                error_msg = error_messages.get(result_code, f"Неизвестная ошибка (код: {result_code})")
                logger.warning(f"Возврат повербанка не удался для станции {station_id}: {error_msg}")
                    
        except Exception as e:
            logger.error(f"Ошибка обработки ответа возврата: {e}")
    
    async def _update_or_add_powerbank_to_station(self, station_id: int, powerbank_id: int, slot_number: int) -> None:
        """
        Обновляет или добавляет повербанк в станцию
        """
        try:
            # Проверяем, есть ли уже повербанк в этом слоте
            existing = await StationPowerbank.get_by_station_and_slot(self.db_pool, station_id, slot_number)
            
            if existing:
                # Обновляем существующий повербанк
                await StationPowerbank.update_powerbank_data(
                    self.db_pool, 
                    station_id, 
                    slot_number, 
                    level=100, 
                    voltage=4200, 
                    temperature=25
                )
                
                logger = get_logger('return_powerbank')
                logger.info(f"Обновлены данные повербанка {powerbank_id} в слоте {slot_number} станции {station_id}")
            else:
                # Добавляем новый повербанк в станцию
                await self._add_powerbank_to_station(station_id, powerbank_id, slot_number)
                
        except Exception as e:
            logger = get_logger('return_powerbank')
            logger.error(f"Ошибка обновления/добавления повербанка в станцию: {e}")
    
    async def _add_powerbank_to_station(self, station_id: int, powerbank_id: int, slot_number: int) -> None:
        """
        Добавляет повербанк в станцию
        """
        try:
            # Добавляем повербанк в станцию
            await StationPowerbank.add_powerbank(
                self.db_pool, 
                station_id, 
                powerbank_id, 
                slot_number, 
                level=100, 
                voltage=4200, 
                temperature=25
            )
            
            logger = get_logger('return_powerbank')
            logger.info(f"Повербанк {powerbank_id} добавлен в станцию {station_id}, слот {slot_number}")
            
        except Exception as e:
            logger = get_logger('return_powerbank')
            logger.error(f"Ошибка добавления повербанка в станцию: {e}")
    
    async def _request_inventory_after_operation(self, station_id: int) -> None:
        """
        Запрашивает инвентарь после операции
        """
        try:
            from handlers.query_inventory import QueryInventoryHandler
            inventory_handler = QueryInventoryHandler(self.db_pool, self.connection_manager)
            await inventory_handler.send_inventory_request(station_id)
            
            logger = get_logger('return_powerbank')
            logger.info(f"Запрос инвентаря отправлен на станцию {station_id}")
            
        except Exception as e:
            logger = get_logger('return_powerbank')
            logger.error(f"Ошибка запроса инвентаря: {e}")
    
    async def start_damage_return_process(self, station_id: int, user_id: int, description: str) -> Dict[str, Any]:
        """
        Запускает процесс возврата повербанка с поломкой
        """
        try:
            logger = get_logger('return_powerbank')
            logger.info(f"Начинаем процесс возврата с поломкой: station_id={station_id}, user_id={user_id}")
            
            # Проверяем, что станция существует и активна
            from models.station import Station
            station = await Station.get_by_id(self.db_pool, station_id)
            if not station:
                return {"success": False, "message": "Станция не найдена"}
            
            if station.status != 'active':
                return {"success": False, "message": "Станция неактивна"}
            
            # Проверяем, что станция была онлайн в течение последних 30 секунд
            from utils.station_utils import validate_station_for_operation
            station_valid, station_message = await validate_station_for_operation(
                self.db_pool, self.connection_manager, station_id, "возврат powerbank'а с поломкой", 30
            )
            
            if not station_valid:
                return {"success": False, "message": station_message}
            
            # Получаем соединение (уже проверенное в validate_station_for_operation)
            connection = self.connection_manager.get_connection_by_station_id(station_id)
            
            # Ищем активный заказ пользователя
            active_orders = await Order.get_active_orders_by_user(self.db_pool, user_id)
            if not active_orders:
                return {"success": False, "message": "У вас нет активных заказов"}
            
            # Берем первый активный заказ (можно расширить логику выбора)
            active_order = active_orders[0]
            powerbank_id = active_order.powerbank_id
            
            if not powerbank_id:
                return {"success": False, "message": "В заказе не указан повербанк"}
            
            # Получаем информацию о повербанке
            powerbank = await Powerbank.get_by_id(self.db_pool, powerbank_id)
            if not powerbank:
                return {"success": False, "message": "Повербанк не найден"}
            
            # Обновляем статус повербанка на "сломанный пользователем"
            await powerbank.update_status(self.db_pool, 'user_reported_broken')
            await powerbank.update_write_off_reason(self.db_pool, 'broken')
            
            # Создаем заказ на возврат с поломкой
            return_order = await Order.create_return_order(
                self.db_pool, 
                station_id, 
                user_id, 
                powerbank_id
            )
            
            # Обновляем оригинальный заказ на статус "возвращен с поломкой"
            await Order.update_order_status(self.db_pool, active_order.order_id, 'return_damage')
            
            # Создаем запись об ошибке повербанка
            from api.powerbank_error_report_api import PowerbankErrorReportAPI
            error_api = PowerbankErrorReportAPI(self.db_pool)
            await error_api.report_powerbank_error(
                order_id=active_order.order_id,
                powerbank_id=powerbank_id,
                station_id=station_id,
                user_id=user_id,
                error_type='other',  
                additional_notes=description
            )
            
            # Отправляем команду на возврат повербанка
            secret_key = connection.secret_key
            if not secret_key:
                return {"success": False, "message": "Нет секретного ключа для станции"}
            
            # Находим свободный слот для возврата
            free_slot = await self._find_free_slot(station_id)
            if not free_slot:
                return {"success": False, "message": "Нет свободных слотов для возврата"}
            
            # Создаем команду возврата
            return_command = build_return_power_bank(
                secret_key=secret_key,
                slot=free_slot,
                vsn=1
            )
            
            # Отправляем команду станции
            try:
                connection.writer.write(return_command)
                await connection.writer.drain()
                logger.info(f"Команда возврата отправлена на станцию {station_id}")
            except Exception as e:
                logger.error(f"Ошибка отправки команды возврата: {e}")
                return {"success": False, "message": f"Ошибка отправки команды: {e}"}
            
            # Ждем 10 секунд для вставки повербанка пользователем
            logger.info(f"Ожидаем вставку повербанка в течение 10 секунд...")
            await asyncio.sleep(10)
            
            # Запрашиваем инвентарь для получения актуальных данных о вставленном повербанке
            await self._request_inventory_after_operation(station_id)
            await asyncio.sleep(2)
            
            # Проверяем, был ли повербанк действительно вставлен в станцию
            powerbank_inserted = await self._check_powerbank_insertion(station_id, powerbank_id)
            
            if powerbank_inserted:
                logger.info(f"Повербанк {powerbank_id} успешно вставлен в станцию {station_id}")
                message = "Повербанк возвращен с поломкой и успешно обработан станцией."
            else:
                logger.warning(f"Повербанк {powerbank_id} не был обнаружен в станции {station_id} после 10 секунд ожидания")
                message = "Повербанк возвращен с поломкой, но не был обнаружен в станции. Проверьте, что повербанк вставлен правильно."
            
            logger.info(f"Процесс возврата с поломкой завершен: order_id={return_order.order_id}")
            
            return {
                "success": True,
                "message": message,
                "order_id": return_order.order_id,
                "powerbank_id": powerbank_id,
                "station_id": station_id,
                "powerbank_inserted": powerbank_inserted
            }
            
        except Exception as e:
            logger = get_logger('return_powerbank')
            logger.error(f"Ошибка процесса возврата с поломкой: {e}")
            return {"success": False, "message": f"Ошибка процесса возврата: {e}"}
    
    async def _check_powerbank_insertion(self, station_id: int, powerbank_id: int) -> bool:
        """
        Проверяет, был ли повербанк вставлен в станцию
        """
        try:
            # Проверяем, есть ли повербанк в station_powerbank для этой станции
            station_powerbanks = await StationPowerbank.get_by_station(self.db_pool, station_id)
            
            for sp in station_powerbanks:
                if sp.powerbank_id == powerbank_id:
                    logger = get_logger('return_powerbank')
                    logger.info(f"Повербанк {powerbank_id} найден в слоте {sp.slot_number} станции {station_id}")
                    return True
            
            return False
            
        except Exception as e:
            logger = get_logger('return_powerbank')
            logger.error(f"Ошибка проверки вставки повербанка: {e}")
            return False
    
    async def start_manual_return_process(self, station_id: int, user_id: int, order_id: int) -> Dict[str, Any]:
        """
        Запускает процесс ручного возврата повербанка (вариант 3)
        """
        try:
            logger = get_logger('return_powerbank')
            logger.info(f"Начинаем процесс ручного возврата: station_id={station_id}, user_id={user_id}, order_id={order_id}")
            
            # Получаем заказ
            order = await Order.get_by_id(self.db_pool, order_id)
            if not order:
                return {"success": False, "message": "Заказ не найден"}
            
            if order.user_id != user_id:
                return {"success": False, "message": "Заказ не принадлежит пользователю"}
            
            if order.status != 'borrow':
                return {"success": False, "message": "Заказ неактивен или уже возвращен"}
            
            powerbank_id = order.powerbank_id
            if not powerbank_id:
                return {"success": False, "message": "В заказе не указан повербанк"}
            
            # Проверяем, что станция существует и активна
            from models.station import Station
            station = await Station.get_by_id(self.db_pool, station_id)
            if not station:
                return {"success": False, "message": "Станция не найдена"}
            
            if station.status != 'active':
                return {"success": False, "message": "Станция неактивна"}
            
            # Проверяем, что станция была онлайн в течение последних 30 секунд
            from utils.station_utils import validate_station_for_operation
            station_valid, station_message = await validate_station_for_operation(
                self.db_pool, self.connection_manager, station_id, "ручной возврат powerbank'а", 30
            )
            
            if not station_valid:
                return {"success": False, "message": station_message}
            
            # Получаем соединение
            connection = self.connection_manager.get_connection_by_station_id(station_id)
            
            # Отправляем команду на возврат повербанка
            secret_key = connection.secret_key
            if not secret_key:
                return {"success": False, "message": "Нет секретного ключа для станции"}
            
            # Находим свободный слот для возврата
            free_slot = await self._find_free_slot(station_id)
            if not free_slot:
                return {"success": False, "message": "Нет свободных слотов для возврата"}
            
            # Создаем команду возврата
            return_command = build_return_power_bank(
                secret_key=secret_key,
                slot=free_slot,
                vsn=1
            )
            
            # Отправляем команду станции
            try:
                connection.writer.write(return_command)
                await connection.writer.drain()
                logger.info(f"Команда возврата отправлена на станцию {station_id}")
            except Exception as e:
                logger.error(f"Ошибка отправки команды возврата: {e}")
                return {"success": False, "message": f"Ошибка отправки команды: {e}"}
            
            # Ждем 10 секунд для вставки повербанка пользователем
            logger.info(f"Ожидаем вставку повербанка в течение 10 секунд...")
            await asyncio.sleep(10)
            
            # Запрашиваем инвентарь для получения актуальных данных о вставленном повербанке
            await self._request_inventory_after_operation(station_id)
            
            # Дополнительно ждем еще 2 секунды для обработки ответа инвентаря
            await asyncio.sleep(2)
            
            # Проверяем, был ли повербанк действительно вставлен в станцию
            powerbank_inserted = await self._check_powerbank_insertion(station_id, powerbank_id)
            
            if powerbank_inserted:
                # Обновляем статус заказа на 'return'
                await Order.update_order_status(self.db_pool, order_id, 'return')
                logger.info(f"Заказ {order_id} изменен на статус 'return' - повербанк {powerbank_id} возвращен")
                message = "Повербанк успешно возвращен и обработан станцией."
            else:
                logger.warning(f"Повербанк {powerbank_id} не был обнаружен в станции {station_id} после 10 секунд ожидания")
                message = "Повербанк не был обнаружен в станции. Проверьте, что повербанк вставлен правильно."
            
            logger.info(f"Процесс ручного возврата завершен: order_id={order_id}")
            
            return {
                "success": True,
                "message": message,
                "order_id": order_id,
                "powerbank_id": powerbank_id,
                "station_id": station_id,
                "powerbank_inserted": powerbank_inserted
            }
            
        except Exception as e:
            logger = get_logger('return_powerbank')
            logger.error(f"Ошибка процесса ручного возврата: {e}")
            return {"success": False, "message": f"Ошибка процесса возврата: {e}"}
    
    async def _find_free_slot(self, station_id: int) -> Optional[int]:
        """
        Находит свободный слот в станции для возврата повербанка
        """
        try:
            from models.station_powerbank import StationPowerbank
            
            # Получаем все занятые слоты в станции
            occupied_slots = await StationPowerbank.get_occupied_slots(self.db_pool, station_id)
            
            # Получаем информацию о станции для определения общего количества слотов
            from models.station import Station
            station = await Station.get_by_id(self.db_pool, station_id)
            if not station:
                return None
            
            # Используем количество слотов из базы данных
            max_slots = station.slots_declared
            
            # Ищем первый свободный слот
            for slot_number in range(1, max_slots + 1):
                if slot_number not in occupied_slots:
                    logger = get_logger('return_powerbank')
                    logger.info(f"Найден свободный слот {slot_number} для возврата в станции {station_id}")
                    return slot_number
            
            return None
            
        except Exception as e:
            logger = get_logger('return_powerbank')
            logger.error(f"Ошибка поиска свободного слота: {e}")
            return None
