"""
Модель для работы с заказами
"""
from typing import Optional, Dict, Any, List
from datetime import datetime
import aiomysql
from utils.time_utils import get_moscow_time


class Order:
    """Модель заказа"""
    
    def __init__(self, order_id: int, station_id: int, user_id: int, 
                 powerbank_id: Optional[int] = None, status: str = 'borrow',
                 timestamp: Optional[datetime] = None, completed_at: Optional[datetime] = None):
        self.order_id = order_id
        self.station_id = station_id
        self.user_id = user_id
        self.powerbank_id = powerbank_id
        self.status = status
        self.timestamp = timestamp or get_moscow_time()
        self.completed_at = completed_at
    
    def to_dict(self) -> Dict[str, Any]:
        """Преобразует заказ в словарь"""
        return {
            'order_id': self.order_id,
            'station_id': self.station_id,
            'user_id': self.user_id,
            'powerbank_id': self.powerbank_id,
            'status': self.status,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None
        }
    
    @classmethod
    async def create_pending_order(cls, db_pool, user_id: int, powerbank_id: int, 
                                 station_id: int) -> 'Order':
        """Создает заказ со статусом бороу"""

        return await cls.create(db_pool, station_id, user_id, powerbank_id, 
                              status='borrow')
    
    @classmethod
    async def create(cls, db_pool, station_id: int, user_id: int, 
                    powerbank_id: int = None, status: str = 'borrow') -> 'Order':
        """Создает заказ с указанными параметрами"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                # Проверяем существование пользователя
                await cursor.execute("""
                    SELECT user_id FROM app_user WHERE user_id = %s
                """, (user_id,))
                user_exists = await cursor.fetchone()
                
                if not user_exists:
                    # Создаем системного пользователя для административных операций
                    await cursor.execute("""
                        INSERT INTO app_user (fio, email, phone_e164, status, created_at, powerbank_limit)
                        VALUES (%s, %s, %s, %s, %s, %s) AS new_user
                        ON DUPLICATE KEY UPDATE fio = new_user.fio
                    """, (f'system_user_{user_id}', f'system_{user_id}@local', '0000000000', 'active', get_moscow_time(), 1))
                
                await cursor.execute("""
                    INSERT INTO orders (station_id, user_id, powerbank_id, status, timestamp, completed_at)
                    VALUES (%s, %s, %s, %s, %s, %s)
                """, (station_id, user_id, powerbank_id, status, get_moscow_time(), None))
                
                order_id = cursor.lastrowid
                
                return cls(
                    order_id=order_id,
                    station_id=station_id,
                    user_id=user_id,
                    powerbank_id=powerbank_id,
                    status=status,
                    timestamp=get_moscow_time()
                )
    
    @classmethod
    async def create_borrow_order(cls, db_pool, station_id: int, user_id: int, 
                                 powerbank_id: int) -> 'Order':
        """Создает заказ на выдачу повербанка"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                # Проверяем существование пользователя
                await cursor.execute("""
                    SELECT user_id FROM app_user WHERE user_id = %s
                """, (user_id,))
                user_exists = await cursor.fetchone()
                
                if not user_exists:
                    # Создаем системного пользователя для административных операций
                    await cursor.execute("""
                        INSERT INTO app_user (fio, email, phone_e164, status, created_at, powerbank_limit)
                        VALUES (%s, %s, %s, %s, %s, %s) AS new_values
                        ON DUPLICATE KEY UPDATE fio = new_values.fio
                    """, (f'system_user_{user_id}', f'system_{user_id}@local', '0000000000', 'active', get_moscow_time(), 1))
                
                await cursor.execute("""
                    INSERT INTO orders (station_id, user_id, powerbank_id, status, timestamp, completed_at)
                    VALUES (%s, %s, %s, %s, %s, %s)
                """, (station_id, user_id, powerbank_id, 'borrow', get_moscow_time(), None))
                
                order_id = cursor.lastrowid
                
                return cls(
                    order_id=order_id,
                    station_id=station_id,
                    user_id=user_id,
                    powerbank_id=powerbank_id,
                    status='borrow',
                    timestamp=get_moscow_time()
                )
    
    @classmethod
    async def create_return_order(cls, db_pool, station_id: int, user_id: int, 
                                powerbank_id: int) -> 'Order':
        """Создает заказ на возврат повербанка"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                # Проверяем существование пользователя
                await cursor.execute("""
                    SELECT user_id FROM app_user WHERE user_id = %s
                """, (user_id,))
                user_exists = await cursor.fetchone()
                
                if not user_exists:
                    # Создаем системного пользователя для административных операций
                    await cursor.execute("""
                        INSERT INTO app_user (fio, email, phone_e164, status, created_at, powerbank_limit)
                        VALUES (%s, %s, %s, %s, %s, %s) AS new_values
                        ON DUPLICATE KEY UPDATE fio = new_values.fio
                    """, (f'system_user_{user_id}', f'system_{user_id}@local', '0000000000', 'active', get_moscow_time(), 1))
                
                # Для заказов на возврат сразу устанавливаем completed_at
                completed_time = get_moscow_time()
                await cursor.execute("""
                    INSERT INTO orders (station_id, user_id, powerbank_id, status, timestamp, completed_at)
                    VALUES (%s, %s, %s, %s, %s, %s)
                """, (station_id, user_id, powerbank_id, 'return', get_moscow_time(), completed_time))
                
                order_id = cursor.lastrowid
                
                return cls(
                    order_id=order_id,
                    station_id=station_id,
                    user_id=user_id,
                    powerbank_id=powerbank_id,
                    status='return',
                    timestamp=get_moscow_time()
                )
    
    @classmethod
    async def get_by_id(cls, db_pool, order_id: int) -> Optional['Order']:
        """Получает заказ по ID"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute("""
                    SELECT id, station_id, user_id, powerbank_id, status, timestamp
                    FROM orders WHERE id = %s
                """, (order_id,))
                
                result = await cursor.fetchone()
                
                if result:
                    return cls(
                        order_id=result[0],
                        station_id=result[1],
                        user_id=result[2],
                        powerbank_id=result[3],
                        status=result[4],
                        timestamp=result[5]
                    )
                return None
    
    @classmethod
    async def get_user_orders(cls, db_pool, user_id: int, limit: int = 10) -> List['Order']:
        """Получает заказы пользователя"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute("""
                    SELECT id, station_id, user_id, powerbank_id, status, timestamp
                    FROM orders 
                    WHERE user_id = %s 
                    ORDER BY timestamp DESC 
                    LIMIT %s
                """, (user_id, limit))
                
                results = await cursor.fetchall()
                
                orders = []
                for result in results:
                    orders.append(cls(
                        order_id=result[0],
                        station_id=result[1],
                        user_id=result[2],
                        powerbank_id=result[3],
                        status=result[4],
                        timestamp=result[5]
                    ))
                
                return orders
    
    @classmethod
    async def get_active_orders_by_user(cls, db_pool, user_id: int) -> List['Order']:
        """Получает активные заказы пользователя"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute("""
                    SELECT id, station_id, user_id, powerbank_id, status, timestamp
                    FROM orders 
                    WHERE user_id = %s AND status IN ('borrow', 'return_damage')
                    ORDER BY timestamp DESC
                """, (user_id,))
                
                results = await cursor.fetchall()
                
                orders = []
                for result in results:
                    orders.append(cls(
                        order_id=result[0],
                        station_id=result[1],
                        user_id=result[2],
                        powerbank_id=result[3],
                        status=result[4],
                        timestamp=result[5]
                    ))
                
                return orders
    
    @classmethod
    async def get_station_orders(cls, db_pool, station_id: int, limit: int = 10) -> List['Order']:
        """Получает заказы станции"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute("""
                    SELECT id, station_id, user_id, powerbank_id, status, timestamp
                    FROM orders 
                    WHERE station_id = %s 
                    ORDER BY timestamp DESC 
                    LIMIT %s
                """, (station_id, limit))
                
                results = await cursor.fetchall()
                
                orders = []
                for result in results:
                    orders.append(cls(
                        order_id=result[0],
                        station_id=result[1],
                        user_id=result[2],
                        powerbank_id=result[3],
                        status=result[4],
                        timestamp=result[5]
                    ))
                
                return orders

    @classmethod
    async def get_by_user_id(cls, db_pool, user_id: int) -> List['Order']:
        """Получает все заказы пользователя"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute("""
                    SELECT id, station_id, user_id, powerbank_id, status, timestamp
                    FROM orders 
                    WHERE user_id = %s 
                    ORDER BY timestamp DESC
                """, (user_id,))
                
                results = await cursor.fetchall()
                
                orders = []
                for result in results:
                    orders.append(cls(
                        order_id=result[0],
                        station_id=result[1],
                        user_id=result[2],
                        powerbank_id=result[3],
                        status=result[4],
                        timestamp=result[5]
                    ))
                
                return orders

    @classmethod
    async def get_active_by_user_id(cls, db_pool, user_id: int) -> List['Order']:
        """Получает активные заказы пользователя"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute("""
                    SELECT id, station_id, user_id, powerbank_id, status, timestamp
                    FROM orders 
                    WHERE user_id = %s AND status = 'active'
                    ORDER BY timestamp DESC
                """, (user_id,))
                
                results = await cursor.fetchall()
                
                orders = []
                for result in results:
                    orders.append(cls(
                        order_id=result[0],
                        station_id=result[1],
                        user_id=result[2],
                        powerbank_id=result[3],
                        status=result[4],
                        timestamp=result[5]
                    ))
                
                return orders

    @classmethod
    async def get_active_by_powerbank_id(cls, db_pool, powerbank_id: int) -> Optional['Order']:
        """Получает активный заказ по ID повербанка"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute("""
                    SELECT id, station_id, user_id, powerbank_id, status, timestamp
                    FROM orders 
                    WHERE powerbank_id = %s AND status = 'active'
                    LIMIT 1
                """, (powerbank_id,))
                
                result = await cursor.fetchone()
                
                if result:
                    return cls(
                        order_id=result[0],
                        station_id=result[1],
                        user_id=result[2],
                        powerbank_id=result[3],
                        status=result[4],
                        timestamp=result[5]
                    )
                return None

    @classmethod
    async def get_active_by_station_id(cls, db_pool, station_id: int) -> List['Order']:
        """Получает активные заказы для станции"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute("""
                    SELECT id, station_id, user_id, powerbank_id, status, timestamp
                    FROM orders 
                    WHERE station_id = %s AND status = 'active'
                    ORDER BY timestamp DESC
                """, (station_id,))
                
                results = await cursor.fetchall()
                
                orders = []
                for result in results:
                    orders.append(cls(
                        order_id=result[0],
                        station_id=result[1],
                        user_id=result[2],
                        powerbank_id=result[3],
                        status=result[4],
                        timestamp=result[5]
                    ))
                
                return orders

    @classmethod
    async def get_count_by_user_id(cls, db_pool, user_id: int) -> int:
        """Получает количество заказов пользователя"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute("""
                    SELECT COUNT(*) FROM orders WHERE user_id = %s
                """, (user_id,))
                
                result = await cursor.fetchone()
                return result[0] if result else 0

    @classmethod
    async def cancel(cls, db_pool, order_id: int) -> bool:
        """Отменяет заказ"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute("""
                    UPDATE orders SET status = 'cancelled' WHERE id = %s
                """, (order_id,))
                
                return cursor.rowcount > 0
    
    async def update_status(self, db_pool, new_status: str) -> bool:
        """Обновляет статус заказа"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute(
                    "UPDATE orders SET status = %s WHERE id = %s",
                    (new_status, self.order_id)
                )
                self.status = new_status
                return True
    
    @classmethod
    async def get_active_borrow_order(cls, db_pool, powerbank_id: int) -> Optional['Order']:
        """Получает активный заказ на выдачу для повербанка"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute("""
                    SELECT id, station_id, user_id, powerbank_id, status, timestamp
                    FROM orders 
                    WHERE powerbank_id = %s AND status = 'borrow'
                    ORDER BY timestamp DESC 
                    LIMIT 1
                """, (powerbank_id,))
                
                result = await cursor.fetchone()
                
                if result:
                    return cls(
                        order_id=result[0],
                        station_id=result[1],
                        user_id=result[2],
                        powerbank_id=result[3],
                        status=result[4],
                        timestamp=result[5]
                    )
                return None
    
    @classmethod
    async def confirm_borrow(cls, db_pool, order_id: int) -> bool:
        """Подтверждает заказ на выдачу ('borrow')"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute("""
                    UPDATE orders SET status = 'borrow' 
                    WHERE id = %s
                """, (order_id,))
                
                return cursor.rowcount > 0
    
    @classmethod
    async def complete_order(cls, db_pool, order_id: int) -> bool:
        """Завершает заказ (меняет статус на 'completed')"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute("""
                    UPDATE orders SET status = 'completed' WHERE id = %s
                """, (order_id,))
                
                return cursor.rowcount > 0
    
    @classmethod
    async def update_order_status(cls, db_pool, order_id: int, new_status: str) -> bool:
        """Обновляет статус заказа"""
        # Проверяем, что статус соответствует допустимым значениям
        allowed_statuses = ['borrow', 'return']
        if new_status not in allowed_statuses:
            print(f"Недопустимый статус заказа: {new_status}. Допустимые: {allowed_statuses}")
            return False
            
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                # Обновляем статус и устанавливаем completed_at для завершенных заказов
                if new_status == 'return':
                    await cursor.execute("""
                        UPDATE orders SET status = %s, completed_at = %s WHERE id = %s
                    """, (new_status, get_moscow_time(), order_id))
                else:
                    # При смене на другие статусы сбрасываем completed_at
                    await cursor.execute("""
                        UPDATE orders SET status = %s, completed_at = NULL WHERE id = %s
                    """, (new_status, order_id))
                
                return cursor.rowcount > 0
    
    @classmethod
    async def get_all_active(cls, db_pool) -> List['Order']:
        """Получает все активные заказы"""
        async with db_pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute("""
                    SELECT id, station_id, user_id, powerbank_id, status, timestamp
                    FROM orders 
                    WHERE status IN ('borrow', 'pending', 'return_damage')
                    ORDER BY timestamp DESC
                """)
                
                results = await cursor.fetchall()
                
                orders = []
                for result in results:
                    orders.append(cls(
                        order_id=result[0],
                        station_id=result[1],
                        user_id=result[2],
                        powerbank_id=result[3],
                        status=result[4],
                        timestamp=result[5]
                    ))
                
                return orders